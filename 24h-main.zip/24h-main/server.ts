import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini client
let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return genAIClient;
}

// Health check endpoint
app.get("/api/health", (_req: Request, res: Response) => {
  res.json({ status: "ok", service: "Cartomante 24h", timestamp: new Date().toISOString() });
});

// API endpoint: Oracle / Tarot interpretation with Gemini AI
app.post("/api/oracle/reading", async (req: Request, res: Response) => {
  try {
    const { question, cards, deckType, clientName } = req.body;

    if (!cards || !Array.isArray(cards) || cards.length === 0) {
      return res.status(400).json({ error: "Nenhuma carta fornecida para a tiragem." });
    }

    const ai = getGenAI();
    if (!ai) {
      // Fallback pre-calculated reading if API key is not yet set
      const cardNames = cards.map((c: any) => c.name).join(", ");
      return res.json({
        reading: `As cartas reveladas (${cardNames}) indicam um momento de profunda transformação em sua vida, ${clientName || 'buscador'}. As energias do universo estão se alinhando para destravar caminhos afetivos e financeiros. Mantenha o coração sereno e confie nas respostas das forças espirituais. Para aprofundar cada detalhe com a Cartomante de plantão, inicie sua chamada de vídeo ou envie mensagem no grupo de WhatsApp!`,
        advice: "Foque na sua intuição e evite tomar decisões precipitadas nas próximas 24 horas.",
        energyScore: 88,
        aiPowered: false,
      });
    }

    const cardsDesc = cards
      .map(
        (c: any, index: number) =>
          `Carta ${index + 1}: ${c.name} (${c.positionName || 'Posição ' + (index + 1)}) - Significado arquetípico: ${c.keywords || c.summary}`
      )
      .join("\n");

    const prompt = `Você é a venerada e sábia Cartomante 24h, uma experiente mestre de Baralho Cigano (Lenormand) e Tarot de Marselha com mais de 25 anos de mediunidade acolhedora, sensível e respeitosa.
Um consulente solicitou uma tiragem espiritual rápida online.

Nome do Consulente: ${clientName || "Irmão(ã) de Luz"}
Pergunta ou Intenção: ${question || "Orientação geral sobre amor, trabalho e caminhos espirituais"}
Tipo de Baralho: ${deckType || "Baralho Cigano Tradicional"}
Cartas Reveladas:
${cardsDesc}

Por favor, forneça uma interpretação mística e acolhedora em português do Brasil:
1. Mensagem central das cartas e revelação espiritual.
2. Conselho prático para o momento presente (amor, finanças ou saúde energética).
3. Uma bênção/conselho final encorajador.

Responda em tom carinhoso, empático e misterioso (estilo cartomante/cigana de luz), sem ser excessivamente fatalista, focando em caminhos abertos, clareza e acolhimento 24 horas. Máximo de 3 parágrafos fluídos.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction:
          "Você é a Cartomante 24h, conselheira espiritual compassiva, respeitosa e sábia. Fale sempre em português natural e acolhedor do Brasil.",
        temperature: 0.8,
      },
    });

    const readingText = response.text || "As cartas trazem ventos de renovação e proteção para o seu destino.";

    return res.json({
      reading: readingText,
      energyScore: Math.floor(Math.random() * 15) + 85,
      aiPowered: true,
    });
  } catch (error: any) {
    console.error("Erro na consulta do oráculo:", error);
    return res.json({
      reading:
        "Os caminhos astrais mostram que portas fechadas se abrirão em breve. A energia das cartas sinaliza renovação no amor e proteção contra energias pesadas. Para uma revelação mais aprofundada em tempo real, conecte-se com a Cartomante por chamada de vídeo ou entre no nosso Grupo VIP de WhatsApp!",
      advice: "Acenda seus pensamentos positivos e não hesite em procurar a orientação das cartas.",
      energyScore: 90,
      aiPowered: false,
    });
  }
});

// Start server with Vite middleware in dev or static files in prod
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Cartomante 24h server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
