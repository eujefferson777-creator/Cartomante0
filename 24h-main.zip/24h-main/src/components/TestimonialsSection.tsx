import { Star, MessageCircle, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { TESTIMONIALS } from '../data/testimonials';
import { SiteConfig } from '../types';

interface TestimonialsSectionProps {
  config?: SiteConfig;
}

export function TestimonialsSection({ config }: TestimonialsSectionProps) {
  const testimonials = config?.customTestimonials && config.customTestimonials.length > 0
    ? config.customTestimonials
    : TESTIMONIALS;

  return (
    <section id="depoimentos" className="py-16 md:py-24 bg-[#070312] relative border-t border-purple-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            Depoimentos Verificados
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-white">
            Quem Já Consultou por Vídeo e WhatsApp
          </h2>
          <p className="mt-3 text-sm sm:text-base text-purple-200/80">
            Mais de 10.000 pessoas acolhidas e caminhos destravados. Veja os relatos de quem confiou nas cartas.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="p-6 rounded-3xl bg-[#110722] border border-purple-500/30 hover:border-purple-400 transition-all flex flex-col justify-between shadow-xl shadow-purple-950/30"
            >
              <div>
                {/* Rating stars & Date */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex text-purple-400">
                    {[...Array(t.stars)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-purple-400 text-purple-400" />
                    ))}
                  </div>
                  <span className="text-[11px] text-purple-300/70">{t.date}</span>
                </div>

                {/* Comment */}
                <p className="text-sm text-purple-100 italic leading-relaxed mb-4">
                  "{t.comment}"
                </p>

                {/* WhatsApp Screenshot Box */}
                {t.whatsappScreenshotText && (
                  <div className="p-3 bg-[#0a1118] border border-emerald-500/30 rounded-2xl text-[11px] text-purple-100 mb-4 flex items-start gap-2 shadow-inner">
                    <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] text-emerald-400 font-bold block mb-0.5">Mensagem enviada no WhatsApp:</span>
                      <p className="italic text-neutral-200">"{t.whatsappScreenshotText}"</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Client Info */}
              <div className="pt-4 border-t border-purple-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={t.avatar}
                    alt={t.clientName}
                    className="w-10 h-10 rounded-full object-cover border border-purple-400/60"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center gap-1">
                      {t.clientName}
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    </h3>
                    <p className="text-[10px] text-purple-300/70">{t.city}</p>
                  </div>
                </div>
                <span className="text-[10px] text-purple-200 bg-purple-950/80 px-2 py-0.5 rounded-md border border-purple-500/30 font-medium">
                  {t.serviceUsed.split('(')[0]}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
