import { Check, MessageCircle, Sparkles, QrCode, ShieldCheck, Zap, Edit3, HeartHandshake } from 'lucide-react';
import { PRICING_PLANS } from '../data/pricingPlans';
import { PricingPlan, SiteConfig, UserAccount } from '../types';

interface PricingCalculatorSectionProps {
  config: SiteConfig;
  currentUser?: UserAccount | null;
  onSelectPlan: (plan: PricingPlan) => void;
  onSelectCustomCalculation?: (title: string, price: number) => void;
  onOpenWhatsAppDirect: (planTitle: string, price: number) => void;
  onOpenLinkManager?: (targetLinkId?: string) => void;
}

export function PricingCalculatorSection({
  config,
  currentUser,
  onSelectPlan,
  onOpenWhatsAppDirect,
  onOpenLinkManager
}: PricingCalculatorSectionProps) {
  return (
    <section id="valores" className="py-16 md:py-24 bg-[#080412] relative border-t border-purple-500/20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            Tabela Oficial de Consultas 24h
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-white">
            Valores Transparentes & Acessíveis
          </h2>
          <p className="mt-3 text-sm sm:text-base text-purple-200/80">
            Sem pegadinhas ou cobranças ocultas. Escolha a sua tiragem de 1 ou 3 perguntas com resposta imediata das Cartomantes de plantão.
          </p>
          {currentUser?.role === 'admin' && (
            <div className="mt-3">
              <button
                onClick={() => onOpenLinkManager?.('pix')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md cursor-pointer transition-all"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Atualizar Valores & Chaves PIX (Admin)</span>
              </button>
            </div>
          )}
        </div>

        {/* Pricing Cards Grid - Exactly the 2 requested options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {PRICING_PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 relative ${
                plan.isPopular
                  ? 'bg-gradient-to-b from-purple-950 via-[#1a0e36] to-[#0d051c] border-2 border-amber-400 shadow-2xl shadow-purple-950/80 scale-[1.02]'
                  : 'bg-[#100720] border border-purple-500/30 hover:border-purple-400/60 shadow-xl shadow-purple-950/40'
              }`}
            >
              {/* Popular Badge */}
              {plan.badge && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span
                    className={`px-4 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow-lg ${
                      plan.isPopular
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-neutral-950 border border-amber-300'
                        : 'bg-[#1a0f33] text-purple-200 border border-purple-400/40'
                    }`}
                  >
                    ⭐ {plan.badge}
                  </span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mt-2 mb-3">
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-500/40">
                    🟢 Plantão 24h Disponível
                  </span>
                  <span className="text-xs font-bold text-white bg-purple-950/90 px-2.5 py-1 rounded-full border border-purple-500/40">
                    {plan.directQuestions} {plan.directQuestions === 1 ? 'Pergunta' : 'Perguntas'}
                  </span>
                </div>

                <h3 className="text-2xl font-serif font-black text-white">{plan.title}</h3>
                <p className="text-xs sm:text-sm text-purple-200/80 mt-2 leading-relaxed">{plan.description}</p>

                {/* Price Display */}
                <div className="my-6 pt-4 border-t border-purple-500/20">
                  {plan.originalPrice && (
                    <div className="text-xs text-purple-400/70 line-through mb-0.5 font-mono">
                      De R$ {plan.originalPrice.toFixed(2).replace('.', ',')}
                    </div>
                  )}
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-sm font-bold text-amber-400">R$</span>
                    <span className="text-4xl sm:text-5xl font-black text-white tracking-tight">
                      {plan.price.toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-xs text-purple-300 font-medium">/ consulta</span>
                  </div>
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1 mt-1.5">
                    <Zap className="w-3.5 h-3.5 fill-emerald-400" /> Atendimento imediato após confirmação
                  </span>
                </div>

                {/* Features List */}
                <ul className="space-y-3 mb-6 text-xs sm:text-sm text-purple-100">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5 pt-4 border-t border-purple-500/20">
                <button
                  id={`select-plan-pix-${plan.id}`}
                  onClick={() => onSelectPlan(plan)}
                  className={`w-full py-3.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg ${
                    plan.isPopular
                      ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-black'
                      : 'bg-purple-600 hover:bg-purple-500 text-white'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>Pagar com Chave PIX (R$ {plan.price.toFixed(2).replace('.', ',')})</span>
                </button>

                <button
                  id={`select-plan-whatsapp-${plan.id}`}
                  onClick={() => onOpenWhatsAppDirect(plan.title, plan.price)}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-emerald-950/70 hover:bg-emerald-900/90 border border-emerald-500/40 text-emerald-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-emerald-400" />
                  <span>Chamar no WhatsApp Oficial</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Security & Guarantee Note */}
        <div className="mt-12 p-6 rounded-3xl bg-purple-950/30 border border-purple-500/30 text-center max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="text-left">
            <h4 className="font-serif font-bold text-white text-sm">Garantia de Sigilo e Respeito Astral</h4>
            <p className="text-xs text-purple-200/80 mt-0.5">
              Todas as consultas são 100% confidenciais. Você conversa diretamente com a Cartomante no WhatsApp ou na sala de vídeo privativa.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
