import React, { useState } from 'react';
import { 
  X, 
  Link as LinkIcon, 
  Check, 
  ExternalLink, 
  MessageCircle, 
  Video, 
  Sparkles, 
  DollarSign, 
  Instagram, 
  Facebook,
  Send, 
  Youtube, 
  Save, 
  RefreshCw, 
  ShieldCheck, 
  AlertCircle,
  HelpCircle,
  Plus,
  Trash2
} from 'lucide-react';
import { SiteConfig } from '../types';

interface AdminLinkManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SiteConfig;
  onSaveConfig: (updated: SiteConfig) => void;
  targetLinkId?: string | null;
}

export function AdminLinkManagerModal({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  targetLinkId
}: AdminLinkManagerModalProps) {
  const [formData, setFormData] = useState<SiteConfig>({
    ...config,
    customLinks: config.customLinks || {}
  });

  const [activeTab, setActiveTab] = useState<'all' | 'whatsapp' | 'balloon' | 'video' | 'pix' | 'social' | 'custom'>(
    targetLinkId === 'balloon' ? 'balloon' :
    targetLinkId?.startsWith('social') ? 'social' :
    targetLinkId?.startsWith('video') ? 'video' :
    targetLinkId?.startsWith('pix') ? 'pix' :
    targetLinkId?.startsWith('wa') ? 'whatsapp' : 'all'
  );

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [newCustomKey, setNewCustomKey] = useState('');
  const [newCustomUrl, setNewCustomUrl] = useState('');

  if (!isOpen) return null;

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    onSaveConfig(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  const handleAddCustomLink = () => {
    if (!newCustomKey.trim() || !newCustomUrl.trim()) return;
    setFormData({
      ...formData,
      customLinks: {
        ...(formData.customLinks || {}),
        [newCustomKey.trim()]: newCustomUrl.trim()
      }
    });
    setNewCustomKey('');
    setNewCustomUrl('');
  };

  const handleRemoveCustomLink = (key: string) => {
    const updated = { ...(formData.customLinks || {}) };
    delete updated[key];
    setFormData({ ...formData, customLinks: updated });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0e071c] border-2 border-purple-500/50 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl shadow-purple-950/60 overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-purple-500/30 bg-gradient-to-r from-purple-950/80 via-[#180d30] to-purple-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-400 flex items-center justify-center text-purple-300 shadow-lg shadow-purple-900/40">
              <LinkIcon className="w-6 h-6 text-purple-200 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-serif font-black text-white tracking-wide">
                  Central de Atualização de Links & Cliques
                </h3>
                <span className="bg-purple-600/60 border border-purple-400/50 text-purple-100 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                  Admin Master
                </span>
              </div>
              <p className="text-xs text-purple-200/80">
                Altere os links, WhatsApp, salas de vídeo e botões da sua página em tempo real.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-purple-950/60 border border-purple-500/40 hover:bg-purple-900/60 text-purple-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 px-6 py-3 bg-[#080411] border-b border-purple-500/20 overflow-x-auto">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'all'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                : 'text-purple-300 hover:bg-purple-950/50 hover:text-white'
            }`}
          >
            ⚡ Todos os Links
          </button>
          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'whatsapp'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-emerald-300 hover:bg-emerald-950/50'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            WhatsApp & Grupos
          </button>
          <button
            onClick={() => setActiveTab('balloon')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'balloon'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-teal-300 hover:bg-teal-950/50'
            }`}
          >
            <span>🎈 Balão Flutuante</span>
          </button>
          <button
            onClick={() => setActiveTab('video')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'video'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-indigo-300 hover:bg-indigo-950/50'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            Chamada de Vídeo
          </button>
          <button
            onClick={() => setActiveTab('pix')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'pix'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-amber-300 hover:bg-amber-950/50'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            PIX & Valores
          </button>
          <button
            onClick={() => setActiveTab('social')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'social'
                ? 'bg-fuchsia-600 text-white shadow-md'
                : 'text-fuchsia-300 hover:bg-fuchsia-950/50'
            }`}
          >
            <Instagram className="w-3.5 h-3.5" />
            Redes & Canais
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
              activeTab === 'custom'
                ? 'bg-purple-700 text-white shadow-md'
                : 'text-purple-300 hover:bg-purple-950/50'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            Links Personalizados
          </button>
        </div>

        {/* Modal Body / Forms */}
        <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-6 flex-1 text-white">
          
          {/* Section: WhatsApp & Group Links */}
          {(activeTab === 'all' || activeTab === 'whatsapp') && (
            <div className="bg-[#140b27] border border-purple-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-emerald-400">
                <MessageCircle className="w-5 h-5" />
                <h4 className="font-serif font-bold text-base text-white">Links de WhatsApp & Grupo VIP</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Link do Grupo VIP de WhatsApp (Botões Principais)
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      value={formData.groupWhatsAppLink}
                      onChange={(e) => setFormData({ ...formData, groupWhatsAppLink: e.target.value })}
                      placeholder="https://chat.whatsapp.com/..."
                      className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all font-mono"
                      required
                    />
                    {formData.groupWhatsAppLink && (
                      <a
                        href={formData.groupWhatsAppLink}
                        target="_blank"
                        rel="noreferrer"
                        className="absolute right-2.5 top-2.5 text-emerald-400 hover:text-emerald-300"
                        title="Testar Link em nova aba"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Controla os cliques dos botões: "Entrar no Grupo VIP", "Participar do Grupo" e CTA do Hero.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Número de WhatsApp com DDD (Ex: 5511999998888)
                  </label>
                  <input
                    type="text"
                    value={formData.phoneWhatsApp}
                    onChange={(e) => setFormData({ ...formData, phoneWhatsApp: e.target.value.replace(/\D/g, '') })}
                    placeholder="5511999998888"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all font-mono"
                    required
                  />
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Número que recebe as mensagens diretas de consulta, oráculos e suporte 24h.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Section: Balão Flutuante do WhatsApp (Widget Flutuante) */}
          {(activeTab === 'all' || activeTab === 'balloon') && (
            <div className="bg-[#140b27] border-2 border-emerald-500/40 rounded-2xl p-5 space-y-4 shadow-lg shadow-emerald-950/40">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-300">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 fill-emerald-400 text-neutral-950" />
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-base text-white flex items-center gap-2">
                      <span>🎈 Balão Flutuante do WhatsApp (Widget de Canto)</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-400 font-bold">
                        100% Editável
                      </span>
                    </h4>
                    <p className="text-[11px] text-purple-200/80">
                      Configure para onde o visitante vai ao clicar no balão verde flutuante no canto da tela.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Ação ao Clicar no Balão */}
                <div>
                  <label className="block text-xs font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                    O que acontece ao clicar no Balão:
                  </label>
                  <select
                    value={formData.floatingBalloonAction || 'menu'}
                    onChange={(e) => setFormData({ ...formData, floatingBalloonAction: e.target.value as any })}
                    className="w-full bg-[#080411] border border-emerald-500/50 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all cursor-pointer font-sans"
                  >
                    <option value="menu">💬 Abrir Menu Flutuante (Entrar no Grupo, Privado, Lives)</option>
                    <option value="direct_whatsapp">🟢 Abrir Direto o WhatsApp de Atendimento</option>
                    <option value="direct_group">👥 Abrir Direto o Link do Grupo VIP</option>
                    <option value="custom_url">🔗 Abrir Link / URL Personalizada (Qualquer Site)</option>
                  </select>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Defina o comportamento do botão redondo flutuante.
                  </p>
                </div>

                {/* Link Personalizado do Balão */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Link / URL Personalizada do Balão:
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      value={formData.floatingBalloonCustomUrl || ''}
                      onChange={(e) => setFormData({ ...formData, floatingBalloonCustomUrl: e.target.value })}
                      placeholder="https://wa.me/5511... ou https://link.com"
                      className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all font-mono"
                    />
                    {formData.floatingBalloonCustomUrl && (
                      <a
                        href={formData.floatingBalloonCustomUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="absolute right-2.5 top-2.5 text-emerald-400 hover:text-emerald-300"
                        title="Testar Link em nova aba"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Usado se você escolher "Abrir Link / URL Personalizada".
                  </p>
                </div>

                {/* Mensagem Padrão de WhatsApp */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Mensagem Padrão Enviada pelo Balão:
                  </label>
                  <input
                    type="text"
                    value={formData.floatingBalloonDirectMessage || ''}
                    onChange={(e) => setFormData({ ...formData, floatingBalloonDirectMessage: e.target.value })}
                    placeholder="Olá Cartomante 24h! Gostaria de uma consulta online agora."
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all"
                  />
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Texto pré-digitado que o consulente envia para seu WhatsApp.
                  </p>
                </div>

                {/* Etiqueta de Plantão no Balão */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Texto / Aviso no Menu do Balão:
                  </label>
                  <input
                    type="text"
                    value={formData.floatingBalloonNotice || ''}
                    onChange={(e) => setFormData({ ...formData, floatingBalloonNotice: e.target.value })}
                    placeholder="Plantão 24h Ativo (ou 🟢 3 Cartomantes Online)"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all"
                  />
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Frase de destaque que aparece dentro da caixinha do balão.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Section: Video Call & Room Links */}
          {(activeTab === 'all' || activeTab === 'video') && (
            <div className="bg-[#140b27] border border-purple-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-indigo-400">
                <Video className="w-5 h-5" />
                <h4 className="font-serif font-bold text-base text-white">Chamada de Vídeo das Cartomantes</h4>
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                  Link Externo Opcional de Sala de Vídeo (Google Meet, Zoom, Jitsi ou WhatsApp)
                </label>
                <div className="relative">
                  <input
                    type="url"
                    value={formData.videoConsultLink || ''}
                    onChange={(e) => setFormData({ ...formData, videoConsultLink: e.target.value })}
                    placeholder="https://meet.google.com/abc-def-ghi (Deixe vazio para usar a Sala Integrada 24h)"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 transition-all font-mono"
                  />
                  {formData.videoConsultLink && (
                    <a
                      href={formData.videoConsultLink}
                      target="_blank"
                      rel="noreferrer"
                      className="absolute right-2.5 top-2.5 text-indigo-400 hover:text-indigo-300"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Se preenchido, os botões de "Entrar em Vídeo" podem direcionar para sua sala externa ou abrir o simulador de alta tecnologia 24h integrado.
                </p>
              </div>
            </div>
          )}

          {/* Section: PIX & Pricing */}
          {(activeTab === 'all' || activeTab === 'pix') && (
            <div className="bg-[#140b27] border border-purple-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-amber-400">
                <DollarSign className="w-5 h-5" />
                <h4 className="font-serif font-bold text-base text-white">Configuração do PIX & Tabela de Preços</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Valor de 1 Pergunta Direta (R$)
                  </label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    value={formData.price1Question || 20}
                    onChange={(e) => setFormData({ ...formData, price1Question: Number(e.target.value) })}
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white font-bold focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Valor de 3 Perguntas Aprofundadas (R$)
                  </label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    value={formData.price3Questions || 50}
                    onChange={(e) => setFormData({ ...formData, price3Questions: Number(e.target.value) })}
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white font-bold focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Chave PIX (E-mail, CPF, Celular ou Aleatória)
                  </label>
                  <input
                    type="text"
                    value={formData.pixKey}
                    onChange={(e) => setFormData({ ...formData, pixKey: e.target.value })}
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                    Nome do Titular Recebedor PIX
                  </label>
                  <input
                    type="text"
                    value={formData.pixReceiverName}
                    onChange={(e) => setFormData({ ...formData, pixReceiverName: e.target.value })}
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section: Social & External Channels */}
          {(activeTab === 'all' || activeTab === 'social') && (
            <div className="bg-[#140b27] border border-purple-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-fuchsia-400">
                <Instagram className="w-5 h-5" />
                <h4 className="font-serif font-bold text-base text-white">Redes Sociais & Canais de Atendimento</h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Facebook className="w-3.5 h-3.5 text-blue-400" />
                    Facebook Página / Grupo
                  </label>
                  <input
                    type="url"
                    value={formData.facebookLink || ''}
                    onChange={(e) => setFormData({ ...formData, facebookLink: e.target.value })}
                    placeholder="https://facebook.com/cartomante24h"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-blue-400 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Instagram className="w-3.5 h-3.5 text-pink-400" />
                    Instagram Link
                  </label>
                  <input
                    type="url"
                    value={formData.instagramLink || ''}
                    onChange={(e) => setFormData({ ...formData, instagramLink: e.target.value })}
                    placeholder="https://instagram.com/cartomante24h"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-pink-400 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Send className="w-3.5 h-3.5 text-sky-400" />
                    Telegram Canal
                  </label>
                  <input
                    type="url"
                    value={formData.telegramLink || ''}
                    onChange={(e) => setFormData({ ...formData, telegramLink: e.target.value })}
                    placeholder="https://t.me/cartomante24h"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-sky-400 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Youtube className="w-3.5 h-3.5 text-red-400" />
                    YouTube Canal
                  </label>
                  <input
                    type="url"
                    value={formData.youtubeLink || ''}
                    onChange={(e) => setFormData({ ...formData, youtubeLink: e.target.value })}
                    placeholder="https://youtube.com/@cartomante24h"
                    className="w-full bg-[#080411] border border-purple-500/40 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-red-400 transition-all font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section: Custom Dynamic Links */}
          {(activeTab === 'all' || activeTab === 'custom') && (
            <div className="bg-[#140b27] border border-purple-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-purple-300">
                  <Plus className="w-5 h-5 text-purple-400" />
                  <h4 className="font-serif font-bold text-base text-white">Links & Botões Personalizados Extras</h4>
                </div>
                <span className="text-[11px] text-purple-300/80">Sobrescreva qualquer link no clique</span>
              </div>

              {/* Add Custom Link Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3.5 bg-[#080411] border border-purple-500/30 rounded-xl">
                <div className="sm:col-span-4">
                  <input
                    type="text"
                    value={newCustomKey}
                    onChange={(e) => setNewCustomKey(e.target.value)}
                    placeholder="Nome/Identificador (ex: link_parceiro)"
                    className="w-full bg-[#140b27] border border-purple-500/40 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-400"
                  />
                </div>
                <div className="sm:col-span-6">
                  <input
                    type="url"
                    value={newCustomUrl}
                    onChange={(e) => setNewCustomUrl(e.target.value)}
                    placeholder="https://link-de-destino.com"
                    className="w-full bg-[#140b27] border border-purple-500/40 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-400 font-mono"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="button"
                    onClick={handleAddCustomLink}
                    className="w-full h-full bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold py-2 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Adicionar
                  </button>
                </div>
              </div>

              {/* List of custom links */}
              {formData.customLinks && Object.keys(formData.customLinks).length > 0 && (
                <div className="space-y-2 pt-2">
                  {Object.entries(formData.customLinks).map(([key, url]) => (
                    <div key={key} className="flex items-center justify-between p-2.5 bg-[#080411] border border-purple-500/20 rounded-xl">
                      <div className="flex items-center gap-2 overflow-hidden mr-2">
                        <span className="font-bold text-xs text-purple-200 font-mono shrink-0">{key}:</span>
                        <a href={url} target="_blank" rel="noreferrer" className="text-xs text-emerald-300 font-mono truncate hover:underline">
                          {url}
                        </a>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveCustomLink(key)}
                        className="text-red-400 hover:text-red-300 p-1 rounded hover:bg-red-950/40 transition-colors cursor-pointer"
                        title="Remover link"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-4 border-t border-purple-500/30 flex items-center justify-between">
            <p className="text-xs text-purple-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Todas as alterações são salvas e refletidas instantaneamente.</span>
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl border border-purple-500/40 hover:bg-purple-950/60 text-purple-200 text-sm font-semibold transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-gradient-to-r from-purple-600 via-fuchsia-600 to-purple-600 hover:from-purple-500 hover:to-purple-500 text-white text-sm font-bold rounded-xl shadow-lg shadow-purple-900/50 flex items-center gap-2 transition-all hover:scale-[1.02] cursor-pointer"
              >
                {savedSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-300" />
                    <span>Links Atualizados!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Salvar & Atualizar Página</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
}
