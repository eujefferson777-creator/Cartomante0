import { useState, useEffect, type FormEvent } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  MessageCircle, 
  Smartphone, 
  DollarSign, 
  Link2, 
  Settings, 
  RefreshCw, 
  Search, 
  Calendar, 
  MapPin, 
  UserCheck, 
  UserX, 
  Zap, 
  QrCode, 
  ArrowLeft,
  ExternalLink,
  Save,
  Check,
  Edit3,
  Plus,
  Trash2,
  HelpCircle,
  Star,
  FileText,
  Eye,
  Volume2,
  Facebook,
  Share2,
  Copy,
  Download,
  Upload,
  Globe,
  Layers,
  Phone,
  Send
} from 'lucide-react';
import { SiteConfig, UserAccount, CartomanteCandidate, CartomanteProfile, FAQItem, Testimonial } from '../types';
import { 
  subscribeToAllUsers, 
  updateUserApprovalStatus, 
  updateUserMonthlyFeeStatus, 
  updateUserRole,
  subscribeToCartomanteCandidates,
  updateCandidateStatus,
  saveSiteConfigToDb
} from '../lib/firebase';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import { FAQS_DATA } from '../data/faqs';
import { TESTIMONIALS } from '../data/testimonials';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface AdminPageProps {
  config: SiteConfig;
  currentUser: UserAccount | null;
  onSaveConfig: (newConfig: SiteConfig) => void;
  onBackToHome: () => void;
  onOpenCommunity: () => void;
}

export function AdminPage({
  config,
  currentUser,
  onSaveConfig,
  onBackToHome,
  onOpenCommunity
}: AdminPageProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'cms_site' | 'clone_site' | 'cartomantes' | 'users' | 'monthly_fee' | 'links' | 'settings'>('overview');
  
  // Real-time collections state
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [candidates, setCandidates] = useState<CartomanteCandidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [copiedClone, setCopiedClone] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importNotice, setImportNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [cmsSubTab, setCmsSubTab] = useState<'hero_general' | 'cartomantes_cms' | 'faqs_cms' | 'testimonials_cms' | 'footer_cms'>('hero_general');

  // Editable config state
  const [formConfig, setFormConfig] = useState<SiteConfig>({
    ...config,
    siteName: config.siteName || 'Cartomante 24h',
    siteSlogan: config.siteSlogan || 'Tarot Místico & WhatsApp 24h',
    onlineNotice: config.onlineNotice || '🟢 3 Cartomantes de Plantão Online Agora',
    heroBadge: config.heroBadge || 'Plantão Espiritual 24h • Atendimento Imediato Sem Fila',
    heroTitle: config.heroTitle || 'Cartomante 24h Online Chamada de Vídeo & WhatsApp',
    heroSubtitle: config.heroSubtitle || 'Revelações precisas sobre amor, destino e caminhos abertos com as cartas ciganas e o tarot sagrado. Participe do nosso grupo VIP no WhatsApp e faça consultas privativas com valores justos e transparentes.',
    facebookLink: config.facebookLink || 'https://facebook.com/cartomante24h.oficial',
    facebookPageName: config.facebookPageName || 'Cartomante 24h Oficial',
    facebookPixelId: config.facebookPixelId || '',
    cloneDomainUrl: config.cloneDomainUrl || 'https://cartomante24h.online',
    developerWhatsApp: config.developerWhatsApp || '5511999998888',
    monthlyFeeAmount: config.monthlyFeeAmount || 50.0,
    monthlyFeePixKey: config.monthlyFeePixKey || 'financeiro.provedor@cartomante24h.com',
    cartomanteMonthlyFeeAmount: config.cartomanteMonthlyFeeAmount || 50.0,
    cartomanteMonthlyFeePixKey: config.cartomanteMonthlyFeePixKey || config.pixKey || '',
    cartomanteMonthlyFeeReceiverName: config.cartomanteMonthlyFeeReceiverName || config.pixReceiverName || 'Jefferson - Cartomante 24h',
    cartomanteMonthlyFeeCustomMessage: config.cartomanteMonthlyFeeCustomMessage || '',
    price1Question: config.price1Question || 20.0,
    price3Questions: config.price3Questions || 50.0,
    footerAbout: config.footerAbout || 'Atendimento espiritual e oracular 24 horas por dia com absoluto sigilo, acolhimento e respeito. Consultas por chamada de vídeo, WhatsApp e comunidade online.',
    customCartomantes: config.customCartomantes && config.customCartomantes.length > 0 ? config.customCartomantes : CARTOMANTES_PROFILES,
    customFaqs: config.customFaqs && config.customFaqs.length > 0 ? config.customFaqs : FAQS_DATA,
    customTestimonials: config.customTestimonials && config.customTestimonials.length > 0 ? config.customTestimonials : TESTIMONIALS
  });

  // State for adding/editing a cartomante
  const [editingCartomante, setEditingCartomante] = useState<CartomanteProfile | null>(null);
  const [isAddingCartomante, setIsAddingCartomante] = useState(false);
  const [newCartomante, setNewCartomante] = useState<CartomanteProfile>({
    id: `cartomante-${Date.now()}`,
    name: '',
    title: 'Mestra em Baralho Cigano',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    rating: 5.0,
    consultationsCount: 100,
    experienceYears: 10,
    isOnline: true,
    statusText: 'Disponível Agora',
    specialties: ['Amor', 'Prosperidade', 'Baralho Cigano'],
    deckTypes: ['Baralho Cigano', 'Tarot de Marselha'],
    bio: '',
    voiceGreetingText: 'Salve! Seja bem-vindo(a). As cartas têm uma resposta para você.',
    whatsappMessage: 'Olá! Gostaria de uma consulta com você.'
  });

  // State for FAQ item
  const [newFaq, setNewFaq] = useState<FAQItem>({
    id: `faq-${Date.now()}`,
    question: '',
    answer: '',
    category: 'geral'
  });

  // State for Testimonial item
  const [newTestimonial, setNewTestimonial] = useState<Testimonial>({
    id: `test-${Date.now()}`,
    name: '',
    city: 'São Paulo - SP',
    stars: 5,
    date: 'Hoje',
    consultationType: '1 Pergunta Direta',
    comment: '',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    verified: true
  });

  // Subscribe to real users from Firestore
  useEffect(() => {
    const unsubUsers = subscribeToAllUsers((userList) => {
      setUsers(userList);
      setLoading(false);
    });

    const unsubCandidates = subscribeToCartomanteCandidates((candidateList) => {
      setCandidates(candidateList);
    });

    return () => {
      unsubUsers();
      unsubCandidates();
    };
  }, []);

  const handleConfigSubmit = async (e: FormEvent) => {
    e.preventDefault();
    onSaveConfig(formConfig);
    try {
      await saveSiteConfigToDb(formConfig);
      setSaveSuccessMsg('✓ Todas as alterações do site foram salvas no Banco de Dados (Nuvem)!');
      setTimeout(() => setSaveSuccessMsg(''), 4000);
    } catch (err) {
      console.error('Error saving config:', err);
    }
  };

  const toggleCartomantePermission = async (user: UserAccount) => {
    const newStatus = !user.isApprovedByAdmin;
    await updateUserApprovalStatus(user.id, newStatus);
  };

  // Manual activation of 30-day monthly fee for registered cartomante
  const handleActivateCartomanteMonthlyFee = async (id: string, name: string, isUserAccount: boolean) => {
    const nextMonth = new Date();
    nextMonth.setDate(nextMonth.getDate() + 30);
    const nextMonthStr = nextMonth.toISOString();

    if (isUserAccount) {
      await updateUserMonthlyFeeStatus(id, 'pago', nextMonthStr);
      await updateUserApprovalStatus(id, true);
    } else {
      const currentList = formConfig.customCartomantes || CARTOMANTES_PROFILES;
      const updatedList = currentList.map((c) => {
        if (c.id === id) {
          return {
            ...c,
            monthlyFeeStatus: 'pago' as const,
            monthlyFeeDueDate: nextMonthStr
          };
        }
        return c;
      });
      const updatedConfig = { ...formConfig, customCartomantes: updatedList };
      setFormConfig(updatedConfig);
      onSaveConfig(updatedConfig);
      await saveSiteConfigToDb(updatedConfig);
    }

    setSaveSuccessMsg(`✓ Mensalidade de 30 dias ATIVADA com sucesso para ${name}!`);
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Suspend or mark monthly fee as expired for a cartomante
  const handleSuspendCartomanteMonthlyFee = async (id: string, name: string, isUserAccount: boolean) => {
    if (isUserAccount) {
      await updateUserMonthlyFeeStatus(id, 'vencido');
      await updateUserApprovalStatus(id, false);
    } else {
      const currentList = formConfig.customCartomantes || CARTOMANTES_PROFILES;
      const updatedList = currentList.map((c) => {
        if (c.id === id) {
          return {
            ...c,
            monthlyFeeStatus: 'vencido' as const
          };
        }
        return c;
      });
      const updatedConfig = { ...formConfig, customCartomantes: updatedList };
      setFormConfig(updatedConfig);
      onSaveConfig(updatedConfig);
      await saveSiteConfigToDb(updatedConfig);
    }

    setSaveSuccessMsg(`Mensalidade de ${name} marcada como vencida/suspensa.`);
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Update phone number of a cartomante
  const handleUpdateCartomantePhone = async (id: string, phone: string, isUserAccount: boolean) => {
    if (isUserAccount) {
      // User accounts phone is stored in user profile
    } else {
      const currentList = formConfig.customCartomantes || CARTOMANTES_PROFILES;
      const updatedList = currentList.map((c) => (c.id === id ? { ...c, phone } : c));
      const updatedConfig = { ...formConfig, customCartomantes: updatedList };
      setFormConfig(updatedConfig);
      onSaveConfig(updatedConfig);
      await saveSiteConfigToDb(updatedConfig);
    }
    setSaveSuccessMsg(`✓ Telefone de contato salvo com sucesso!`);
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  // Send WhatsApp billing notification directly to registered cartomante
  const handleSendMonthlyFeeWhatsApp = (cartomanteName: string, phone?: string, dueDateStr?: string) => {
    const amount = formConfig.cartomanteMonthlyFeeAmount || 50.0;
    const pix = formConfig.cartomanteMonthlyFeePixKey || formConfig.pixKey || 'Informe sua chave PIX no painel';
    const receiver = formConfig.cartomanteMonthlyFeeReceiverName || formConfig.pixReceiverName || 'Jefferson - Cartomante 24h';
    const dueDate = dueDateStr 
      ? new Date(dueDateStr).toLocaleDateString('pt-BR') 
      : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR');

    const msg = `🔮 *MENSALIDADE CARTOMANTE 24H*\n\n` +
      `Olá *${cartomanteName}*! Tudo bem?\n` +
      `Aqui é o Jefferson, administrador do portal *Cartomante 24h*.\n\n` +
      `Estou enviando os dados para ativação e renovação da sua mensalidade (período de 30 dias de atendimento, lives e divulgação no portal):\n\n` +
      `💰 *Valor da Mensalidade:* R$ ${amount.toFixed(2).replace('.', ',')}\n` +
      `📅 *Vencimento:* ${dueDate}\n` +
      `🔑 *Chave PIX:* ${pix}\n` +
      `👤 *Titular:* ${receiver}\n\n` +
      `Assim que realizar a transferência, por favor envie o comprovante por aqui para eu manter seu perfil 100% ativo e liberado no site!\n\n` +
      `Muito axé e ótimos atendimentos! ✨`;

    const cleanPhone = phone ? phone.replace(/\D/g, '') : '';
    const encoded = encodeURIComponent(msg);
    if (cleanPhone) {
      window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
    } else {
      window.open(`https://wa.me/?text=${encoded}`, '_blank');
    }
  };

  const handleApproveCandidate = async (candidate: CartomanteCandidate) => {
    await updateCandidateStatus(candidate.id, 'aprovado');
  };

  const handleRejectCandidate = async (candidate: CartomanteCandidate) => {
    await updateCandidateStatus(candidate.id, 'rejeitado');
  };

  // Cartomante Management in CMS
  const handleSaveCartomante = () => {
    if (!newCartomante.name.trim()) return;
    const currentList = formConfig.customCartomantes || CARTOMANTES_PROFILES;
    const existingIndex = currentList.findIndex((c) => c.id === newCartomante.id);
    let updatedList: CartomanteProfile[];
    if (existingIndex >= 0) {
      updatedList = [...currentList];
      updatedList[existingIndex] = newCartomante;
    } else {
      updatedList = [...currentList, newCartomante];
    }
    const updatedConfig = { ...formConfig, customCartomantes: updatedList };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
    setIsAddingCartomante(false);
    setEditingCartomante(null);
    setSaveSuccessMsg('Cartomante salva com sucesso!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  const handleDeleteCartomante = (id: string) => {
    const currentList = formConfig.customCartomantes || CARTOMANTES_PROFILES;
    const updatedList = currentList.filter((c) => c.id !== id);
    const updatedConfig = { ...formConfig, customCartomantes: updatedList };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
  };

  // FAQ Management in CMS
  const handleAddFaq = () => {
    if (!newFaq.question.trim() || !newFaq.answer.trim()) return;
    const currentFaqs = formConfig.customFaqs || FAQS_DATA;
    const updatedFaqs = [...currentFaqs, { ...newFaq, id: `faq-${Date.now()}` }];
    const updatedConfig = { ...formConfig, customFaqs: updatedFaqs };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
    setNewFaq({ id: `faq-${Date.now()}`, question: '', answer: '', category: 'geral' });
  };

  const handleDeleteFaq = (id: string) => {
    const currentFaqs = formConfig.customFaqs || FAQS_DATA;
    const updatedFaqs = currentFaqs.filter((f) => f.id !== id);
    const updatedConfig = { ...formConfig, customFaqs: updatedFaqs };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
  };

  // Testimonials Management in CMS
  const handleAddTestimonial = () => {
    if (!newTestimonial.name.trim() || !newTestimonial.comment.trim()) return;
    const currentTests = formConfig.customTestimonials || TESTIMONIALS;
    const updatedTests = [...currentTests, { ...newTestimonial, id: `test-${Date.now()}` }];
    const updatedConfig = { ...formConfig, customTestimonials: updatedTests };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
    setNewTestimonial({
      id: `test-${Date.now()}`,
      name: '',
      city: 'São Paulo - SP',
      stars: 5,
      date: 'Hoje',
      consultationType: '1 Pergunta Direta',
      comment: '',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      verified: true
    });
  };

  const handleDeleteTestimonial = (id: string) => {
    const currentTests = formConfig.customTestimonials || TESTIMONIALS;
    const updatedTests = currentTests.filter((t) => t.id !== id);
    const updatedConfig = { ...formConfig, customTestimonials: updatedTests };
    setFormConfig(updatedConfig);
    onSaveConfig(updatedConfig);
    saveSiteConfigToDb(updatedConfig);
  };

  // Calculations & Metrics
  const cartomantesList = users.filter((u) => u.role === 'cartomante');
  const approvedCartomantes = cartomantesList.filter((u) => u.isApprovedByAdmin);
  const clientsList = users.filter((u) => u.role === 'client');
  const pendingCandidates = candidates.filter((c) => c.status === 'pendente');

  // Unified list of all registered cartomantes (CMS profiles + User accounts)
  const allRegisteredCartomantes = [
    ...(formConfig.customCartomantes || CARTOMANTES_PROFILES).map((c) => ({
      id: c.id,
      name: c.name,
      avatar: c.avatar,
      phone: c.phone || '',
      monthlyFeeStatus: c.monthlyFeeStatus || 'pendente',
      monthlyFeeDueDate: c.monthlyFeeDueDate || '',
      isUserAccount: false,
      title: c.title || 'Cartomante de Plantão'
    })),
    ...users
      .filter(
        (u) =>
          u.role === 'cartomante' &&
          !(formConfig.customCartomantes || CARTOMANTES_PROFILES).some(
            (c) => c.id === u.id || c.name.toLowerCase() === u.name.toLowerCase()
          )
      )
      .map((u) => ({
        id: u.id,
        name: u.name,
        avatar: u.avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
        phone: u.phone || '',
        monthlyFeeStatus: u.monthlyFeeStatus || (u.isApprovedByAdmin ? 'pago' : 'pendente'),
        monthlyFeeDueDate: u.monthlyFeeDueDate || '',
        isUserAccount: true,
        title: 'Cartomante Cadastrada'
      }))
  ];

  // Filtered users for search
  const filteredUsers = users.filter((u) => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.phone && u.phone.includes(searchTerm)) ||
    (u.city && u.city.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const developerPhone = formConfig.developerWhatsApp || '5511999998888';
  const openDeveloperWhatsApp = (message: string) => {
    window.open(`https://wa.me/${developerPhone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleCopyCloneJson = () => {
    const cloneData = JSON.stringify(formConfig, null, 2);
    navigator.clipboard.writeText(cloneData);
    setCopiedClone(true);
    setTimeout(() => setCopiedClone(false), 3000);
  };

  const handleDownloadCloneJson = () => {
    const cloneData = JSON.stringify(formConfig, null, 2);
    const blob = new Blob([cloneData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cartomante24h-clone-config-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportCloneJson = async (e: FormEvent) => {
    e.preventDefault();
    setImportNotice(null);
    try {
      if (!importJsonText.trim()) {
        setImportNotice({ type: 'error', message: 'Cole o código JSON do clone para importar.' });
        return;
      }
      const parsed = JSON.parse(importJsonText);
      if (typeof parsed !== 'object' || parsed === null) {
        throw new Error('Formato JSON inválido.');
      }
      const updatedConfig: SiteConfig = {
        ...formConfig,
        ...parsed,
        siteName: parsed.siteName || formConfig.siteName,
        phoneWhatsApp: parsed.phoneWhatsApp || formConfig.phoneWhatsApp,
        groupWhatsAppLink: parsed.groupWhatsAppLink || formConfig.groupWhatsAppLink,
        facebookLink: parsed.facebookLink || formConfig.facebookLink,
        facebookPageName: parsed.facebookPageName || formConfig.facebookPageName,
        facebookPixelId: parsed.facebookPixelId || formConfig.facebookPixelId,
        cloneDomainUrl: parsed.cloneDomainUrl || formConfig.cloneDomainUrl,
        pixKey: parsed.pixKey || formConfig.pixKey,
        price1Question: parsed.price1Question || 20.0,
        price3Questions: parsed.price3Questions || 50.0
      };
      setFormConfig(updatedConfig);
      await saveSiteConfigToDb(updatedConfig);
      onSaveConfig(updatedConfig);
      setImportNotice({ type: 'success', message: '🎉 Configurações do Clone importadas e sincronizadas com sucesso!' });
      setImportJsonText('');
    } catch (err: any) {
      setImportNotice({ type: 'error', message: `Erro ao importar JSON: ${err.message || 'Código inválido'}` });
    }
  };

  const openFacebookShareTest = () => {
    const urlToShare = formConfig.cloneDomainUrl || window.location.origin;
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(urlToShare)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#070312] text-white flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="bg-gradient-to-r from-purple-950 via-[#120728] to-neutral-950 border-b border-purple-500/30 sticky top-0 z-40 px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 border border-purple-500/30 text-purple-200 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Voltar ao Site</span>
          </button>
          
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif font-black text-base sm:text-lg text-white">
                  Painel de Controle Master • Jefferson
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-bold">
                  ADMIN OFICIAL
                </span>
              </div>
              <p className="text-[11px] text-purple-200/70">
                Edite todo o conteúdo do site, cartomantes, usuários reais, links e valores em tempo real na nuvem
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCommunity}
            className="px-3.5 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/60 border border-purple-500/40 text-purple-200 text-xs font-semibold transition-all cursor-pointer"
          >
            Ir para Comunidade
          </button>
        </div>
      </header>

      {/* Main Admin Navigation Tabs */}
      <div className="bg-[#0b051c] border-b border-purple-500/20 px-4 sm:px-8 py-2.5 overflow-x-auto">
        <div className="flex gap-2 max-w-7xl mx-auto min-w-max">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" /> Visão Geral & Métricas
          </button>

          <button
            onClick={() => setActiveTab('cms_site')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'cms_site'
                ? 'bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white shadow-lg font-black'
                : 'text-amber-300 hover:bg-purple-900/40 border border-amber-500/30'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" /> 📝 Editar Todo o Site (CMS)
          </button>

          <button
            onClick={() => setActiveTab('clone_site')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'clone_site'
                ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white shadow-lg font-black'
                : 'text-blue-300 hover:bg-blue-950/60 border border-blue-500/40'
            }`}
          >
            <Facebook className="w-3.5 h-3.5 text-blue-400" /> 🌐 Clonar Site & Facebook
          </button>

          <button
            onClick={() => setActiveTab('cartomantes')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'cartomantes'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Cartomantes & Permissões ({cartomantesList.length})
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'users'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" /> Usuários Reais ({users.length})
          </button>

          <button
            onClick={() => setActiveTab('monthly_fee')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'monthly_fee'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" /> 💰 Ativar & Cobrar Mensalidades ({allRegisteredCartomantes.length})
          </button>

          <button
            onClick={() => setActiveTab('links')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'links'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <Link2 className="w-3.5 h-3.5" /> Central de Links & WhatsApp
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-amber-400 text-neutral-950 shadow-md font-black'
                : 'text-purple-200 hover:bg-purple-900/40 hover:text-white'
            }`}
          >
            <Settings className="w-3.5 h-3.5" /> Configurações & PIX
          </button>
        </div>
      </div>

      {/* Main Admin Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {saveSuccessMsg && (
          <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-emerald-200 text-sm flex items-center gap-2.5 shadow-lg animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold">{saveSuccessMsg}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB: CMS VISUAL / EDITAR O SITE TODO */}
        {/* ========================================================================= */}
        {activeTab === 'cms_site' && (
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-gradient-to-r from-[#170932] via-[#200e42] to-[#120726] border border-purple-500/40 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold mb-2">
                  <Edit3 className="w-3.5 h-3.5" /> CMS Visual do Administrador
                </div>
                <h3 className="text-2xl font-serif font-black text-white">
                  Edite Qualquer Texto, Cartomante, FAQ ou Depoimento do Site
                </h3>
                <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-2xl">
                  Todas as mudanças feitas aqui ficam gravadas no banco de dados Firebase na nuvem e continuam funcionando quando o site for hospedado ou exportado!
                </p>
              </div>

              <button
                onClick={handleConfigSubmit}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 font-black text-sm flex items-center gap-2 shadow-xl cursor-pointer transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Salvar Tudo na Nuvem</span>
              </button>
            </div>

            {/* CMS Sub-Tabs Navigation */}
            <div className="flex gap-2 border-b border-purple-500/20 pb-3 overflow-x-auto">
              <button
                onClick={() => setCmsSubTab('hero_general')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  cmsSubTab === 'hero_general'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-black/40 text-purple-300 hover:text-white'
                }`}
              >
                🔮 Textos do Topo & Hero
              </button>

              <button
                onClick={() => setCmsSubTab('cartomantes_cms')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  cmsSubTab === 'cartomantes_cms'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-black/40 text-purple-300 hover:text-white'
                }`}
              >
                ✨ Cartomantes do Site ({(formConfig.customCartomantes || []).length})
              </button>

              <button
                onClick={() => setCmsSubTab('faqs_cms')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  cmsSubTab === 'faqs_cms'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-black/40 text-purple-300 hover:text-white'
                }`}
              >
                ❓ Dúvidas Frequentes (FAQ) ({(formConfig.customFaqs || []).length})
              </button>

              <button
                onClick={() => setCmsSubTab('testimonials_cms')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  cmsSubTab === 'testimonials_cms'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-black/40 text-purple-300 hover:text-white'
                }`}
              >
                ⭐ Depoimentos de Clientes ({(formConfig.customTestimonials || []).length})
              </button>

              <button
                onClick={() => setCmsSubTab('footer_cms')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  cmsSubTab === 'footer_cms'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-black/40 text-purple-300 hover:text-white'
                }`}
              >
                📜 Rodapé & Sobre o Portal
              </button>
            </div>

            {/* Sub-tab 1: Hero & Textos Principais */}
            {cmsSubTab === 'hero_general' && (
              <form onSubmit={handleConfigSubmit} className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
                <h4 className="font-serif font-bold text-lg text-white">Editar Títulos e Textos Principais</h4>
                <div className="space-y-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Nome do Portal / Logo</label>
                    <input
                      type="text"
                      value={formConfig.siteName}
                      onChange={(e) => setFormConfig({ ...formConfig, siteName: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Slogan</label>
                    <input
                      type="text"
                      value={formConfig.siteSlogan}
                      onChange={(e) => setFormConfig({ ...formConfig, siteSlogan: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Texto de Aviso no Topo (Plantão)</label>
                    <input
                      type="text"
                      value={formConfig.onlineNotice}
                      onChange={(e) => setFormConfig({ ...formConfig, onlineNotice: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Badge do Topo do Hero</label>
                    <input
                      type="text"
                      value={formConfig.heroBadge}
                      onChange={(e) => setFormConfig({ ...formConfig, heroBadge: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Título Principal do Hero (H1)</label>
                    <input
                      type="text"
                      value={formConfig.heroTitle}
                      onChange={(e) => setFormConfig({ ...formConfig, heroTitle: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Subtítulo do Hero</label>
                    <textarea
                      rows={3}
                      value={formConfig.heroSubtitle}
                      onChange={(e) => setFormConfig({ ...formConfig, heroSubtitle: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Salvar Textos no Banco</span>
                  </button>
                </div>
              </form>
            )}

            {/* Sub-tab 2: Cartomantes CMS Editor */}
            {cmsSubTab === 'cartomantes_cms' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h4 className="font-serif font-bold text-lg text-white">Cartomantes Exibidas no Site</h4>
                  <button
                    onClick={() => {
                      setNewCartomante({
                        id: `cartomante-${Date.now()}`,
                        name: '',
                        title: 'Mestra em Baralho Cigano',
                        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
                        rating: 5.0,
                        consultationsCount: 150,
                        experienceYears: 12,
                        isOnline: true,
                        statusText: 'Disponível no Plantão',
                        specialties: ['Amor', 'Baralho Cigano'],
                        deckTypes: ['Baralho Cigano'],
                        bio: '',
                        voiceGreetingText: 'Salve! Estou pronta para revelar seus caminhos.',
                        whatsappMessage: 'Olá! Gostaria de consultar com você.'
                      });
                      setIsAddingCartomante(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-lg"
                  >
                    <Plus className="w-4 h-4" /> Adicionar Nova Cartomante
                  </button>
                </div>

                {/* Form to Add / Edit Cartomante */}
                {(isAddingCartomante || editingCartomante) && (
                  <div className="p-6 rounded-3xl bg-[#160a2f] border border-amber-500/40 space-y-4 shadow-2xl animate-fadeIn">
                    <h5 className="font-bold text-base text-amber-300">
                      {editingCartomante ? 'Editar Perfil da Cartomante' : 'Criar Nova Cartomante no Site'}
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-purple-200 mb-1">Nome Místico / Cartomante</label>
                        <input
                          type="text"
                          required
                          value={newCartomante.name}
                          onChange={(e) => setNewCartomante({ ...newCartomante, name: e.target.value })}
                          placeholder="Ex: Mestra Helena do Oriente"
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-purple-200 mb-1">Título / Especialidade Principal</label>
                        <input
                          type="text"
                          value={newCartomante.title}
                          onChange={(e) => setNewCartomante({ ...newCartomante, title: e.target.value })}
                          placeholder="Ex: Especialista em Amor & Baralho Cigano"
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-purple-200 mb-1">URL da Foto de Perfil</label>
                        <input
                          type="url"
                          value={newCartomante.avatar}
                          onChange={(e) => setNewCartomante({ ...newCartomante, avatar: e.target.value })}
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-purple-200 mb-1">Anos de Experiência</label>
                        <input
                          type="number"
                          value={newCartomante.experienceYears}
                          onChange={(e) => setNewCartomante({ ...newCartomante, experienceYears: Number(e.target.value) })}
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-purple-200 mb-1">Biografia / Apresentação</label>
                        <textarea
                          rows={2}
                          value={newCartomante.bio}
                          onChange={(e) => setNewCartomante({ ...newCartomante, bio: e.target.value })}
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white resize-none"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-purple-200 mb-1">Texto da Mensagem de Voz / Saudação em Áudio</label>
                        <input
                          type="text"
                          value={newCartomante.voiceGreetingText}
                          onChange={(e) => setNewCartomante({ ...newCartomante, voiceGreetingText: e.target.value })}
                          className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={handleSaveCartomante}
                        className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl cursor-pointer"
                      >
                        Salvar Cartomante
                      </button>
                      <button
                        onClick={() => {
                          setIsAddingCartomante(false);
                          setEditingCartomante(null);
                        }}
                        className="px-4 py-2.5 bg-black/40 hover:bg-black/60 text-purple-300 text-xs rounded-xl cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                )}

                {/* List of Custom Cartomantes */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {(formConfig.customCartomantes || CARTOMANTES_PROFILES).map((c) => (
                    <div
                      key={c.id}
                      className="p-4 rounded-2xl bg-[#0f0723] border border-purple-500/30 flex flex-col justify-between gap-3 shadow-lg"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={c.avatar}
                          alt={c.name}
                          className="w-12 h-12 rounded-full object-cover border border-purple-400"
                        />
                        <div>
                          <h5 className="font-bold text-white text-sm">{c.name}</h5>
                          <span className="text-[11px] text-purple-300 block">{c.title}</span>
                          <span className="text-[10px] text-amber-300 font-semibold">{c.experienceYears} anos de dons</span>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2 border-t border-purple-500/20">
                        <button
                          onClick={() => {
                            setNewCartomante(c);
                            setEditingCartomante(c);
                            setIsAddingCartomante(true);
                          }}
                          className="flex-1 py-1.5 bg-purple-900/50 hover:bg-purple-800 text-purple-200 text-xs font-bold rounded-xl cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" /> Editar
                        </button>
                        <button
                          onClick={() => handleDeleteCartomante(c.id)}
                          className="p-1.5 px-3 bg-rose-950/60 hover:bg-rose-900 text-rose-300 text-xs rounded-xl cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sub-tab 3: FAQ CMS Editor */}
            {cmsSubTab === 'faqs_cms' && (
              <div className="space-y-6">
                <div className="p-6 rounded-3xl bg-[#160a2f] border border-purple-500/30 space-y-4">
                  <h4 className="font-bold text-sm text-white uppercase tracking-wider">Adicionar Nova Pergunta Frequente</h4>
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder="Pergunta (Ex: Como recebo minhas cartas?)"
                      value={newFaq.question}
                      onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white"
                    />
                    <textarea
                      rows={2}
                      placeholder="Resposta explicativa..."
                      value={newFaq.answer}
                      onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white resize-none"
                    />
                    <button
                      onClick={handleAddFaq}
                      className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center gap-1.5 shadow"
                    >
                      <Plus className="w-4 h-4" /> Adicionar Pergunta
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  {(formConfig.customFaqs || FAQS_DATA).map((faq) => (
                    <div
                      key={faq.id}
                      className="p-4 rounded-2xl bg-[#0f0723] border border-purple-500/20 flex items-start justify-between gap-4"
                    >
                      <div>
                        <h5 className="font-bold text-sm text-white">{faq.question}</h5>
                        <p className="text-xs text-purple-200/80 mt-1 leading-relaxed">{faq.answer}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteFaq(faq.id)}
                        className="p-2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-xl cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sub-tab 4: Testimonials CMS Editor */}
            {cmsSubTab === 'testimonials_cms' && (
              <div className="space-y-6">
                <div className="p-6 rounded-3xl bg-[#160a2f] border border-purple-500/30 space-y-4">
                  <h4 className="font-bold text-sm text-white uppercase tracking-wider">Adicionar Depoimento Real</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Nome do Cliente (Ex: Juliana F.)"
                      value={newTestimonial.name}
                      onChange={(e) => setNewTestimonial({ ...newTestimonial, name: e.target.value })}
                      className="px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Cidade (Ex: Rio de Janeiro - RJ)"
                      value={newTestimonial.city}
                      onChange={(e) => setNewTestimonial({ ...newTestimonial, city: e.target.value })}
                      className="px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Tipo (Ex: 1 Pergunta Direta)"
                      value={newTestimonial.consultationType}
                      onChange={(e) => setNewTestimonial({ ...newTestimonial, consultationType: e.target.value })}
                      className="px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white"
                    />
                    <div className="sm:col-span-3">
                      <textarea
                        rows={2}
                        placeholder="Comentário do cliente..."
                        value={newTestimonial.comment}
                        onChange={(e) => setNewTestimonial({ ...newTestimonial, comment: e.target.value })}
                        className="w-full px-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white resize-none"
                      />
                    </div>
                  </div>
                  <button
                    onClick={handleAddTestimonial}
                    className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center gap-1.5 shadow"
                  >
                    <Plus className="w-4 h-4" /> Adicionar Depoimento
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(formConfig.customTestimonials || TESTIMONIALS).map((t) => (
                    <div
                      key={t.id}
                      className="p-4 rounded-2xl bg-[#0f0723] border border-purple-500/20 flex flex-col justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-xs">{t.name} • {t.city}</span>
                          <span className="text-amber-300 text-xs font-bold">★ {t.stars}.0</span>
                        </div>
                        <p className="text-xs text-purple-100 italic mt-2">"{t.comment}"</p>
                      </div>
                      <div className="flex justify-end pt-2 border-t border-purple-500/10">
                        <button
                          onClick={() => handleDeleteTestimonial(t.id)}
                          className="px-3 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-300 text-xs rounded-lg cursor-pointer"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sub-tab 5: Footer & About CMS */}
            {cmsSubTab === 'footer_cms' && (
              <form onSubmit={handleConfigSubmit} className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
                <h4 className="font-serif font-bold text-lg text-white">Editar Texto do Rodapé & Sigilo</h4>
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">Texto de Apresentação no Rodapé</label>
                  <textarea
                    rows={4}
                    value={formConfig.footerAbout}
                    onChange={(e) => setFormConfig({ ...formConfig, footerAbout: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Salvar Rodapé
                </button>
              </form>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB: CLONAR SITE & OPÇÃO DO FACEBOOK */}
        {/* ========================================================================= */}
        {activeTab === 'clone_site' && (
          <div className="space-y-6">
            {/* Header Banner */}
            <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-950 via-[#100c30] to-purple-950 border border-blue-500/40 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold">
                  <Facebook className="w-3.5 h-3.5 text-blue-400" /> Clonador de Site & Integração com Facebook
                </div>
                <h3 className="text-xl sm:text-2xl font-serif font-black text-white">
                  Clonagem do Site Cartomante 24h & Opção de Facebook
                </h3>
                <p className="text-xs sm:text-sm text-purple-200/80 max-w-2xl">
                  Configure os dados do Facebook que serão exibidos no site e nos compartilhamentos ao clonar. Gere o pacote completo do site (WhatsApp, PIX, Cartomantes, FAQs e Facebook) para replicar em qualquer domínio.
                </p>
              </div>

              <div className="flex flex-wrap gap-2.5 shrink-0">
                <button
                  onClick={handleCopyCloneJson}
                  className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
                >
                  {copiedClone ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedClone ? 'Código Copiado!' : 'Copiar Dados do Clone'}</span>
                </button>

                <button
                  onClick={handleDownloadCloneJson}
                  className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Baixar JSON</span>
                </button>
              </div>
            </div>

            {/* Status Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-[#0f0723] border border-blue-500/30">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-blue-300">Página do Facebook</span>
                  <Facebook className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-sm font-bold text-white truncate">
                  {formConfig.facebookPageName || 'Cartomante 24h Oficial'}
                </div>
                <span className="text-[11px] text-emerald-400 font-semibold block mt-1">
                  {formConfig.facebookLink ? '✓ Link Ativo' : '⚠ Link padrão'}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#0f0723] border border-purple-500/30">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-purple-300">Domínio do Clone</span>
                  <Globe className="w-4 h-4 text-purple-400" />
                </div>
                <div className="text-sm font-bold text-white truncate font-mono">
                  {formConfig.cloneDomainUrl || 'https://cartomante24h.online'}
                </div>
                <span className="text-[11px] text-purple-300/70 block mt-1">
                  Destino do Clone
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#0f0723] border border-emerald-500/30">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-emerald-300">WhatsApp Vinculado</span>
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-sm font-bold text-white font-mono">
                  {formConfig.phoneWhatsApp}
                </div>
                <span className="text-[11px] text-emerald-400 block mt-1">
                  Atendimento Automático
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#0f0723] border border-amber-500/30">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-amber-300">Tabela de Preços</span>
                  <DollarSign className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-sm font-bold text-amber-300">
                  R$ {formConfig.price1Question?.toFixed(2)} / R$ {formConfig.price3Questions?.toFixed(2)}
                </div>
                <span className="text-[11px] text-purple-200/70 block mt-1">
                  1 Pergunta & 3 Perguntas
                </span>
              </div>
            </div>

            {/* Grid: Facebook Configuration & Social Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column: Facebook & Clone Settings Form */}
              <form onSubmit={handleConfigSubmit} className="p-6 rounded-3xl bg-[#0f0723] border border-blue-500/40 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-blue-400 border-b border-blue-500/20 pb-3">
                    <Facebook className="w-5 h-5" />
                    <h4 className="font-serif font-bold text-base text-white">Opções do Facebook para o Clone</h4>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Facebook className="w-3.5 h-3.5 text-blue-400" />
                      Link da Página ou Grupo no Facebook
                    </label>
                    <input
                      type="url"
                      value={formConfig.facebookLink || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, facebookLink: e.target.value })}
                      placeholder="https://facebook.com/cartomante24h.oficial"
                      className="w-full bg-[#070312] border border-blue-500/40 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-blue-400 font-mono transition-all"
                    />
                    <span className="text-[11px] text-purple-300/70 mt-1 block">
                      Este link aparecerá no cabeçalho, rodapé e nos botões de contato do Facebook.
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                      Nome da Página no Facebook
                    </label>
                    <input
                      type="text"
                      value={formConfig.facebookPageName || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, facebookPageName: e.target.value })}
                      placeholder="Cartomante 24h Oficial"
                      className="w-full bg-[#070312] border border-purple-500/40 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-amber-400 transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5">
                      ID do Pixel do Facebook (Meta Ads Pixel)
                    </label>
                    <input
                      type="text"
                      value={formConfig.facebookPixelId || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, facebookPixelId: e.target.value })}
                      placeholder="Ex: 849201948201948"
                      className="w-full bg-[#070312] border border-purple-500/40 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-amber-400 font-mono transition-all"
                    />
                    <span className="text-[11px] text-purple-300/70 mt-1 block">
                      Opcional para campanhas de anúncios pagos no Facebook e Instagram.
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-purple-400" />
                      Domínio Oficial do Clone
                    </label>
                    <input
                      type="url"
                      value={formConfig.cloneDomainUrl || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, cloneDomainUrl: e.target.value })}
                      placeholder="https://cartomante24h.online"
                      className="w-full bg-[#070312] border border-purple-500/40 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-neutral-600 focus:outline-none focus:border-amber-400 font-mono transition-all"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-purple-500/20">
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl cursor-pointer transition-all"
                  >
                    <Save className="w-4 h-4" />
                    <span>Salvar Opções de Facebook & Clone no Banco</span>
                  </button>
                </div>
              </form>

              {/* Right Column: Visual Facebook Share & Post Preview */}
              <div className="p-6 rounded-3xl bg-[#0f0723] border border-blue-500/40 space-y-4">
                <div className="flex items-center justify-between border-b border-blue-500/20 pb-3">
                  <div className="flex items-center gap-2 text-blue-400">
                    <Eye className="w-5 h-5" />
                    <h4 className="font-serif font-bold text-base text-white">Visualização do Card no Facebook</h4>
                  </div>
                  <span className="text-[11px] text-blue-300 font-semibold px-2.5 py-0.5 rounded-full bg-blue-500/20">
                    Feed / Compartilhamento
                  </span>
                </div>

                {/* Facebook Mock Post */}
                <div className="bg-[#18191a] border border-neutral-700/60 rounded-2xl p-4 text-white shadow-xl space-y-3 font-sans">
                  {/* Post Top Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-full bg-purple-950 border border-purple-400/50 overflow-hidden shrink-0">
                        <img
                          src={catLogo}
                          alt="Logo Místico"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-neutral-100 flex items-center gap-1">
                          <span>{formConfig.facebookPageName || 'Cartomante 24h Oficial'}</span>
                          <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-[9px] flex items-center justify-center text-white font-bold">✓</span>
                        </div>
                        <div className="text-[11px] text-neutral-400 flex items-center gap-1">
                          <span>Publicado agora</span>
                          <span>•</span>
                          <Globe className="w-3 h-3" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Post Text */}
                  <p className="text-xs text-neutral-200 leading-relaxed">
                    🔮 <strong>{formConfig.heroTitle || 'Cartomante 24h Online • Chamada de Vídeo & WhatsApp'}</strong>
                    <br />
                    Atendimento imediato 24h com Baralho Cigano e Tarot sagrado. 1 Pergunta por R$ {formConfig.price1Question?.toFixed(2)} e 3 Perguntas por R$ {formConfig.price3Questions?.toFixed(2)}. Participe do nosso grupo VIP!
                  </p>

                  {/* OpenGraph Link Card */}
                  <a
                    href={formConfig.cloneDomainUrl || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block bg-[#242526] hover:bg-[#2e2f30] border border-neutral-700/80 rounded-xl overflow-hidden transition-all group"
                  >
                    <div className="h-44 w-full bg-[#0a0418] relative overflow-hidden flex items-center justify-center">
                      <img
                        src={catLogo}
                        alt="Preview Cartomante 24h"
                        className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-3">
                        <span className="px-2 py-0.5 rounded-md bg-purple-600/90 text-white text-[10px] font-black uppercase tracking-wider">
                          Plantão 24H Online
                        </span>
                      </div>
                    </div>

                    <div className="p-3.5 space-y-1">
                      <span className="text-[10px] text-neutral-400 uppercase font-mono tracking-wider block">
                        {(formConfig.cloneDomainUrl || 'cartomante24h.online').replace(/^https?:\/\//, '')}
                      </span>
                      <h5 className="font-bold text-xs sm:text-sm text-neutral-100 line-clamp-1 group-hover:text-blue-400 transition-colors">
                        {formConfig.heroTitle || 'Cartomante 24h Online - Chamada de Vídeo & WhatsApp'}
                      </h5>
                      <p className="text-[11px] text-neutral-400 line-clamp-2">
                        {formConfig.heroSubtitle || 'Revelações com Baralho Cigano e Tarot sagrado sem fila 24 horas por dia.'}
                      </p>
                    </div>
                  </a>

                  {/* Post Bottom Action Buttons */}
                  <div className="pt-2 border-t border-neutral-700/60 flex items-center justify-around text-xs font-semibold text-neutral-300">
                    <button
                      type="button"
                      onClick={openFacebookShareTest}
                      className="hover:text-blue-400 flex items-center gap-1.5 transition-colors cursor-pointer py-1"
                    >
                      <Share2 className="w-3.5 h-3.5" /> Compartilhar
                    </button>

                    {formConfig.facebookLink && (
                      <a
                        href={formConfig.facebookLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-blue-400 flex items-center gap-1.5 transition-colors cursor-pointer py-1"
                      >
                        <Facebook className="w-3.5 h-3.5 text-blue-400" /> Abrir Página Facebook
                      </a>
                    )}
                  </div>
                </div>

                {/* Quick Share Testing Actions */}
                <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={openFacebookShareTest}
                    className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow transition-all cursor-pointer"
                  >
                    <Facebook className="w-4 h-4" />
                    <span>Testar Compartilhamento Oficial</span>
                  </button>

                  {formConfig.facebookLink && (
                    <a
                      href={formConfig.facebookLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2.5 rounded-xl bg-[#140b27] hover:bg-[#1a0f33] border border-blue-500/40 text-blue-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Ver Página</span>
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* Section: Import & Export Clone Engine */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Export Box */}
              <div className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-purple-300">
                    <Layers className="w-5 h-5 text-purple-400" />
                    <h4 className="font-serif font-bold text-base text-white">Código de Exportação do Clone</h4>
                  </div>
                  <span className="text-[11px] text-purple-300/80">Payload JSON Completo</span>
                </div>

                <p className="text-xs text-purple-200/80">
                  Copie o código JSON abaixo para colar em outra instalação do Cartomante 24h. Ele inclui todos os textos, cartomantes, Facebook, PIX e links configurados.
                </p>

                <div className="relative">
                  <textarea
                    readOnly
                    rows={7}
                    value={JSON.stringify(formConfig, null, 2)}
                    className="w-full bg-[#05020c] border border-purple-500/30 rounded-xl p-3 text-[11px] text-purple-200 font-mono focus:outline-none resize-none"
                  />
                  <button
                    type="button"
                    onClick={handleCopyCloneJson}
                    className="absolute top-2.5 right-2.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold flex items-center gap-1 shadow cursor-pointer transition-all"
                  >
                    {copiedClone ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedClone ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
              </div>

              {/* Import Box */}
              <form onSubmit={handleImportCloneJson} className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-amber-300">
                    <Upload className="w-5 h-5 text-amber-400" />
                    <h4 className="font-serif font-bold text-base text-white">Importar Configuração Clonada</h4>
                  </div>
                  <span className="text-[11px] text-amber-400 font-bold">1-Clique</span>
                </div>

                <p className="text-xs text-purple-200/80">
                  Cole o código JSON exportado de outro site para sincronizar e aplicar tudo instantaneamente neste portal:
                </p>

                {importNotice && (
                  <div className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    importNotice.type === 'success'
                      ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-200'
                      : 'bg-red-950/80 border border-red-500/50 text-red-200'
                  }`}>
                    {importNotice.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />}
                    <span>{importNotice.message}</span>
                  </div>
                )}

                <textarea
                  rows={5}
                  value={importJsonText}
                  onChange={(e) => setImportJsonText(e.target.value)}
                  placeholder="Cole aqui o código JSON do clone..."
                  className="w-full bg-[#05020c] border border-purple-500/30 rounded-xl p-3 text-[11px] text-white font-mono focus:outline-none focus:border-amber-400 resize-none placeholder-neutral-600"
                />

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow cursor-pointer transition-all"
                >
                  <Upload className="w-4 h-4" />
                  <span>Importar & Ativar Clone no Banco</span>
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 1: OVERVIEW & REAL-TIME STATS */}
        {/* ========================================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Developer Monthly Notification Banner */}
            <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950 via-[#180936] to-amber-950/70 border border-amber-500/40 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold">
                  <Clock className="w-3.5 h-3.5" /> Status da Mensalidade & Suporte do Provedor
                </div>
                <h3 className="text-xl sm:text-2xl font-serif font-black text-white">
                  Desenvolvimento & Hospedagem 24 Horas
                </h3>
                <p className="text-xs sm:text-sm text-purple-200/80 max-w-2xl">
                  Ao completar 1 mês de uso, mantenha seu site ativo e atualizado falando diretamente com o provedor/desenvolvedor responsável pelo sistema.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 shrink-0">
                <button
                  onClick={() => openDeveloperWhatsApp('Olá! Sou o Jefferson administrador do Cartomante 24h e gostaria de tratar sobre a renovação mensal e suporte do site.')}
                  className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Falar com o Provedor no WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#0f0723] border border-purple-500/30 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-purple-300">Total Usuários Reais</span>
                  <Users className="w-5 h-5 text-purple-400" />
                </div>
                <div className="text-3xl font-black text-white">{users.length}</div>
                <span className="text-[11px] text-emerald-400 font-semibold block mt-1">
                  ✓ Com verificação de celular
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-[#0f0723] border border-purple-500/30 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-300">Cartomantes Autorizadas</span>
                  <Sparkles className="w-5 h-5 text-amber-400" />
                </div>
                <div className="text-3xl font-black text-amber-300">{approvedCartomantes.length}</div>
                <span className="text-[11px] text-purple-200/70 block mt-1">
                  de {cartomantesList.length} cadastradas
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-[#0f0723] border border-purple-500/30 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-300">Consulentes (Clientes)</span>
                  <UserCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="text-3xl font-black text-emerald-400">{clientsList.length}</div>
                <span className="text-[11px] text-purple-200/70 block mt-1">
                  Prontos para consultar
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-[#0f0723] border border-purple-500/30 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-300">Inscrições Pendentes</span>
                  <Clock className="w-5 h-5 text-amber-400" />
                </div>
                <div className="text-3xl font-black text-white">{pendingCandidates.length}</div>
                <span className="text-[11px] text-amber-400 font-semibold block mt-1">
                  No Trabalhe Conosco
                </span>
              </div>
            </div>

            {/* Quick Actions Shortcuts */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={() => setActiveTab('cms_site')}
                className="p-5 rounded-2xl bg-[#13092b] border border-purple-500/30 hover:border-purple-400 text-left transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-purple-600/40 flex items-center justify-center text-white mb-3 group-hover:scale-110 transition-transform">
                  <Edit3 className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-white">Editar Textos & Fotos do Site Todo</h4>
                <p className="text-xs text-purple-200/70 mt-1">
                  Modifique títulos, cartomantes, fotos, valores e depoimentos salvando na nuvem.
                </p>
              </button>

              <button
                onClick={() => setActiveTab('cartomantes')}
                className="p-5 rounded-2xl bg-[#13092b] border border-purple-500/30 hover:border-amber-400/60 text-left transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-purple-900/50 flex items-center justify-center text-amber-300 mb-3 group-hover:scale-110 transition-transform">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-white">Autorizar Cartomantes para Trabalhar</h4>
                <p className="text-xs text-purple-200/70 mt-1">
                  Permita ou desative cartomantes para que possam atender e fazer lives no portal.
                </p>
              </button>

              <button
                onClick={() => setActiveTab('monthly_fee')}
                className="p-5 rounded-2xl bg-[#13092b] border border-purple-500/30 hover:border-amber-400/60 text-left transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-950 flex items-center justify-center text-emerald-400 mb-3 group-hover:scale-110 transition-transform">
                  <DollarSign className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-sm text-white">Gestão da Mensalidade de 30 Dias</h4>
                <p className="text-xs text-purple-200/70 mt-1">
                  Acompanhe a taxa de desenvolvimento e pagamentos das mensalidades.
                </p>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: CARTOMANTES & PERMISSIONS */}
        {/* ========================================================================= */}
        {activeTab === 'cartomantes' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-serif font-bold text-xl text-white">
                  Gerenciamento de Cartomantes & Permissão de Trabalho
                </h3>
                <p className="text-xs text-purple-200/80 mt-1">
                  Por regra de segurança, uma cartomante só pode atender e realizar lives se você autorizar.
                </p>
              </div>
            </div>

            {/* Candidates from "Trabalhe Conosco" */}
            {candidates.length > 0 && (
              <div className="p-6 rounded-3xl bg-[#12082b] border border-purple-500/30 space-y-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <h4 className="font-bold text-sm text-amber-300 uppercase tracking-wider">
                    Candidatas Inscritas no Portal ({candidates.length})
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {candidates.map((cand) => (
                    <div
                      key={cand.id}
                      className="p-4 rounded-2xl bg-black/40 border border-purple-500/20 flex flex-col justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <h5 className="font-bold text-white text-sm">{cand.name}</h5>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              cand.status === 'aprovado'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : cand.status === 'rejeitado'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            }`}
                          >
                            {cand.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-xs text-purple-200/70 mt-1">{cand.email} • 📱 {cand.phone}</p>
                        <p className="text-xs text-purple-100 mt-2 bg-purple-950/40 p-2.5 rounded-xl border border-purple-500/20">
                          {cand.bio || 'Sem biografia informada.'}
                        </p>
                        {cand.groupLink && (
                          <a
                            href={cand.groupLink}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-emerald-400 hover:underline flex items-center gap-1 mt-2"
                          >
                            <ExternalLink className="w-3 h-3" /> Grupo WhatsApp da Cartomante
                          </a>
                        )}
                      </div>

                      <div className="flex gap-2 pt-2 border-t border-purple-500/20">
                        {cand.status !== 'aprovado' && (
                          <button
                            onClick={() => handleApproveCandidate(cand)}
                            className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl cursor-pointer transition-all"
                          >
                            Aprovar Candidatura
                          </button>
                        )}
                        {cand.status !== 'rejeitado' && (
                          <button
                            onClick={() => handleRejectCandidate(cand)}
                            className="py-1.5 px-3 bg-rose-900/60 hover:bg-rose-800 text-rose-200 text-xs rounded-xl cursor-pointer transition-all"
                          >
                            Recusar
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* List of Cartomante Accounts */}
            <div className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
              <h4 className="font-bold text-sm text-purple-200 uppercase tracking-wider">
                Cartomantes com Cadastro no Banco de Dados
              </h4>

              {cartomantesList.length === 0 ? (
                <p className="text-xs text-purple-300/70 py-6 text-center">
                  Nenhuma conta com perfil de cartomante cadastrada até o momento.
                </p>
              ) : (
                <div className="space-y-3">
                  {cartomantesList.map((cartomante) => (
                    <div
                      key={cartomante.id}
                      className="p-4 rounded-2xl bg-black/40 border border-purple-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={cartomante.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                          alt={cartomante.name}
                          className="w-12 h-12 rounded-full border-2 border-purple-400/50 object-cover"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <h5 className="font-bold text-white text-sm">{cartomante.name}</h5>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                cartomante.isApprovedByAdmin
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              }`}
                            >
                              {cartomante.isApprovedByAdmin ? 'AUTORIZADA A TRABALHAR' : 'BLOQUEADA / PENDENTE'}
                            </span>
                          </div>
                          <p className="text-xs text-purple-200/70">
                            {cartomante.email} • 📱 {cartomante.phone || 'Sem telefone'} • Signo: {cartomante.astrologicalSign}
                          </p>
                          <p className="text-[11px] text-purple-300/80 mt-1">
                            Status Mensalidade: <strong className="text-amber-300">{cartomante.monthlyFeeStatus || 'pago'}</strong>
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <button
                          onClick={() => toggleCartomantePermission(cartomante)}
                          className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            cartomante.isApprovedByAdmin
                              ? 'bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-500/40'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg'
                          }`}
                        >
                          {cartomante.isApprovedByAdmin ? 'Suspender Atuação' : 'Permitir Trabalhar'}
                        </button>

                        <button
                          onClick={() => updateUserRole(cartomante.id, 'client')}
                          className="px-3 py-2 rounded-xl bg-purple-900/40 hover:bg-purple-900/80 text-purple-300 text-xs font-semibold cursor-pointer"
                        >
                          Tornar Consulente
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: REAL USERS & CLIENTS */}
        {/* ========================================================================= */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-serif font-bold text-xl text-white">
                  Base de Dados de Usuários & Consulentes Reais ({users.length})
                </h3>
                <p className="text-xs text-purple-200/80 mt-1">
                  Todos os usuários cadastrados com validação de celular, data de nascimento e localização.
                </p>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar por nome, email, cel..."
                  className="w-full pl-10 pr-4 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="bg-[#0f0723] border border-purple-500/30 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-purple-100">
                  <thead className="bg-purple-950/80 text-purple-200 uppercase font-bold border-b border-purple-500/20 text-[11px]">
                    <tr>
                      <th className="p-4">Usuário</th>
                      <th className="p-4">Tipo / Papel</th>
                      <th className="p-4">Celular / WhatsApp</th>
                      <th className="p-4">Nascimento</th>
                      <th className="p-4">Localização</th>
                      <th className="p-4">Data Cadastro</th>
                      <th className="p-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-purple-500/10">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-purple-900/20 transition-colors">
                        <td className="p-4 flex items-center gap-3">
                          <img
                            src={u.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name)}`}
                            alt={u.name}
                            className="w-9 h-9 rounded-full object-cover border border-purple-400/40 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-white block">{u.name}</span>
                            <span className="text-[11px] text-purple-300/70">{u.email}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              u.role === 'admin'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                                : u.role === 'cartomante'
                                ? 'bg-purple-500/20 text-purple-300 border border-purple-400/40'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                            }`}
                          >
                            {u.role.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-4 font-mono text-purple-200">
                          {u.phone ? (
                            <span className="flex items-center gap-1 text-emerald-300">
                              <Smartphone className="w-3.5 h-3.5" /> {u.phone}
                            </span>
                          ) : (
                            <span className="text-neutral-500">Não informado</span>
                          )}
                        </td>
                        <td className="p-4 text-purple-200">{u.birthDate || '—'}</td>
                        <td className="p-4 text-purple-200">
                          {u.city ? `${u.city} - ${u.state || 'UF'}` : '—'}
                        </td>
                        <td className="p-4 text-purple-300/70">
                          {u.createdAt ? new Date(u.createdAt).toLocaleDateString('pt-BR') : 'Hoje'}
                        </td>
                        <td className="p-4 text-right">
                          {u.role !== 'admin' && (
                            <select
                              value={u.role}
                              onChange={(e) => updateUserRole(u.id, e.target.value as any)}
                              className="bg-black/60 border border-purple-500/30 rounded-lg px-2 py-1 text-xs text-purple-200"
                            >
                              <option value="client">Consulente</option>
                              <option value="cartomante">Cartomante</option>
                            </select>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: MANUAL CARTOMANTE MONTHLY FEE ACTIVATION & WHATSAPP DISPATCH */}
        {/* ========================================================================= */}
        {activeTab === 'monthly_fee' && (
          <div className="space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#12082b] via-[#1a0c3b] to-black border border-amber-500/40 shadow-2xl space-y-6">
              {/* Header */}
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-purple-500/20">
                <div>
                  <div className="inline-flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                    <DollarSign className="w-4 h-4" />
                    Controle de Mensalidades das Cartomantes • 30 Dias
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-serif font-black text-white">
                    Ativar e Cobrar Mensalidades das Cartomantes
                  </h3>
                  <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-2xl">
                    Você tem controle total para <strong className="text-emerald-300">ativar o período de 30 dias</strong> de cada cartomante cadastrada e <strong className="text-amber-300">enviar a cobrança oficial no WhatsApp</strong> dela com sua chave PIX e valor.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-bold text-xs">
                    {allRegisteredCartomantes.length} Cartomantes Cadastradas
                  </span>
                </div>
              </div>

              {/* Step 1: Configure Fee & PIX */}
              <div className="p-5 rounded-2xl bg-black/50 border border-purple-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    1. Dados da Mensalidade que Você Cobra das Cartomantes:
                  </h4>
                  <button
                    type="button"
                    onClick={handleConfigSubmit}
                    className="px-4 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow transition-all"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Salvar Dados</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Valor da Mensalidade (R$)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formConfig.cartomanteMonthlyFeeAmount || 50.0}
                      onChange={(e) =>
                        setFormConfig({
                          ...formConfig,
                          cartomanteMonthlyFeeAmount: parseFloat(e.target.value) || 0
                        })
                      }
                      className="w-full bg-black/70 border border-purple-500/40 rounded-xl px-3.5 py-2 text-sm text-white font-mono focus:border-amber-400 outline-none"
                    />
                    <span className="text-[10px] text-purple-300/70 block mt-1">
                      Valor cobrado de cada cartomante por 30 dias
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Sua Chave PIX (Para Elas Pagarem Você)
                    </label>
                    <input
                      type="text"
                      value={formConfig.cartomanteMonthlyFeePixKey || ''}
                      onChange={(e) =>
                        setFormConfig({
                          ...formConfig,
                          cartomanteMonthlyFeePixKey: e.target.value
                        })
                      }
                      placeholder="Ex: seu email, CPF ou telefone"
                      className="w-full bg-black/70 border border-purple-500/40 rounded-xl px-3.5 py-2 text-sm text-white font-mono focus:border-amber-400 outline-none"
                    />
                    <span className="text-[10px] text-purple-300/70 block mt-1">
                      Chave PIX do Jefferson inserida na mensagem
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Nome do Titular do PIX
                    </label>
                    <input
                      type="text"
                      value={formConfig.cartomanteMonthlyFeeReceiverName || ''}
                      onChange={(e) =>
                        setFormConfig({
                          ...formConfig,
                          cartomanteMonthlyFeeReceiverName: e.target.value
                        })
                      }
                      placeholder="Ex: Jefferson - Cartomante 24h"
                      className="w-full bg-black/70 border border-purple-500/40 rounded-xl px-3.5 py-2 text-sm text-white focus:border-amber-400 outline-none"
                    />
                    <span className="text-[10px] text-purple-300/70 block mt-1">
                      Nome que aparece no comprovante PIX
                    </span>
                  </div>
                </div>
              </div>

              {/* Step 2: Registered Cartomantes List with Activation & WhatsApp Dispatch */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    2. Cartomantes Cadastradas (Ativar Acesso & Enviar Cobrança):
                  </h4>
                  <span className="text-xs text-purple-300">
                    Clique em <strong className="text-emerald-300">Ativar</strong> para conceder 30 dias ou <strong className="text-amber-300">Mandar no WhatsApp</strong>
                  </span>
                </div>

                <div className="space-y-3.5">
                  {allRegisteredCartomantes.map((c) => {
                    const isPaid = c.monthlyFeeStatus === 'pago';
                    const dueDateFormatted = c.monthlyFeeDueDate 
                      ? new Date(c.monthlyFeeDueDate).toLocaleDateString('pt-BR') 
                      : 'Não ativada';

                    return (
                      <div
                        key={c.id}
                        className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 ${
                          isPaid
                            ? 'bg-[#100720]/80 border-emerald-500/40 shadow-lg'
                            : 'bg-[#12061e]/80 border-purple-500/30'
                        }`}
                      >
                        {/* Cartomante Identity & Contact */}
                        <div className="flex items-start sm:items-center gap-3.5 min-w-0">
                          <img
                            src={c.avatar}
                            alt={c.name}
                            className="w-13 h-13 rounded-2xl object-cover border-2 border-purple-400/40 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h5 className="font-bold text-sm sm:text-base text-white truncate">
                                {c.name}
                              </h5>
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                                  isPaid
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                }`}
                              >
                                {isPaid ? '🟢 Ativa (30 Dias)' : '🟡 Aguardando Ativação'}
                              </span>
                            </div>

                            <p className="text-xs text-purple-300/80 truncate">{c.title}</p>

                            <div className="flex items-center gap-2 text-xs pt-1 flex-wrap">
                              <span className="text-purple-200/90 font-medium">
                                📅 Vencimento: <strong className="text-white font-mono">{dueDateFormatted}</strong>
                              </span>

                              {/* Phone editable inline */}
                              <div className="flex items-center gap-1.5 ml-0 sm:ml-2">
                                <span className="text-[11px] text-purple-300">📱 WhatsApp:</span>
                                <input
                                  type="text"
                                  defaultValue={c.phone}
                                  placeholder="5511999998888"
                                  onBlur={(e) => handleUpdateCartomantePhone(c.id, e.target.value, c.isUserAccount)}
                                  className="w-32 bg-black/60 border border-purple-500/30 rounded-lg px-2 py-0.5 text-xs text-emerald-300 font-mono focus:border-emerald-400 outline-none"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Control Buttons for Jefferson */}
                        <div className="flex items-center gap-2.5 flex-wrap w-full lg:w-auto justify-end pt-2 lg:pt-0 border-t lg:border-t-0 border-purple-500/20">
                          {/* Button: Activate 30-Day Monthly Fee */}
                          <button
                            type="button"
                            onClick={() => handleActivateCartomanteMonthlyFee(c.id, c.name, c.isUserAccount)}
                            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950/40 cursor-pointer transition-all hover:scale-[1.02]"
                            title="Ativa o acesso por 30 dias para a cartomante atender no site"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Ativar Mensalidade (30 Dias)</span>
                          </button>

                          {/* Button: Send WhatsApp Billing */}
                          <button
                            type="button"
                            onClick={() => handleSendMonthlyFeeWhatsApp(c.name, c.phone, c.monthlyFeeDueDate)}
                            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-amber-950/40 cursor-pointer transition-all hover:scale-[1.02]"
                            title="Abre o WhatsApp dela com a mensagem de cobrança pronta contendo valor e sua chave PIX"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Mandar no WhatsApp</span>
                          </button>

                          {/* Button: Suspend / Expired */}
                          {isPaid && (
                            <button
                              type="button"
                              onClick={() => handleSuspendCartomanteMonthlyFee(c.id, c.name, c.isUserAccount)}
                              className="px-3 py-2.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/40 text-red-300 hover:text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-all"
                              title="Marcar como vencida / suspensa"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Suspender</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Message Model Box Preview */}
              <div className="p-4.5 rounded-2xl bg-[#090312] border border-purple-500/30 text-xs space-y-2">
                <span className="font-bold text-amber-300 flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5" />
                  Modelo da mensagem automática enviada no WhatsApp das cartomantes:
                </span>
                <p className="text-purple-200/80 font-mono text-[11px] whitespace-pre-line bg-black/60 p-3 rounded-xl border border-purple-500/20">
                  {`🔮 *MENSALIDADE CARTOMANTE 24H*\n\nOlá [Nome da Cartomante]! Tudo bem?\nAqui é o Jefferson, administrador do portal *Cartomante 24h*.\n\nEstou enviando os dados para ativação e renovação da sua mensalidade (período de 30 dias de atendimento, lives e divulgação no portal):\n\n💰 *Valor da Mensalidade:* R$ ${(formConfig.cartomanteMonthlyFeeAmount || 50).toFixed(2).replace('.', ',')}\n📅 *Vencimento:* [Data em 30 dias]\n🔑 *Chave PIX:* ${formConfig.cartomanteMonthlyFeePixKey || 'Sua Chave PIX'}\n👤 *Titular:* ${formConfig.cartomanteMonthlyFeeReceiverName || 'Jefferson - Cartomante 24h'}\n\nAssim que realizar a transferência, por favor envie o comprovante por aqui para eu manter seu perfil 100% ativo e liberado no site!\n\nMuito axé e ótimos atendimentos! ✨`}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: LINKS & WHATSAPP REDIRECTION MANAGER */}
        {/* ========================================================================= */}
        {activeTab === 'links' && (
          <form onSubmit={handleConfigSubmit} className="space-y-6">
            <div className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
              <h3 className="font-serif font-bold text-xl text-white">
                Central de Links do WhatsApp & Grupos de Plantão
              </h3>
              <p className="text-xs text-purple-200/80">
                Altere aqui os links oficiais para onde os botões do site levam os consulentes.
              </p>

              <div className="space-y-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Link do Grupo Oficial de WhatsApp das Cartomantes 24h
                  </label>
                  <input
                    type="url"
                    value={formConfig.groupWhatsAppLink}
                    onChange={(e) => setFormConfig({ ...formConfig, groupWhatsAppLink: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Número de WhatsApp Principal (Plantão)
                  </label>
                  <input
                    type="text"
                    value={formConfig.phoneWhatsApp}
                    onChange={(e) => setFormConfig({ ...formConfig, phoneWhatsApp: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    WhatsApp do Desenvolvedor / Provedor (Suporte Técnico)
                  </label>
                  <input
                    type="text"
                    value={formConfig.developerWhatsApp}
                    onChange={(e) => setFormConfig({ ...formConfig, developerWhatsApp: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold text-blue-300 mb-1 flex items-center gap-1.5">
                      <Facebook className="w-3.5 h-3.5 text-blue-400" />
                      Link da Página ou Grupo do Facebook
                    </label>
                    <input
                      type="url"
                      value={formConfig.facebookLink || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, facebookLink: e.target.value })}
                      placeholder="https://facebook.com/cartomante24h.oficial"
                      className="w-full px-4 py-2.5 bg-black/50 border border-blue-500/40 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-blue-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Pixel ID do Facebook (Meta Ads)
                    </label>
                    <input
                      type="text"
                      value={formConfig.facebookPixelId || ''}
                      onChange={(e) => setFormConfig({ ...formConfig, facebookPixelId: e.target.value })}
                      placeholder="Ex: 123456789012345"
                      className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>
                </div>

                {/* Balão Flutuante do WhatsApp */}
                <div className="mt-4 p-4.5 rounded-2xl bg-[#140b27] border-2 border-emerald-500/40 space-y-4">
                  <div className="flex items-center gap-2 text-emerald-300">
                    <MessageCircle className="w-5 h-5 fill-emerald-400 text-neutral-950" />
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-2">
                        <span>🎈 Balão Flutuante do WhatsApp (Widget do Canto da Tela)</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-400 font-bold">
                          Totalmente Editável
                        </span>
                      </h4>
                      <p className="text-[11px] text-purple-200/80">
                        Defina o link e o que acontece quando o visitante clica no botão flutuante redondo verde.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-emerald-300 mb-1">
                        Ação ao Clicar no Balão Flutuante:
                      </label>
                      <select
                        value={formConfig.floatingBalloonAction || 'menu'}
                        onChange={(e) => setFormConfig({ ...formConfig, floatingBalloonAction: e.target.value as any })}
                        className="w-full px-4 py-2.5 bg-black/50 border border-emerald-500/50 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-400 font-sans cursor-pointer"
                      >
                        <option value="menu">💬 Abrir Menu (Entrar no Grupo, Privado, Lives)</option>
                        <option value="direct_whatsapp">🟢 Abrir Direto o WhatsApp Oficial</option>
                        <option value="direct_group">👥 Abrir Direto o Grupo VIP de Cartomantes</option>
                        <option value="custom_url">🔗 Abrir Link / URL Personalizada</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Link / URL Personalizada do Balão (Opcional):
                      </label>
                      <input
                        type="url"
                        value={formConfig.floatingBalloonCustomUrl || ''}
                        onChange={(e) => setFormConfig({ ...formConfig, floatingBalloonCustomUrl: e.target.value })}
                        placeholder="https://wa.me/5511... ou https://link.com"
                        className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-400 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Mensagem Pré-Digitada do WhatsApp no Balão:
                      </label>
                      <input
                        type="text"
                        value={formConfig.floatingBalloonDirectMessage || ''}
                        onChange={(e) => setFormConfig({ ...formConfig, floatingBalloonDirectMessage: e.target.value })}
                        placeholder="Olá Cartomante 24h! Gostaria de consultar online agora."
                        className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Texto de Aviso / Status dentro do Balão:
                      </label>
                      <input
                        type="text"
                        value={formConfig.floatingBalloonNotice || ''}
                        onChange={(e) => setFormConfig({ ...formConfig, floatingBalloonNotice: e.target.value })}
                        placeholder="Plantão 24h Ativo"
                        className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-400"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Salvar Links no Banco de Dados</span>
                </button>
              </div>
            </div>
          </form>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: SETTINGS & PIX CONFIGURATION */}
        {/* ========================================================================= */}
        {activeTab === 'settings' && (
          <form onSubmit={handleConfigSubmit} className="space-y-6">
            <div className="p-6 rounded-3xl bg-[#0f0723] border border-purple-500/30 space-y-4">
              <h3 className="font-serif font-bold text-xl text-white">
                Configurações Gerais de Valores & PIX
              </h3>
              <p className="text-xs text-purple-200/80">
                Configure os 2 valores oficiais do site (1 pergunta e 3 perguntas) e os dados de recebimento PIX.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Valor de 1 Pergunta (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formConfig.price1Question}
                    onChange={(e) => setFormConfig({ ...formConfig, price1Question: Number(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Valor de 3 Perguntas (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formConfig.price3Questions}
                    onChange={(e) => setFormConfig({ ...formConfig, price3Questions: Number(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Chave PIX do Site
                  </label>
                  <input
                    type="text"
                    value={formConfig.pixKey}
                    onChange={(e) => setFormConfig({ ...formConfig, pixKey: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Nome do Titular Recebedor no PIX
                  </label>
                  <input
                    type="text"
                    value={formConfig.pixReceiverName}
                    onChange={(e) => setFormConfig({ ...formConfig, pixReceiverName: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Cidade do Titular PIX
                  </label>
                  <input
                    type="text"
                    value={formConfig.pixCity}
                    onChange={(e) => setFormConfig({ ...formConfig, pixCity: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1">
                    Texto do Aviso do Plantão no Topo
                  </label>
                  <input
                    type="text"
                    value={formConfig.onlineNotice}
                    onChange={(e) => setFormConfig({ ...formConfig, onlineNotice: e.target.value })}
                    className="w-full px-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Salvar Dados de Recebimento no Banco</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </main>
    </div>
  );
}
