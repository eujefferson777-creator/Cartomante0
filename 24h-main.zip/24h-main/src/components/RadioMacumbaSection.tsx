import React from 'react';
import { Radio, Play, Pause, Music, Flame, Sparkles, Volume2, ShieldCheck, Heart, Headphones } from 'lucide-react';
import { RADIO_STATIONS } from '../data/radioStations';
import { RadioStation } from '../types';

interface RadioMacumbaSectionProps {
  onOpenRadioPlayer: () => void;
}

export function RadioMacumbaSection({ onOpenRadioPlayer }: RadioMacumbaSectionProps) {
  const [activeStationId, setActiveStationId] = React.useState<string>(RADIO_STATIONS[0].id);
  const [isPlaying, setIsPlaying] = React.useState<boolean>(false);

  const handlePlayStation = (station: RadioStation) => {
    setActiveStationId(station.id);
    setIsPlaying(true);
    onOpenRadioPlayer();
  };

  return (
    <section id="radio-macumba" className="py-14 bg-gradient-to-b from-[#0b0318] via-[#120524] to-[#0a0314] text-white relative overflow-hidden border-t border-purple-500/20 scroll-mt-20">
      {/* Mystical glow circles */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 via-red-500/20 to-purple-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider mb-4 shadow-lg shadow-amber-950/40">
            <Radio className="w-4 h-4 text-amber-400 animate-spin" />
            <span>TRANSMISSÃO DE AXÉ & ESPIRITUALIDADE 24H NO AR</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-black text-white leading-tight mb-4">
            Rádio Macumba & Espiritualidades
          </h2>

          <p className="text-sm sm:text-base text-purple-200/90 leading-relaxed">
            Sintonize toques sagrados de curimba, atabaques de Umbanda e Candomblé, músicas da egrégora do Povo Cigano, tambores xamânicos e frequências de cura para elevar sua vibração enquanto consulta as cartas.
          </p>
        </div>

        {/* Station Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
          {RADIO_STATIONS.map((st) => {
            const isThisPlaying = isPlaying && activeStationId === st.id;
            return (
              <div
                key={st.id}
                className="bg-[#140827]/80 hover:bg-[#1c0c37] border border-purple-500/30 hover:border-purple-400/60 rounded-3xl p-5 shadow-xl transition-all duration-300 flex flex-col justify-between group relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-colors" />

                <div>
                  {/* Top image & frequency badge */}
                  <div className="relative h-40 rounded-2xl overflow-hidden mb-4 border border-purple-500/30">
                    <img
                      src={st.coverImage}
                      alt={st.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0e041e] via-black/40 to-transparent" />
                    
                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-xl bg-black/70 backdrop-blur-md border border-white/20 text-[10px] font-bold text-amber-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                      <span>{st.frequency}</span>
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-purple-200">
                      <span className="font-semibold text-white truncate drop-shadow-md">
                        {st.tracks.length} Pontos Gravados
                      </span>
                    </div>
                  </div>

                  <h3 className="text-lg font-serif font-black text-white mb-1.5 group-hover:text-amber-300 transition-colors">
                    {st.name}
                  </h3>
                  
                  <p className="text-xs text-purple-300/80 mb-3 line-clamp-2">
                    {st.description}
                  </p>

                  {/* Sample Track Badge */}
                  <div className="p-2.5 rounded-xl bg-black/40 border border-purple-500/20 text-[11px] text-purple-200 flex items-center gap-2 mb-4">
                    <Music className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">
                      <strong>Tocando agora:</strong> {st.tracks[0].title}
                    </span>
                  </div>
                </div>

                {/* Play Button */}
                <button
                  onClick={() => handlePlayStation(st)}
                  className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg ${
                    isThisPlaying
                      ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-amber-950/50 animate-pulse'
                      : 'bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white shadow-purple-950/50'
                  }`}
                >
                  {isThisPlaying ? (
                    <>
                      <Pause className="w-4 h-4 fill-current" />
                      <span>Ouvindo Agora • Pausar</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>Sintonizar Esta Rádio ao Vivo</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner with Quick CTA */}
        <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950/90 via-[#1c0b38] to-purple-950/90 border border-purple-500/40 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-serif font-black text-white">
                Ouça enquanto faz sua consulta com os Cartomantes
              </h4>
              <p className="text-xs text-purple-200/80">
                A música sagrada ajuda a firmar os pensamentos e sintonizar os espíritos de luz.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenRadioPlayer}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-red-950/50 flex items-center gap-2 shrink-0 cursor-pointer"
          >
            <Radio className="w-4 h-4" />
            <span>Abrir Rádio Macumba Completa</span>
          </button>
        </div>

      </div>
    </section>
  );
}
