import { Moon, MessageCircle, Video, ShieldCheck, Heart, ArrowUp, Facebook, Instagram, Send, Youtube } from 'lucide-react';
import { SiteConfig } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface FooterProps {
  config: SiteConfig;
  onOpenWhatsAppGroup: () => void;
  onOpenLives: () => void;
  onOpenAdmin: () => void;
}

export function Footer({ config, onOpenWhatsAppGroup, onOpenLives, onOpenAdmin }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const facebookUrl = config.facebookLink || 'https://facebook.com/cartomante24h.oficial';
  const instagramUrl = config.instagramLink || 'https://instagram.com/cartomante24h';

  return (
    <footer className="bg-[#05020c] border-t border-purple-500/30 text-purple-200/70 text-xs relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#0e051c] border border-purple-500/50 overflow-hidden flex items-center justify-center shadow-md shadow-purple-950/40">
                <img
                  src={catLogo}
                  alt="Logo Gatinho Místico - Cartomante 24h"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-lg font-serif font-black text-white">CARTOMANTE 24H</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              {config.footerAbout || 'Atendimento espiritual e oracular online 24 horas por dia. Lives com cartomantes, Rádio Macumba e comunidade VIP no WhatsApp.'}
            </p>
            
            {/* Social Media Links */}
            <div className="pt-2 flex items-center gap-2.5">
              {facebookUrl && (
                <a
                  href={facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-xl bg-blue-950/60 hover:bg-blue-600 border border-blue-500/40 hover:border-blue-400 text-blue-300 hover:text-white flex items-center justify-center transition-all shadow-md cursor-pointer"
                  title="Página Oficial do Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              )}
              {instagramUrl && (
                <a
                  href={instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-xl bg-pink-950/60 hover:bg-pink-600 border border-pink-500/40 hover:border-pink-400 text-pink-300 hover:text-white flex items-center justify-center transition-all shadow-md cursor-pointer"
                  title="Instagram Oficial"
                >
                  <Instagram className="w-4 h-4" />
                </a>
              )}
              {config.groupWhatsAppLink && (
                <a
                  href={config.groupWhatsAppLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-xl bg-emerald-950/60 hover:bg-emerald-600 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 hover:text-white flex items-center justify-center transition-all shadow-md cursor-pointer"
                  title="Grupo VIP no WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              )}
            </div>

            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-[11px] pt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping"></span>
              <span>Plantão 24h Ativo</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-2">Serviços Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#valores" className="hover:text-purple-300 transition-colors">Tabela de Valores Cobrados</a>
              </li>
              <li>
                <button onClick={onOpenLives} className="hover:text-red-300 transition-colors text-left cursor-pointer flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                  <span>Lives ao Vivo com Cartomantes</span>
                </button>
              </li>
              <li>
                <a href="#radio-macumba" className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  📻 Rádio Macumba & Espiritualidades
                </a>
              </li>
              <li>
                <a href="#oraculo-gratis" className="hover:text-purple-300 transition-colors">Tiragem Grátis da Carta do Dia</a>
              </li>
              <li>
                <button onClick={onOpenWhatsAppGroup} className="hover:text-emerald-300 transition-colors text-left cursor-pointer">
                  Entrar no Grupo VIP do WhatsApp
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Oráculos e Baralhos */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-2">Oráculos Sagrados</h4>
            <ul className="space-y-2 text-purple-200/70">
              <li>• Baralho Cigano Lenormand (36 Cartas)</li>
              <li>• Tarot de Marselha & Linha do Amor</li>
              <li>• Tarot dos Orixás & Abertura de Caminhos</li>
              <li>• Mesa Real 360° & Previsão 6 Meses</li>
            </ul>
          </div>

          {/* Col 4: Sigilo e Config */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-2">Sigilo & Garantia</h4>
            <p className="text-[11px] leading-relaxed text-purple-200/70">
              Atendimento estritamente ético, confidencial e respeitoso. Suas informações e vídeos nunca são gravados ou compartilhados.
            </p>
            <button
              onClick={onOpenAdmin}
              className="text-[11px] text-purple-300 hover:text-white underline block cursor-pointer"
            >
              Configurar dados do WhatsApp / PIX
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-purple-500/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-purple-300/60">
          <p>© {new Date().getFullYear()} Cartomante 24h. Todos os direitos reservados. Feito com amor e fé.</p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 hover:text-purple-300 transition-colors cursor-pointer"
          >
            <span>Voltar ao topo</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
