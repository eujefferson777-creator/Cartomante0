import React, { useState, useEffect, useRef } from 'react';
import { 
  Gamepad2, 
  Sparkles, 
  RotateCw, 
  Trophy, 
  Heart, 
  Shield, 
  Coins, 
  Crown, 
  Eye, 
  RefreshCw, 
  MessageCircle, 
  Star, 
  Check, 
  Dice5,
  Flame,
  Zap,
  HelpCircle,
  Award,
  Gift
} from 'lucide-react';
import { CartomanteProfile, SiteConfig } from '../types';

interface MysticalGamesSectionProps {
  config: SiteConfig;
  onSelectCartomanteToPlay?: (cartomante?: CartomanteProfile, count?: 1 | 3) => void;
  onJoinGroup?: () => void;
}

// 1. DATA: Roleta da Fortuna
interface WheelSector {
  label: string;
  color: string;
  textColor: string;
  icon: string;
  title: string;
  message: string;
  luckyNumbers: string;
  luckyColor: string;
  powerAffirmation: string;
}

const WHEEL_SECTORS: WheelSector[] = [
  {
    label: 'Caminhos Abertos',
    color: '#d97706', // amber-600
    textColor: '#ffffff',
    icon: '🌟',
    title: 'Abertura Plena de Portas e Negócios',
    message: 'A falange dos caçadores e de Ogum limpa a estrada à sua frente. Um nó antigo na sua vida financeira ou profissional está se desatando nesta semana.',
    luckyNumbers: '07 • 14 • 28 • 33 • 49',
    luckyColor: 'Dourado / Amarelo Solar',
    powerAffirmation: 'Eu sou digno da fartura e recebo todos os caminhos abertos pelo universo com gratidão!'
  },
  {
    label: 'Amor & Reconciliação',
    color: '#dc2626', // red-600
    textColor: '#ffffff',
    icon: '❤️',
    title: 'Magnetismo e Renovação Afetiva',
    message: 'A vibração de Pomba Gira Menina e Oxum envolve seu campo áurico. Uma conversa sincera ou reaproximação trará a paz e a segurança que você tanto pede.',
    luckyNumbers: '03 • 12 • 21 • 36 • 45',
    luckyColor: 'Vermelho Rosado / Cobre',
    powerAffirmation: 'Meu coração vibra em paz e atrai o amor verdadeiro, recíproco e protetor!'
  },
  {
    label: 'Prosperidade & Ouro',
    color: '#eab308', // yellow-500
    textColor: '#1a1003',
    icon: '💰',
    title: 'Colheita Abençoada e Multiplicação',
    message: 'O Povo Cigano espalha moedas douradas sob seus pés. Confie no seu valor, finalize pendências e prepare-se para uma entrada imprevista de dinheiro.',
    luckyNumbers: '08 • 16 • 24 • 40 • 56',
    luckyColor: 'Verde Esmeralda e Ouro',
    powerAffirmation: 'O dinheiro flui para a minha vida de fontes honestas, puras e multiplicadoras!'
  },
  {
    label: 'Proteção dos Orixás',
    color: '#2563eb', // blue-600
    textColor: '#ffffff',
    icon: '🛡️',
    title: 'Escudo Espiritual de Ogum e Iansã',
    message: 'Nenhuma inveja, palavra contrária ou olho gordo tem força para derrubar quem é guardado pela egrégora. Seu anjo da guarda ergueu muralhas de aço.',
    luckyNumbers: '01 • 09 • 19 • 37 • 70',
    luckyColor: 'Azul Escuro / Prata',
    powerAffirmation: 'Nenhuma flecha invisível me atinge; estou coberto pelo manto sagrado da justiça!'
  },
  {
    label: 'Paz & Serenidade',
    color: '#059669', // emerald-600
    textColor: '#ffffff',
    icon: '🕊️',
    title: 'Cura Emocional e Alívio da Alma',
    message: 'As águas doces de Oxum e o carinho dos Pretos Velhos tiram o peso do seu peito. Respire em paz: as noites de angústia ficaram para trás.',
    luckyNumbers: '05 • 15 • 25 • 35 • 50',
    luckyColor: 'Branco Pérola / Lavanda',
    powerAffirmation: 'Eu libero a ansiedade do amanhã e descanso na certeza de que tudo coopera para meu bem!'
  },
  {
    label: 'Segredo Revelado',
    color: '#9333ea', // purple-600
    textColor: '#ffffff',
    icon: '🔮',
    title: 'Aviso Importante do Baralho Cigano',
    message: 'Uma máscara vai cair e você enxergará claramente quem é quem. Agradeça pela verdade, pois aquilo que parecia perda era livramento sagrado.',
    luckyNumbers: '11 • 22 • 33 • 44 • 55',
    luckyColor: 'Púrpura / Ametista',
    powerAffirmation: 'Minha intuição é afiada e me revela a verdade antes de qualquer ilusão!'
  },
  {
    label: 'Fartura na Mesa',
    color: '#ea580c', // orange-600
    textColor: '#ffffff',
    icon: '🌽',
    title: 'Colheita e Sustento Familiar',
    message: 'Oxóssi estende sua fartura sobre o seu lar. Alimento, conforto e união familiar serão abençoados com notícias aliviadoras nos próximos dias.',
    luckyNumbers: '04 • 13 • 31 • 42 • 64',
    luckyColor: 'Verde Folha / Terracota',
    powerAffirmation: 'A bênção da fartura reina em minha casa e nunca faltará pão, teto e alegria!'
  },
  {
    label: 'Vitória Inesperada',
    color: '#0891b2', // cyan-600
    textColor: '#ffffff',
    icon: '✨',
    title: 'Reviravolta Positiva a Seu Favor',
    message: 'Aquilo que parecia estagnado ou perdido ganha um sopro de vida inesperado. Mantenha a fé firme: a justiça divina não dorme e você triunfará.',
    luckyNumbers: '02 • 10 • 20 • 32 • 60',
    luckyColor: 'Azul Turquesa / Cristal',
    powerAffirmation: 'Eu sou vitorioso em todas as batalhas que enfrento com retidão e honra!'
  }
];

// 2. DATA: Jogo da Memória Místico
interface MemoryCardItem {
  id: string;
  name: string;
  symbol: string;
  category: string;
  blessing: string;
}

const MEMORY_CARDS_SOURCE: MemoryCardItem[] = [
  { id: 'rosa', name: 'Rosa Vermelha', symbol: '🌹', category: 'Amor & Padilha', blessing: 'Atrai paixão, firmeza afetiva e magnetismo de sedução.' },
  { id: 'espada', name: 'Espada de Ogum', symbol: '⚔️', category: 'Força & Proteção', blessing: 'Corta demandas, vence injustiças e abre caminhos difíceis.' },
  { id: 'arco', name: 'Arco de Oxóssi', symbol: '🏹', category: 'Fartura & Saúde', blessing: 'Mira certeira para alcançar seus objetivos e fartura diária.' },
  { id: 'coroa', name: 'Coroa de Oxum', symbol: '👑', category: 'Riqueza & Amor', blessing: 'Irradia brilho pessoal, prosperidade material e doçura.' },
  { id: 'concha', name: 'Concha de Iemanjá', symbol: '🌊', category: 'Paz & Família', blessing: 'Lava as tristezas, restaura a harmonia no lar e serenidade.' },
  { id: 'ferradura', name: 'Ferradura Cigana', symbol: '🐎', category: 'Sorte da Estrada', blessing: 'Protege seus passos e atrai golpes de sorte inesperados.' },
  { id: 'chave', name: 'Chave Dourada', symbol: '🔑', category: 'Oportunidades', blessing: 'Abre portas emperradas de emprego, moradia e soluções.' },
  { id: 'guia', name: 'Guia dos Pretos Velhos', symbol: '📿', category: 'Sabedoria & Cura', blessing: 'Paciência, conselhos sábios e consolo para o coração.' },
];

// 3. DATA: Oráculo dos Búzios
interface BuzioOutcome {
  openCount: number;
  name: string;
  subtitle: string;
  meaning: 'SIM_ABSOLUTO' | 'SIM_COM_LUTA' | 'SIM_EQUILIBRADO' | 'ATENCAO_ESPERE' | 'NAO_MOMENTO';
  answer: string;
  advice: string;
  ritual: string;
}

const BUZIO_OUTCOMES: Record<number, BuzioOutcome> = {
  4: {
    openCount: 4,
    name: 'Alafia (Todos Abertos)',
    subtitle: 'Luz Plena, Paz Cósmica & Caminho Livre',
    meaning: 'SIM_ABSOLUTO',
    answer: 'SIM! Confirmação total e bênção espiritual imediata.',
    advice: 'O universo diz que seu pedido está alinhado com a justiça e a luz. Siga em frente sem medo ou hesitação.',
    ritual: 'Acenda uma vela branca ou de mel para o seu anjo de guarda agradecendo a confirmação.'
  },
  3: {
    openCount: 3,
    name: 'Etaogunda (3 Abertos, 1 Fechado)',
    subtitle: 'Força de Ogum, Luta com Vitória Certa',
    meaning: 'SIM_COM_LUTA',
    answer: 'SIM! Mas exige coragem, determinação e vigilância.',
    advice: 'A vitória virá das suas próprias mãos. Não conte seus planos a ninguém e encare os desafios com cabeça erguida.',
    ritual: 'Tome um banho de alecrim com espada-de-são-jorge do pescoço para baixo para blindar o corpo.'
  },
  2: {
    openCount: 2,
    name: 'Ejife (2 Abertos, 2 Fechados)',
    subtitle: 'Equilíbrio Sagrado & Bênção dos Ancestrais',
    meaning: 'SIM_EQUILIBRADO',
    answer: 'SIM! Resposta equilibrada, firme e duradoura.',
    advice: 'O que for combinado de forma justa prevalecerá. Há equilíbrio entre razão e emoção, garantindo estabilidade.',
    ritual: 'Beba um copo de água fluidificada com uma pitada de açúcar pensando no seu pedido.'
  },
  1: {
    openCount: 1,
    name: 'Okanran (1 Aberto, 3 Fechados)',
    subtitle: 'Aviso dos Guardiões & Cuidado com Ilusões',
    meaning: 'ATENCAO_ESPERE',
    answer: 'ATENÇÃO! Não dê passos precipitados agora.',
    advice: 'O oráculo pede prudência. O momento pede silêncio, observar os fatos por trás das aparências e não assinar contratos sem ler.',
    ritual: 'Faça uma oração de São Bento e firme uma vela azul pedindo discernimento.'
  },
  0: {
    openCount: 0,
    name: 'Oyeku (Todos Fechados)',
    subtitle: 'Mistério dos Ancestrais & Momento de Recolhimento',
    meaning: 'NAO_MOMENTO',
    answer: 'NÃO NO MOMENTO! Caminhos temporariamente em silêncio.',
    advice: 'O momento é de limpeza espiritual e purificação. Algo precisa ser desfeito antes de o novo destino nascer.',
    ritual: 'Banho de boldo ou manjericão para descarrego e descanso mental nesta noite.'
  }
};

export function MysticalGamesSection({ config, onSelectCartomanteToPlay, onJoinGroup }: MysticalGamesSectionProps) {
  const [activeTab, setActiveTab] = useState<'roleta' | 'memoria' | 'raspadinha' | 'buzios' | 'quiz'>('roleta');

  // --- 1. ESTADO: Roleta da Fortuna ---
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [wheelResult, setWheelResult] = useState<WheelSector | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Play subtle sound click
  const playClickSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!audioContextRef.current) {
        audioContextRef.current = new AudioCtx();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') ctx.resume();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600 + Math.random() * 200, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.06);
    } catch {
      // ignore
    }
  };

  const playWinChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!audioContextRef.current) {
        audioContextRef.current = new AudioCtx();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') ctx.resume();
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.1);
        gain.gain.setValueAtTime(0.12, ctx.currentTime + i * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.1 + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.1);
        osc.stop(ctx.currentTime + i * 0.1 + 0.6);
      });
    } catch {
      // ignore
    }
  };

  const handleSpinWheel = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setWheelResult(null);

    // Audio clicks during spin
    const soundInterval = setInterval(() => {
      playClickSound();
    }, 150);

    const randomIndex = Math.floor(Math.random() * WHEEL_SECTORS.length);
    const sectorAngle = 360 / WHEEL_SECTORS.length;
    // Align sector to pointer at 0 deg (top):
    const targetSectorAngle = randomIndex * sectorAngle + sectorAngle / 2;
    // Calculate new total rotation with 5 to 7 full extra spins
    const extraSpins = 360 * (5 + Math.floor(Math.random() * 3));
    const newRotation = wheelRotation + extraSpins + (360 - (wheelRotation % 360)) + (360 - targetSectorAngle);

    setWheelRotation(newRotation);

    setTimeout(() => {
      clearInterval(soundInterval);
      setIsSpinning(false);
      setWheelResult(WHEEL_SECTORS[randomIndex]);
      playWinChime();
    }, 3800);
  };

  // --- 2. ESTADO: Jogo da Memória Místico ---
  interface MemoryTile {
    uniqueKey: number;
    card: MemoryCardItem;
    isFlipped: boolean;
    isMatched: boolean;
  }

  const [memoryTiles, setMemoryTiles] = useState<MemoryTile[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [memoryMoves, setMemoryMoves] = useState<number>(0);
  const [matchedPairs, setMatchedPairs] = useState<number>(0);
  const [memoryGameWon, setMemoryGameWon] = useState<boolean>(false);

  const initMemoryGame = () => {
    // Duplicate cards and shuffle
    const deck = [...MEMORY_CARDS_SOURCE, ...MEMORY_CARDS_SOURCE]
      .sort(() => Math.random() - 0.5)
      .map((card, idx) => ({
        uniqueKey: idx,
        card,
        isFlipped: false,
        isMatched: false,
      }));
    setMemoryTiles(deck);
    setFlippedIndices([]);
    setMemoryMoves(0);
    setMatchedPairs(0);
    setMemoryGameWon(false);
  };

  useEffect(() => {
    initMemoryGame();
  }, []);

  const handleTileClick = (index: number) => {
    if (flippedIndices.length === 2) return;
    if (memoryTiles[index].isFlipped || memoryTiles[index].isMatched) return;

    playClickSound();

    const newTiles = [...memoryTiles];
    newTiles[index].isFlipped = true;
    setMemoryTiles(newTiles);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMemoryMoves((prev) => prev + 1);
      const [idx1, idx2] = newFlipped;
      if (newTiles[idx1].card.id === newTiles[idx2].card.id) {
        // Matched
        setTimeout(() => {
          newTiles[idx1].isMatched = true;
          newTiles[idx2].isMatched = true;
          setMemoryTiles([...newTiles]);
          setFlippedIndices([]);
          setMatchedPairs((prev) => {
            const next = prev + 1;
            if (next === MEMORY_CARDS_SOURCE.length) {
              setMemoryGameWon(true);
              playWinChime();
            }
            return next;
          });
        }, 500);
      } else {
        // Not matched
        setTimeout(() => {
          newTiles[idx1].isFlipped = false;
          newTiles[idx2].isFlipped = false;
          setMemoryTiles([...newTiles]);
          setFlippedIndices([]);
        }, 900);
      }
    }
  };

  // --- 3. ESTADO: Raspadinha Mística Canvas ---
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [scratchedPercent, setScratchedPercent] = useState<number>(0);
  const [isScratchCardRevealed, setIsScratchCardRevealed] = useState<boolean>(false);
  const isScratchingRef = useRef<boolean>(false);

  // Scratch card random message
  const [scratchReward, setScratchReward] = useState({
    title: 'Bênção de Ouro dos Ciganos',
    symbols: ['🌟', '💰', '🌟'],
    multiplier: 'Caminhos 100% Destravados',
    message: 'Três estrelas douradas se alinharam no seu oráculo! Você receberá notícias favoráveis sobre uma quantia ou oportunidade nesta semana.',
    luckyCode: 'AXE24H-FORTUNA'
  });

  const initScratchCard = () => {
    setIsScratchCardRevealed(false);
    setScratchedPercent(0);

    const rewardsPool = [
      {
        title: 'Tríplice Coroa de Oxum & Ouro',
        symbols: ['👑', '👑', '👑'],
        multiplier: 'Prosperidade & Riqueza Triplicada',
        message: 'A deusa das águas doces e do ouro derrama abundância no seu caminho. Momentos de colheita e alívio financeiro!',
        luckyCode: 'OURO-OXUM-24H'
      },
      {
        title: 'Espada de Ogum & Proteção Blindada',
        symbols: ['⚔️', '🛡️', '⚔️'],
        multiplier: 'Vitória em Batalhas e Causas Difíceis',
        message: 'A justiça divina cortou toda a maldade lançada. Você tem a proteção de Ogum Beira-Mar nas suas costas.',
        luckyCode: 'OGUM-VENCE-GUERRA'
      },
      {
        title: 'Rosa Sagrada de Maria Padilha',
        symbols: ['🌹', '❤️', '🌹'],
        multiplier: 'Amor Ardente & Resolução de Paixões',
        message: 'Os nós do seu coração estão sendo desatados. Quem te fez mal se arrependerá e a verdade do amor vencerá.',
        luckyCode: 'PADILHA-AMOR-24H'
      }
    ];

    const randomReward = rewardsPool[Math.floor(Math.random() * rewardsPool.length)];
    setScratchReward(randomReward);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill with mystical gold gradient cover
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#f59e0b');
    grad.addColorStop(0.3, '#d97706');
    grad.addColorStop(0.7, '#fbbf24');
    grad.addColorStop(1, '#b45309');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add mystical pattern text
    ctx.fillStyle = '#451a03';
    ctx.font = 'bold 16px serif';
    ctx.textAlign = 'center';
    ctx.fillText('✨ RASPADEIRA MÍSTICA 24H ✨', canvas.width / 2, canvas.height / 2 - 20);
    ctx.font = '12px sans-serif';
    ctx.fillText('Passe o dedo ou mouse para raspar a fortuna!', canvas.width / 2, canvas.height / 2 + 10);
    ctx.font = '10px sans-serif';
    ctx.fillText('🔒 Mensagem Espiritual Protegida', canvas.width / 2, canvas.height / 2 + 35);
  };

  useEffect(() => {
    if (activeTab === 'raspadinha') {
      setTimeout(() => {
        initScratchCard();
      }, 100);
    }
  }, [activeTab]);

  const handleScratch = (clientX: number, clientY: number) => {
    if (isScratchCardRevealed) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * canvas.width;
    const y = ((clientY - rect.top) / rect.height) * canvas.height;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 24, 0, Math.PI * 2, false);
    ctx.fill();

    // Check percent periodically
    if (Math.random() < 0.2) {
      checkScratchPercentage();
    }
  };

  const checkScratchPercentage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    let transparentPixels = 0;
    const totalPixels = imgData.data.length / 4;

    for (let i = 3; i < imgData.data.length; i += 4) {
      if (imgData.data[i] === 0) {
        transparentPixels++;
      }
    }

    const percent = Math.round((transparentPixels / totalPixels) * 100);
    setScratchedPercent(percent);

    if (percent > 45 && !isScratchCardRevealed) {
      setIsScratchCardRevealed(true);
      playWinChime();
      // Clear entire canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // --- 4. ESTADO: Oráculo dos 4 Búzios Sagrados ---
  const [buziosQuestion, setBuziosQuestion] = useState<string>('');
  const [isThrowingBuzios, setIsThrowingBuzios] = useState<boolean>(false);
  const [buziosState, setBuziosState] = useState<boolean[]>([true, true, true, false]);
  const [buzioResult, setBuzioResult] = useState<BuzioOutcome | null>(null);

  const handleThrowBuzios = () => {
    if (isThrowingBuzios) return;
    setIsThrowingBuzios(true);
    setBuzioResult(null);

    playClickSound();

    setTimeout(() => {
      // 4 random cowrie shells (open: true, closed: false)
      const shells = [
        Math.random() > 0.45,
        Math.random() > 0.45,
        Math.random() > 0.45,
        Math.random() > 0.45
      ];
      setBuziosState(shells);
      const openCount = shells.filter(Boolean).length;
      setBuzioResult(BUZIO_OUTCOMES[openCount]);
      setIsThrowingBuzios(false);
      playWinChime();
    }, 1200);
  };

  // --- 5. ESTADO: Quiz de Afinidade Espiritual ---
  const [quizStep, setQuizStep] = useState<number>(0);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizCompleted, setQuizCompleted] = useState<boolean>(false);

  const QUIZ_QUESTIONS = [
    {
      question: 'Qual desses elementos mais te acalma e te renova por dentro?',
      options: [
        { text: 'Água doce de cachoeira ou ondas do mar', score: 1 },
        { text: 'Mata virgem, árvores frondosas e terra fértil', score: 2 },
        { text: 'Fogo da lareira, velas brilhantes e noites sob as estrelas', score: 3 },
        { text: 'Vento forte, tempestade e raios de transformação', score: 4 },
      ]
    },
    {
      question: 'Diante de uma injustiça ou momento difícil, como você costuma agir?',
      options: [
        { text: 'Choro em silêncio, mas busco colo e oração', score: 1 },
        { text: 'Analiso com paciência e sabedoria antes de tomar atitude', score: 2 },
        { text: 'Uso a criatividade, contorno os obstáculos e sigo a estrada', score: 3 },
        { text: 'Bato de frente com coragem e defendo quem amo', score: 4 },
      ]
    },
    {
      question: 'Qual é o maior desejo do seu coração neste exato momento?',
      options: [
        { text: 'Harmonia afetiva, amor sincero e paz familiar', score: 1 },
        { text: 'Saúde plena e equilíbrio físico e mental', score: 2 },
        { text: 'Prosperidade financeira, viagens e liberdade', score: 3 },
        { text: 'Quebra de demandas, proteção e vitória em uma causa', score: 4 },
      ]
    },
    {
      question: 'Qual aroma mais te agrada em incensos ou perfumes?',
      options: [
        { text: 'Rosas, lavanda ou alfazema suave', score: 1 },
        { text: 'Arruda, guiné, alecrim ou eucalipto da floresta', score: 2 },
        { text: 'Canela com maçã, sândalo ou baunilha', score: 3 },
        { text: 'Cravo da Índia, mirra ou essência amadeirada forte', score: 4 },
      ]
    }
  ];

  const handleSelectQuizOption = (score: number) => {
    const nextAnswers = [...quizAnswers, score];
    setQuizAnswers(nextAnswers);
    if (quizStep + 1 < QUIZ_QUESTIONS.length) {
      setQuizStep(quizStep + 1);
      playClickSound();
    } else {
      setQuizCompleted(true);
      playWinChime();
    }
  };

  const getQuizResult = () => {
    const total = quizAnswers.reduce((a, b) => a + b, 0);
    if (total <= 6) {
      return {
        falange: 'Falange das Águas Sagradas (Filhos de Oxum & Iemanjá)',
        guardian: 'Mamãe Oxum & Rainha Iemanjá',
        desc: 'Sua aura é carregada de sensibilidade, intuição maternal e doçura. Você sente as energias dos ambientes antes de qualquer um. Sua força reside no amor e na capacidade de acolher.',
        color: 'Azul Claro e Dourado',
        bath: 'Banho de pétalas de rosas amarelas com alfazema e um toque de mel.',
        advice: 'Não guarde mágoas do passado. As águas correm para o mar levando tudo o que não te serve mais.'
      };
    } else if (total <= 9) {
      return {
        falange: 'Linha dos Caboclos & Matas Virgens (Filhos de Oxóssi & Jurema)',
        guardian: 'Pai Oxóssi & Cabocla Jurema',
        desc: 'Você tem uma ligação ancestral profunda com a natureza, remédios de ervas e sabedoria curativa. Gosta da verdade nua e crua e valoriza a liberdade.',
        color: 'Verde Esmeralda e Marrom',
        bath: 'Banho de folhas de louro, alecrim e folhas de eucalipto.',
        advice: 'Mantenha o foco em seus objetivos principais sem se dispersar. Sua flecha tem pontaria sagrada!'
      };
    } else if (total <= 12) {
      return {
        falange: 'Egrégora do Povo Cigano da Estrada & Santa Sara',
        guardian: 'Cigana Esmeralda & Povo do Oriente',
        desc: 'Alma livre, amante da música, da beleza e do mistério das cartas. Você nasceu para prosperar e atrair abundância pelo brilho do seu olhar e pela sua generosidade.',
        color: 'Amarelo Ouro, Vermelho e Roxo',
        bath: 'Banho de pétalas de girassol com paus de canela e 3 cravos-da-índia.',
        advice: 'Confie na sua estrela guia. As cartas mostram uma viagem ou mudança de ciclo muito próspera se aproximando!'
      };
    } else {
      return {
        falange: 'Falange dos Guerreiros de Luz & Força de Ogum e Iansã',
        guardian: 'Pai Ogum & Mãe Iansã',
        desc: 'Espírito destemido, guerreiro e com forte proteção espiritual contra feitiçarias e invejas. Você é o esteio que sustenta e protege muitas pessoas à sua volta.',
        color: 'Vermelho, Cobre e Branco',
        bath: 'Banho de espada-de-são-jorge fatiada, manjericão e alecrim.',
        advice: 'A vitória em sua causa é certa, mas controle a impulsividade. A justiça dos Orixás trabalha em silêncio.'
      };
    }
  };

  return (
    <section id="jogos-misticos" className="py-16 bg-gradient-to-b from-[#090314] via-[#130726] to-[#0a0216] text-white relative overflow-hidden border-t border-purple-500/20 scroll-mt-20">
      
      {/* Background magical glows */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-amber-500/20 border border-purple-400/40 text-purple-200 text-xs font-bold uppercase tracking-wider mb-4 shadow-lg shadow-purple-950/40">
            <Gamepad2 className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>SALÃO DE JOGOS & DISTRAÇÕES MÍSTICAS 24H</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-black text-white leading-tight mb-4">
            Jogos Místicos & Oráculos Gratuitos
          </h2>

          <p className="text-sm sm:text-base text-purple-200/90 leading-relaxed">
            Relaxe e divirta-se enquanto aguarda sua consulta com os Cartomantes! Gire a Roleta da Fortuna, jogue a memória dos Orixás, raspe a profecia secreta ou consulte a caída dos Búzios sagrados.
          </p>
        </div>

        {/* Game Navigation Tabs */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap mb-10">
          <button
            onClick={() => setActiveTab('roleta')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
              activeTab === 'roleta'
                ? 'bg-gradient-to-r from-amber-500 to-red-600 text-white shadow-amber-950/60 scale-105 border border-amber-300/40'
                : 'bg-[#15092b] hover:bg-[#1f0d3e] text-purple-200 border border-purple-500/30'
            }`}
          >
            <RotateCw className={`w-4 h-4 text-amber-300 ${activeTab === 'roleta' ? 'animate-spin' : ''}`} />
            <span>🎡 Roleta da Fortuna</span>
          </button>

          <button
            onClick={() => setActiveTab('memoria')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
              activeTab === 'memoria'
                ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white shadow-purple-950/60 scale-105 border border-purple-300/40'
                : 'bg-[#15092b] hover:bg-[#1f0d3e] text-purple-200 border border-purple-500/30'
            }`}
          >
            <Sparkles className="w-4 h-4 text-fuchsia-300" />
            <span>🃏 Memória dos Orixás</span>
          </button>

          <button
            onClick={() => setActiveTab('raspadinha')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
              activeTab === 'raspadinha'
                ? 'bg-gradient-to-r from-yellow-500 to-amber-600 text-neutral-950 font-black shadow-amber-950/60 scale-105 border border-yellow-200'
                : 'bg-[#15092b] hover:bg-[#1f0d3e] text-purple-200 border border-purple-500/30'
            }`}
          >
            <Gift className="w-4 h-4 text-yellow-400" />
            <span>🎟️ Raspadinha Digital</span>
          </button>

          <button
            onClick={() => setActiveTab('buzios')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
              activeTab === 'buzios'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-700 text-white shadow-blue-950/60 scale-105 border border-blue-300/40'
                : 'bg-[#15092b] hover:bg-[#1f0d3e] text-purple-200 border border-purple-500/30'
            }`}
          >
            <Dice5 className="w-4 h-4 text-blue-300" />
            <span>🐚 Oráculo dos 4 Búzios</span>
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
              activeTab === 'quiz'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-emerald-950/60 scale-105 border border-emerald-300/40'
                : 'bg-[#15092b] hover:bg-[#1f0d3e] text-purple-200 border border-purple-500/30'
            }`}
          >
            <Award className="w-4 h-4 text-emerald-300" />
            <span>✨ Teste de Afinidade</span>
          </button>
        </div>

        {/* GAME CONTENT CONTAINER */}
        <div className="bg-[#120625]/90 border-2 border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-purple-950/80 backdrop-blur-xl">
          
          {/* ============================================================== */}
          {/* 1. ROLETA DA FORTUNA & DESTINOS                                */}
          {/* ============================================================== */}
          {activeTab === 'roleta' && (
            <div className="flex flex-col lg:flex-row items-center justify-center gap-8">
              {/* Wheel Graphic */}
              <div className="flex flex-col items-center">
                <div className="relative w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center">
                  
                  {/* Golden Outer Ring */}
                  <div className="absolute inset-0 rounded-full border-4 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.5)] pointer-events-none z-10" />

                  {/* Indicator Pointer (Top) */}
                  <div className="absolute -top-3 z-20 flex flex-col items-center">
                    <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[24px] border-t-amber-400 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]" />
                  </div>

                  {/* Rotating Wheel Canvas/SVG */}
                  <div 
                    className="w-full h-full rounded-full overflow-hidden transition-transform duration-[3800ms] cubic-bezier(0.15, 0.9, 0.2, 1) relative shadow-2xl"
                    style={{ transform: `rotate(${wheelRotation}deg)` }}
                  >
                    <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                      {WHEEL_SECTORS.map((sec, idx) => {
                        const total = WHEEL_SECTORS.length;
                        const angle = 360 / total;
                        const startAngle = idx * angle;
                        const endAngle = (idx + 1) * angle;
                        
                        const x1 = 50 + 50 * Math.cos((Math.PI * startAngle) / 180);
                        const y1 = 50 + 50 * Math.sin((Math.PI * startAngle) / 180);
                        const x2 = 50 + 50 * Math.cos((Math.PI * endAngle) / 180);
                        const y2 = 50 + 50 * Math.sin((Math.PI * endAngle) / 180);

                        return (
                          <path
                            key={idx}
                            d={`M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`}
                            fill={sec.color}
                            stroke="#ffffff"
                            strokeWidth="0.5"
                          />
                        );
                      })}
                    </svg>

                    {/* Sector Text Labels */}
                    {WHEEL_SECTORS.map((sec, idx) => {
                      const angle = (360 / WHEEL_SECTORS.length) * idx + (360 / WHEEL_SECTORS.length) / 2;
                      return (
                        <div
                          key={idx}
                          className="absolute inset-0 flex items-start justify-center pt-3 text-[10px] sm:text-[11px] font-black uppercase pointer-events-none"
                          style={{
                            transform: `rotate(${angle}deg)`,
                            color: sec.textColor,
                            textShadow: '0 1px 3px rgba(0,0,0,0.9)'
                          }}
                        >
                          <span className="flex items-center gap-0.5">
                            <span>{sec.icon}</span>
                            <span className="truncate max-w-[80px]">{sec.label}</span>
                          </span>
                        </div>
                      );
                    })}

                    {/* Wheel Center Mystical Crystal Hub */}
                    <div className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-gradient-to-br from-amber-300 via-amber-600 to-amber-950 border-3 border-white shadow-xl flex items-center justify-center text-white z-10">
                      <Sparkles className="w-7 h-7 text-amber-100 animate-pulse" />
                    </div>
                  </div>
                </div>

                {/* Spin Button */}
                <button
                  onClick={handleSpinWheel}
                  disabled={isSpinning}
                  className={`mt-6 px-8 py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider shadow-xl transition-all transform cursor-pointer flex items-center gap-2 ${
                    isSpinning
                      ? 'bg-neutral-800 text-neutral-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-amber-500 via-red-500 to-pink-600 hover:from-amber-400 hover:to-pink-500 text-white hover:scale-105 shadow-amber-950/80 active:scale-95'
                  }`}
                >
                  <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
                  <span>{isSpinning ? 'Girando a Fortuna...' : 'Girar a Roleta Grátis'}</span>
                </button>
              </div>

              {/* Wheel Result Card */}
              <div className="flex-1 max-w-md w-full">
                {wheelResult ? (
                  <div className="p-6 rounded-3xl bg-gradient-to-b from-[#1c0c37] to-[#120526] border-2 border-amber-400/60 shadow-2xl animate-fadeIn space-y-4 text-xs">
                    <div className="flex items-center justify-between pb-3 border-b border-purple-500/30">
                      <div className="flex items-center gap-2">
                        <span className="text-3xl">{wheelResult.icon}</span>
                        <div>
                          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest block">
                            Resultado Revelado:
                          </span>
                          <h3 className="text-lg font-serif font-black text-white">
                            {wheelResult.title}
                          </h3>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 border border-amber-400 text-amber-300 font-bold text-[10px]">
                        {wheelResult.label}
                      </span>
                    </div>

                    <p className="text-sm text-purple-100/90 leading-relaxed italic bg-purple-950/50 p-3.5 rounded-2xl border border-purple-500/20">
                      "{wheelResult.message}"
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2.5 rounded-xl bg-black/40 border border-purple-500/20">
                        <strong className="text-amber-300 block mb-0.5">Números da Sorte:</strong>
                        <span className="text-white font-mono">{wheelResult.luckyNumbers}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black/40 border border-purple-500/20">
                        <strong className="text-amber-300 block mb-0.5">Cor Energética:</strong>
                        <span className="text-white">{wheelResult.luckyColor}</span>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-200">
                      <strong>Decreto de Poder:</strong> "{wheelResult.powerAffirmation}"
                    </div>

                    {/* Quick CTA to confirm in WhatsApp Group */}
                    <div className="pt-2 flex flex-col sm:flex-row gap-2">
                      <button
                        onClick={() => onJoinGroup?.()}
                        className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/60 cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Confirmar no Grupo VIP</span>
                      </button>

                      <button
                        onClick={() => onSelectCartomanteToPlay?.(undefined, 1)}
                        className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>Tirar 1 Pergunta (R$ 20)</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 rounded-3xl bg-[#160830]/60 border border-purple-500/20 text-center space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-300">
                      <RotateCw className="w-7 h-7 animate-pulse" />
                    </div>
                    <h3 className="font-serif font-black text-lg text-white">
                      O que o Destino tem para você hoje?
                    </h3>
                    <p className="text-xs text-purple-300 leading-relaxed">
                      Aperte o botão <strong>Girar a Roleta Grátis</strong> para receber uma mensagem profética especial, números da sorte para jogar e conselho dos guias espirituais.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* 2. JOGO DA MEMÓRIA DOS ORIXÁS & SÍMBOLOS                      */}
          {/* ============================================================== */}
          {activeTab === 'memoria' && (
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-purple-500/20">
                <div>
                  <h3 className="font-serif font-black text-lg text-white">
                    Jogo da Memória dos Símbolos Sagrados
                  </h3>
                  <p className="text-xs text-purple-300">
                    Encontre os 8 pares sagrados de Orixás e Baralho Cigano
                  </p>
                </div>

                <div className="flex items-center gap-4 text-xs">
                  <span className="px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-500/30 font-bold text-purple-200">
                    Jogadas: <strong className="text-amber-300">{memoryMoves}</strong>
                  </span>
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 font-bold text-emerald-200">
                    Pares: <strong className="text-white">{matchedPairs} / {MEMORY_CARDS_SOURCE.length}</strong>
                  </span>
                  <button
                    onClick={initMemoryGame}
                    className="p-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-800 text-purple-200 cursor-pointer"
                    title="Reiniciar Jogo"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Memory Grid */}
              <div className="grid grid-cols-4 sm:grid-cols-4 gap-2.5 sm:gap-3.5">
                {memoryTiles.map((tile, idx) => {
                  const isVisible = tile.isFlipped || tile.isMatched;
                  return (
                    <button
                      key={tile.uniqueKey}
                      onClick={() => handleTileClick(idx)}
                      disabled={tile.isMatched}
                      className={`h-20 sm:h-24 rounded-2xl p-2 flex flex-col items-center justify-center transition-all duration-300 transform active:scale-95 cursor-pointer select-none relative overflow-hidden ${
                        tile.isMatched
                          ? 'bg-emerald-950/80 border-2 border-emerald-400/80 shadow-md shadow-emerald-950/50'
                          : isVisible
                          ? 'bg-gradient-to-br from-purple-900 via-indigo-950 to-purple-900 border-2 border-purple-400 shadow-lg'
                          : 'bg-[#1a0c35] hover:bg-[#231046] border-2 border-purple-500/30 hover:border-purple-400/60 shadow-md'
                      }`}
                    >
                      {isVisible ? (
                        <div className="animate-fadeIn text-center">
                          <span className="text-2xl sm:text-3xl block mb-1">{tile.card.symbol}</span>
                          <span className="text-[9px] sm:text-[10px] font-black text-white block truncate max-w-[80px]">
                            {tile.card.name}
                          </span>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Sparkles className="w-5 h-5 text-purple-400/60 mx-auto mb-1 animate-pulse" />
                          <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest">
                            24H
                          </span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Win Modal Banner */}
              {memoryGameWon && (
                <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-[#102a1d] to-emerald-950 border-2 border-emerald-400 text-center space-y-3 animate-fadeIn shadow-2xl">
                  <div className="inline-flex p-3 rounded-full bg-emerald-500/20 text-emerald-300">
                    <Trophy className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-serif font-black text-white">
                    Parabéns! Memória Mística Concluída!
                  </h4>
                  <p className="text-xs text-emerald-200 max-w-md mx-auto">
                    Você completou o jogo em <strong>{memoryMoves} jogadas</strong>. Os Orixás e o Baralho Cigano abençoam sua clareza de pensamento e foco.
                  </p>
                  <div className="pt-2 flex items-center justify-center gap-3">
                    <button
                      onClick={initMemoryGame}
                      className="px-4 py-2 rounded-xl bg-purple-900 hover:bg-purple-800 text-white font-bold text-xs cursor-pointer"
                    >
                      Jogar Novamente
                    </button>
                    <button
                      onClick={() => onJoinGroup?.()}
                      className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs cursor-pointer shadow-lg"
                    >
                      Compartilhar no Grupo de Cartomantes
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* 3. RASPADINHA DIGITAL INTERATIVA                              */}
          {/* ============================================================== */}
          {activeTab === 'raspadinha' && (
            <div className="max-w-md mx-auto space-y-5 text-center">
              <div>
                <h3 className="font-serif font-black text-lg text-white mb-1">
                  Raspadinha da Fortuna & Profecia Secreta
                </h3>
                <p className="text-xs text-purple-300">
                  Passe o dedo ou mouse sobre o cartão dourado para raspar e revelar seu prêmio espiritual
                </p>
              </div>

              {/* Scratch Area Canvas Card */}
              <div className="relative w-full max-w-sm mx-auto h-56 rounded-3xl overflow-hidden shadow-2xl border-2 border-amber-400/80 bg-gradient-to-b from-[#1b0a33] to-[#0d031c]">
                
                {/* Underlying Secret Revealed Content */}
                <div className="absolute inset-0 p-5 flex flex-col items-center justify-center text-center space-y-2 select-none">
                  <div className="flex items-center justify-center gap-3 text-3xl">
                    {scratchReward.symbols.map((s, i) => (
                      <span key={i} className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/40">
                        {s}
                      </span>
                    ))}
                  </div>

                  <h4 className="font-serif font-black text-base text-amber-300">
                    {scratchReward.title}
                  </h4>

                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-400 text-emerald-300 text-[10px] font-bold">
                    {scratchReward.multiplier}
                  </span>

                  <p className="text-[11px] text-purple-200 italic line-clamp-2 px-2">
                    "{scratchReward.message}"
                  </p>

                  <div className="text-[10px] font-mono text-amber-300 bg-black/60 px-3 py-1 rounded-lg border border-amber-500/30">
                    CÓDIGO VIP: <strong>{scratchReward.luckyCode}</strong>
                  </div>
                </div>

                {/* Interactive Canvas Coating */}
                <canvas
                  ref={canvasRef}
                  width={380}
                  height={224}
                  className="absolute inset-0 w-full h-full cursor-pointer touch-none z-10"
                  onMouseDown={() => { isScratchingRef.current = true; }}
                  onMouseUp={() => { isScratchingRef.current = false; }}
                  onMouseLeave={() => { isScratchingRef.current = false; }}
                  onMouseMove={(e) => {
                    if (isScratchingRef.current) {
                      handleScratch(e.clientX, e.clientY);
                    }
                  }}
                  onTouchStart={() => { isScratchingRef.current = true; }}
                  onTouchEnd={() => { isScratchingRef.current = false; }}
                  onTouchMove={(e) => {
                    if (e.touches[0]) {
                      handleScratch(e.touches[0].clientX, e.touches[0].clientY);
                    }
                  }}
                />
              </div>

              {/* Progress and Reset */}
              <div className="flex items-center justify-between px-2 text-xs">
                <span className="text-purple-300 text-[11px]">
                  Raspado: <strong className="text-amber-300">{scratchedPercent}%</strong>
                </span>
                <button
                  onClick={initScratchCard}
                  className="px-4 py-1.5 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-500/30 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Nova Raspadinha</span>
                </button>
              </div>

              {isScratchCardRevealed && (
                <div className="p-4 rounded-2xl bg-amber-950/80 border border-amber-400/80 text-center space-y-2 animate-fadeIn">
                  <Sparkles className="w-6 h-6 text-amber-300 mx-auto" />
                  <h4 className="font-bold text-sm text-white">Cartão Revelado com Sucesso!</h4>
                  <p className="text-xs text-amber-200">
                    Apresente o código <strong>{scratchReward.luckyCode}</strong> no grupo de WhatsApp com as Cartomantes para jogar com bênção e prioridade!
                  </p>
                  <button
                    onClick={() => onJoinGroup?.()}
                    className="mt-1 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase cursor-pointer"
                  >
                    Entrar no Grupo com o Código
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* 4. ORÁCULO DOS 4 BÚZIOS SAGRADOS                              */}
          {/* ============================================================== */}
          {activeTab === 'buzios' && (
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="text-center">
                <h3 className="font-serif font-black text-lg text-white mb-1">
                  Oráculo dos 4 Búzios de Confirmação Rápida
                </h3>
                <p className="text-xs text-purple-300">
                  Faça uma pergunta com o coração calmo e lance os búzios sagrados para obter a resposta do plano espiritual
                </p>
              </div>

              {/* Question input */}
              <div className="max-w-md mx-auto">
                <label className="block text-xs font-bold text-purple-200 mb-1.5 text-left">
                  Sua Pergunta ou Dúvida (Opcional):
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={buziosQuestion}
                    onChange={(e) => setBuziosQuestion(e.target.value)}
                    placeholder="Ex: Vou ter êxito nessa decisão? Meus caminhos estão abertos?"
                    className="flex-1 px-3.5 py-2.5 bg-black/60 border border-purple-500/40 rounded-xl text-white text-xs placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    onClick={handleThrowBuzios}
                    disabled={isThrowingBuzios}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-blue-950/60 cursor-pointer disabled:opacity-50"
                  >
                    <Dice5 className={`w-4 h-4 ${isThrowingBuzios ? 'animate-spin' : ''}`} />
                    <span>{isThrowingBuzios ? 'Lançando...' : 'Lançar Búzios'}</span>
                  </button>
                </div>
              </div>

              {/* Cowrie shells visual representation on sacred cloth */}
              <div className="p-8 rounded-3xl bg-gradient-to-b from-[#180e2d] to-[#0c0418] border-2 border-purple-500/30 shadow-inner flex items-center justify-center gap-5 sm:gap-8 min-h-[160px]">
                {buziosState.map((isOpen, idx) => (
                  <div
                    key={idx}
                    className={`w-16 h-22 sm:w-20 sm:h-28 rounded-3xl border-3 flex flex-col items-center justify-center p-2 shadow-xl transition-all duration-700 transform ${
                      isThrowingBuzios
                        ? 'animate-bounce scale-90 rotate-12'
                        : isOpen
                        ? 'bg-gradient-to-b from-amber-100 to-amber-200 border-amber-400 text-neutral-900 shadow-amber-500/20'
                        : 'bg-gradient-to-b from-neutral-800 to-neutral-900 border-neutral-600 text-neutral-400 shadow-black'
                    }`}
                  >
                    <span className="text-3xl sm:text-4xl mb-1">
                      {isOpen ? '🐚' : '🌑'}
                    </span>
                    <span className="text-[10px] font-black uppercase tracking-wider">
                      {isOpen ? 'Aberto' : 'Fechado'}
                    </span>
                  </div>
                ))}
              </div>

              {/* Buzio Result Outcome Card */}
              {buzioResult && (
                <div className="p-6 rounded-3xl bg-gradient-to-b from-[#180a30] to-[#0d031c] border-2 border-blue-400/60 shadow-2xl animate-fadeIn space-y-3.5 text-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-purple-500/30">
                    <div>
                      <span className="text-[10px] font-bold text-blue-300 uppercase tracking-widest block">
                        Caída dos Búzios:
                      </span>
                      <h4 className="text-lg font-serif font-black text-white">
                        {buzioResult.name}
                      </h4>
                      <p className="text-[11px] text-purple-300">
                        {buzioResult.subtitle}
                      </p>
                    </div>

                    <span className={`px-3 py-1.5 rounded-xl font-black text-xs ${
                      buzioResult.meaning.startsWith('SIM')
                        ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300'
                        : 'bg-amber-500/20 border border-amber-400 text-amber-300'
                    }`}>
                      {buzioResult.answer.split('!')[0]}!
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-500/20 text-purple-100 leading-relaxed italic">
                    "{buzioResult.advice}"
                  </div>

                  <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-500/30 text-blue-200">
                    <strong>Orientação Espiritual:</strong> {buzioResult.ritual}
                  </div>

                  <div className="pt-2 flex items-center justify-between flex-wrap gap-2">
                    <span className="text-[11px] text-purple-300">
                      Deseja confirmação mais profunda sobre amor ou família?
                    </span>
                    <button
                      onClick={() => onSelectCartomanteToPlay?.(undefined, 1)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Consultar Cartomante (R$ 20)
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* 5. QUIZ DE AFINIDADE ESPIRITUAL                                */}
          {/* ============================================================== */}
          {activeTab === 'quiz' && (
            <div className="max-w-xl mx-auto space-y-6">
              {!quizCompleted ? (
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-purple-500/20 mb-4 text-xs">
                    <span className="font-bold text-purple-200">
                      Pergunta {quizStep + 1} de {QUIZ_QUESTIONS.length}
                    </span>
                    <span className="text-amber-300 font-mono">
                      {Math.round(((quizStep + 1) / QUIZ_QUESTIONS.length) * 100)}% concluído
                    </span>
                  </div>

                  <h3 className="font-serif font-black text-lg text-white mb-4">
                    {QUIZ_QUESTIONS[quizStep].question}
                  </h3>

                  <div className="space-y-2.5">
                    {QUIZ_QUESTIONS[quizStep].options.map((opt, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSelectQuizOption(opt.score)}
                        className="w-full p-3.5 rounded-2xl bg-[#180c35] hover:bg-purple-900/60 border border-purple-500/30 hover:border-purple-400 text-left text-xs font-semibold text-purple-100 hover:text-white transition-all transform active:scale-98 cursor-pointer flex items-center justify-between group"
                      >
                        <span>{opt.text}</span>
                        <Check className="w-4 h-4 text-purple-400 group-hover:text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                (() => {
                  const res = getQuizResult();
                  return (
                    <div className="p-6 rounded-3xl bg-gradient-to-b from-[#180c35] to-[#0c041c] border-2 border-emerald-400/60 shadow-2xl animate-fadeIn space-y-4 text-xs">
                      <div className="text-center pb-3 border-b border-purple-500/30">
                        <span className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-300 inline-block mb-2">
                          <Award className="w-8 h-8" />
                        </span>
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block">
                          Sua Egrégora de Afinidade:
                        </span>
                        <h3 className="text-xl font-serif font-black text-white mt-1">
                          {res.falange}
                        </h3>
                        <p className="text-xs text-purple-300 mt-0.5">
                          Guardiões Protetores: <strong>{res.guardian}</strong>
                        </p>
                      </div>

                      <p className="text-xs text-purple-100 leading-relaxed bg-black/40 p-3.5 rounded-2xl border border-purple-500/20">
                        {res.desc}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-500/20">
                          <strong className="text-amber-300 block mb-1">Cores Energéticas:</strong>
                          <span className="text-white">{res.color}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-500/20">
                          <strong className="text-amber-300 block mb-1">Banho de Elevação:</strong>
                          <span className="text-white">{res.bath}</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/30 text-emerald-200">
                        <strong>Mensagem dos Guias:</strong> {res.advice}
                      </div>

                      <div className="pt-2 flex items-center justify-center gap-3">
                        <button
                          onClick={() => {
                            setQuizStep(0);
                            setQuizAnswers([]);
                            setQuizCompleted(false);
                          }}
                          className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-bold text-xs cursor-pointer"
                        >
                          Refazer Teste
                        </button>
                        <button
                          onClick={() => onJoinGroup?.()}
                          className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg cursor-pointer"
                        >
                          Falar com Cartomante no WhatsApp
                        </button>
                      </div>
                    </div>
                  );
                })()
              )}
            </div>
          )}

        </div>

      </div>
    </section>
  );
}
