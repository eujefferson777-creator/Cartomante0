import React, { useState, useEffect, useRef } from 'react';
import { 
  Radio, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  SkipForward, 
  SkipBack, 
  Sparkles, 
  Flame, 
  Music, 
  Heart, 
  ChevronUp, 
  ChevronDown, 
  X, 
  Send, 
  Check, 
  Disc,
  Headphones,
  Sliders,
  RefreshCw,
  AlertCircle,
  Wifi
} from 'lucide-react';
import { RADIO_STATIONS } from '../data/radioStations';
import { RadioStation, RadioTrack } from '../types';
import { spiritualAudioEngine } from '../lib/spiritualAudioEngine';

interface RadioMacumbaPlayerProps {
  isOpen: boolean;
  onClose?: () => void;
  onTogglePlayExternal?: () => void;
}

export function RadioMacumbaPlayer({ isOpen, onClose }: RadioMacumbaPlayerProps) {
  const [currentStationIndex, setCurrentStationIndex] = useState(0);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [usingBackup, setUsingBackup] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isPrayerModalOpen, setIsPrayerModalOpen] = useState(false);
  const [prayerName, setPrayerName] = useState('');
  const [prayerPontoRequest, setPrayerPontoRequest] = useState('');
  const [prayerSentSuccess, setPrayerSentSuccess] = useState(false);
  const [equalizerHeights, setEqualizerHeights] = useState<number[]>([15, 30, 45, 25, 40, 60, 35, 20]);
  const [useSynthesizerFallback, setUseSynthesizerFallback] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentStation: RadioStation = RADIO_STATIONS[currentStationIndex] || RADIO_STATIONS[0];
  const currentTrack: RadioTrack = currentStation.tracks[currentTrackIndex] || currentStation.tracks[0];
  const activeStream = usingBackup && currentStation.backupStreamUrl ? currentStation.backupStreamUrl : currentStation.streamUrl;

  // Sync volume with audio element and fallback engine
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
    spiritualAudioEngine.setVolume(isMuted ? 0 : volume);
  }, [volume, isMuted]);

  // Handle stream change
  useEffect(() => {
    setUsingBackup(false);
    setStreamError(null);
    if (audioRef.current) {
      audioRef.current.src = currentStation.streamUrl;
      if (isPlaying) {
        setIsLoadingAudio(true);
        audioRef.current
          .play()
          .then(() => {
            setIsLoadingAudio(false);
            setStreamError(null);
          })
          .catch((err) => {
            console.warn('Playback error, trying backup stream:', err);
            handleStreamFallback();
          });
      }
    }
  }, [currentStationIndex]);

  // Handle stream fallback if primary fails
  const handleStreamFallback = () => {
    if (!usingBackup && currentStation.backupStreamUrl && audioRef.current) {
      setUsingBackup(true);
      setIsLoadingAudio(true);
      audioRef.current.src = currentStation.backupStreamUrl;
      audioRef.current
        .play()
        .then(() => {
          setIsLoadingAudio(false);
          setStreamError(null);
        })
        .catch(() => {
          // If both fail, activate spiritual synthesizer drone so music never dies
          setUseSynthesizerFallback(true);
          spiritualAudioEngine.startStation(currentStation.rhythmStyle);
          setIsLoadingAudio(false);
          setStreamError('Transmissão ao vivo sintonizada via Frequência Harmônica.');
        });
    } else {
      setUseSynthesizerFallback(true);
      spiritualAudioEngine.startStation(currentStation.rhythmStyle);
      setIsLoadingAudio(false);
      setStreamError('Transmissão sintonizada em modo Egrégora Sagrada.');
    }
  };

  // Animate equalizer bars when playing
  useEffect(() => {
    if (!isPlaying) {
      setEqualizerHeights([8, 12, 8, 14, 10, 16, 10, 8]);
      return;
    }

    const interval = setInterval(() => {
      setEqualizerHeights([
        Math.floor(Math.random() * 45) + 18,
        Math.floor(Math.random() * 60) + 25,
        Math.floor(Math.random() * 75) + 30,
        Math.floor(Math.random() * 55) + 22,
        Math.floor(Math.random() * 70) + 28,
        Math.floor(Math.random() * 85) + 24,
        Math.floor(Math.random() * 50) + 20,
        Math.floor(Math.random() * 40) + 16
      ]);
    }, 130);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Handle Play/Pause
  const handleTogglePlay = () => {
    if (isPlaying) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      spiritualAudioEngine.stop();
      setIsPlaying(false);
      setIsLoadingAudio(false);
    } else {
      setIsPlaying(true);
      setStreamError(null);
      if (useSynthesizerFallback) {
        spiritualAudioEngine.startStation(currentStation.rhythmStyle);
      } else if (audioRef.current) {
        setIsLoadingAudio(true);
        audioRef.current
          .play()
          .then(() => {
            setIsLoadingAudio(false);
          })
          .catch((err) => {
            console.error('Audio play error:', err);
            handleStreamFallback();
          });
      }
    }
  };

  // Switch Station
  const handleSelectStation = (index: number) => {
    setCurrentStationIndex(index);
    setCurrentTrackIndex(0);
    setUseSynthesizerFallback(false);
    setIsPlaying(true);
  };

  // Next Track in Station
  const handleNextTrack = () => {
    const nextIdx = (currentTrackIndex + 1) % currentStation.tracks.length;
    setCurrentTrackIndex(nextIdx);
  };

  // Previous Track
  const handlePrevTrack = () => {
    const prevIdx = (currentTrackIndex - 1 + currentStation.tracks.length) % currentStation.tracks.length;
    setCurrentTrackIndex(prevIdx);
  };

  // Retry Connection
  const handleRetry = () => {
    setStreamError(null);
    setUseSynthesizerFallback(false);
    if (audioRef.current) {
      setIsLoadingAudio(true);
      audioRef.current.src = currentStation.streamUrl;
      audioRef.current
        .play()
        .then(() => {
          setIsLoadingAudio(false);
          setIsPlaying(true);
        })
        .catch(() => {
          handleStreamFallback();
        });
    }
  };

  // Submit Prayer / Ponto Request
  const handleSubmitPrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerName.trim() || !prayerPontoRequest.trim()) return;

    setPrayerSentSuccess(true);
    setTimeout(() => {
      setPrayerSentSuccess(false);
      setIsPrayerModalOpen(false);
      setPrayerName('');
      setPrayerPontoRequest('');
    }, 2500);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Hidden HTML5 Live Audio Element for Real Radio Streams */}
      <audio
        ref={audioRef}
        src={activeStream}
        preload="none"
        onWaiting={() => setIsLoadingAudio(true)}
        onPlaying={() => {
          setIsLoadingAudio(false);
          setIsPlaying(true);
          setStreamError(null);
        }}
        onError={(e) => {
          console.warn('Audio tag error:', e);
          if (isPlaying) {
            handleStreamFallback();
          }
        }}
      />

      {/* Floating Radio Dock Widget (Fixed Bottom) */}
      <div className="fixed bottom-3 inset-x-2 sm:inset-x-auto sm:right-6 sm:max-w-md z-40 animate-fadeIn font-sans">
        <div className="bg-[#0e061e]/95 border-2 border-purple-500/50 rounded-2xl sm:rounded-3xl shadow-2xl shadow-purple-950/90 backdrop-blur-xl overflow-hidden">
          
          {/* Header Bar of the Player */}
          <div className="px-3.5 py-2.5 bg-gradient-to-r from-purple-950 via-[#180b33] to-purple-950 border-b border-purple-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-amber-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-amber-950/60 shrink-0">
                <Radio className={`w-3.5 h-3.5 ${isPlaying ? 'animate-pulse text-amber-100' : ''}`} />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-serif font-black text-xs text-white tracking-wide truncate">
                    RÁDIO MACUMBA 24H
                  </span>
                  <span className="px-1.5 py-0.2 rounded-full bg-red-600 text-[9px] font-extrabold text-white animate-pulse flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                    NO AR AO VIVO
                  </span>
                </div>
                <p className="text-[10px] text-purple-300 truncate flex items-center gap-1">
                  <span>{currentStation.name}</span>
                  <span>•</span>
                  <span className="text-amber-300 font-semibold">{currentStation.frequency}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 text-xs transition-colors cursor-pointer"
                title={isExpanded ? 'Recolher Estações' : 'Ver Todas as Estações'}
              >
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
              </button>
              {onClose && (
                <button
                  onClick={() => {
                    if (audioRef.current) {
                      audioRef.current.pause();
                    }
                    spiritualAudioEngine.stop();
                    setIsPlaying(false);
                    onClose();
                  }}
                  className="p-1.5 rounded-lg bg-purple-900/40 hover:bg-red-950 text-neutral-400 hover:text-red-300 text-xs transition-colors cursor-pointer"
                  title="Fechar Rádio"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Expanded Drawer: All Spiritual Stations Selector */}
          {isExpanded && (
            <div className="p-3 bg-[#0a0316] border-b border-purple-500/20 max-h-60 overflow-y-auto space-y-1.5 text-xs">
              <div className="text-[11px] font-bold text-purple-300 mb-1.5 flex items-center justify-between">
                <span>ESTAÇÕES DE RÁDIO ESPIRITUAIS 24H:</span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <Wifi className="w-3 h-3" /> Transmissão Real
                </span>
              </div>
              {RADIO_STATIONS.map((station, idx) => (
                <button
                  key={station.id}
                  onClick={() => handleSelectStation(idx)}
                  className={`w-full p-2 rounded-xl flex items-center gap-2.5 transition-all cursor-pointer text-left ${
                    currentStationIndex === idx
                      ? 'bg-purple-900/70 border border-purple-400 text-white shadow'
                      : 'bg-[#140827]/60 hover:bg-[#1a0c35] border border-purple-500/20 text-purple-200'
                  }`}
                >
                  <img
                    src={station.coverImage}
                    alt={station.name}
                    className="w-9 h-9 rounded-lg object-cover border border-purple-400/40 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-xs truncate flex items-center gap-1.5">
                      {station.name}
                      {currentStationIndex === idx && isPlaying && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      )}
                    </div>
                    <div className="text-[10px] text-purple-300/80 truncate">
                      {station.tagline}
                    </div>
                  </div>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/40 text-amber-300">
                    {station.frequency.split('•')[0]}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Current Track Playback Bar & Equalizer */}
          <div className="p-3 bg-[#110724] flex items-center justify-between gap-3">
            
            {/* Visualizer / Equalizer bars */}
            <div className="flex items-end gap-0.5 h-7 w-12 shrink-0 bg-black/40 p-1 rounded-lg border border-purple-500/30 justify-center">
              {equalizerHeights.map((h, i) => (
                <div
                  key={i}
                  className="w-1 bg-gradient-to-t from-purple-500 via-amber-400 to-emerald-400 rounded-t transition-all duration-150"
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>

            {/* Track Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-white truncate leading-tight">
                  {currentTrack.title}
                </h4>
                {isLoadingAudio && (
                  <span className="text-[10px] text-amber-300 animate-pulse font-medium">
                    (Conectando...)
                  </span>
                )}
              </div>
              <p className="text-[11px] text-purple-300 truncate">
                {currentTrack.artistOrEntity}
              </p>
              {streamError && (
                <p className="text-[9px] text-amber-400/90 truncate flex items-center gap-1">
                  <AlertCircle className="w-2.5 h-2.5" />
                  {streamError}
                </p>
              )}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={handlePrevTrack}
                className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-purple-900/40 transition-colors cursor-pointer"
                title="Ponto Anterior"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={handleTogglePlay}
                disabled={isLoadingAudio}
                className={`p-2.5 rounded-xl text-white shadow-lg transition-all transform active:scale-95 cursor-pointer ${
                  isPlaying
                    ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-amber-950/60'
                    : 'bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 shadow-purple-950/60'
                } ${isLoadingAudio ? 'opacity-70 cursor-wait' : ''}`}
                title={isPlaying ? 'Pausar Rádio' : 'Ouvir Rádio Macumba Ao Vivo'}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              <button
                onClick={handleNextTrack}
                className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-purple-900/40 transition-colors cursor-pointer"
                title="Próximo Ponto"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 rounded-lg text-purple-300 hover:text-white hover:bg-purple-900/40 transition-colors cursor-pointer"
                title={isMuted ? 'Ativar Som' : 'Mutar'}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Volume Slider Bar */}
          <div className="px-3 pb-2 pt-0.5 bg-[#110724] flex items-center gap-2 border-t border-purple-500/10 text-[10px] text-purple-300">
            <span className="font-semibold text-[9px] uppercase tracking-wider text-purple-400">Volume:</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setVolume(val);
                if (val > 0 && isMuted) setIsMuted(false);
              }}
              className="w-full h-1.5 bg-black/60 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
            <span className="w-6 text-right font-mono text-[9px] text-purple-300">
              {Math.round((isMuted ? 0 : volume) * 100)}%
            </span>
          </div>

          {/* Quick Actions Footer (Letra do Ponto / Pedir Oração) */}
          <div className="px-3 py-2 bg-[#0c041c] border-t border-purple-500/20 flex items-center justify-between text-[11px] gap-2">
            <button
              onClick={() => setIsLyricsOpen(!isLyricsOpen)}
              className="text-purple-300 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Music className="w-3 h-3 text-amber-400" />
              <span>{isLyricsOpen ? 'Ocultar Letra' : 'Letra & Oração'}</span>
            </button>

            <button
              onClick={() => setIsPrayerModalOpen(true)}
              className="text-emerald-300 hover:text-emerald-200 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>Fazer Pedido de Ponto</span>
            </button>
          </div>

          {/* Ponto Lyrics Dropdown Drawer */}
          {isLyricsOpen && currentTrack.pontoLyrics && (
            <div className="p-3 bg-purple-950/80 border-t border-purple-500/30 text-xs text-purple-100 italic leading-relaxed animate-fadeIn">
              <span className="font-bold text-amber-300 not-italic block mb-1 text-[10px] uppercase">
                Letra & Refrão Sagrado:
              </span>
              "{currentTrack.pontoLyrics}"
            </div>
          )}

        </div>
      </div>

      {/* Modal: Pedir Ponto / Oração na Rádio Macumba */}
      {isPrayerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-[#120726] border-2 border-purple-500/50 rounded-3xl p-5 w-full max-w-md shadow-2xl shadow-purple-950/80">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
                  <Flame className="w-5 h-5 fill-amber-400" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-white text-base">
                    Pedir Ponto na Rádio Macumba
                  </h3>
                  <p className="text-[11px] text-purple-300">
                    Firme sua intenção para tocar no plantão espiritual 24h
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPrayerModalOpen(false)}
                className="p-1.5 rounded-lg bg-neutral-900 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {prayerSentSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-center space-y-2">
                <Check className="w-8 h-8 mx-auto text-emerald-400" />
                <h4 className="font-bold text-sm text-white">Pedido Firmado no Altar!</h4>
                <p className="text-xs text-emerald-300">
                  Seu ponto e sua intenção foram enviados para a transmissão da Rádio Macumba. Axé e caminhos abertos!
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitPrayer} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-purple-200 font-bold mb-1">
                    Seu Nome ou Nome da Pessoa:
                  </label>
                  <input
                    type="text"
                    required
                    value={prayerName}
                    onChange={(e) => setPrayerName(e.target.value)}
                    placeholder="Ex: Maria das Graças / Carlos"
                    className="w-full px-3 py-2 bg-black/60 border border-purple-500/40 rounded-xl text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                  />
                </div>

                <div>
                  <label className="block text-purple-200 font-bold mb-1">
                    Qual Ponto, Entidade ou Oração deseja pedir?
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={prayerPontoRequest}
                    onChange={(e) => setPrayerPontoRequest(e.target.value)}
                    placeholder="Ex: Gostaria de pedir um ponto de Ogum e Maria Padilha para abrir os caminhos do meu relacionamento..."
                    className="w-full px-3 py-2 bg-black/60 border border-purple-500/40 rounded-xl text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400 resize-none"
                  />
                </div>

                <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-[11px] text-purple-200">
                  ✨ Os pedidos de pontos são transmitidos durante a programação da rádio e acompanham a egrégora de luz dos Orixás e Ciganos.
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsPrayerModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-300 hover:bg-neutral-800 text-xs font-semibold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs shadow-lg shadow-amber-950/50 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Enviar Pedido de Ponto</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}
