import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  MessageCircle, 
  User, 
  Star, 
  Volume2, 
  VolumeX, 
  Layers, 
  CreditCard, 
  Check, 
  Flame, 
  Smile, 
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  Zap,
  HelpCircle
} from 'lucide-react';
import { CartomanteProfile, SiteConfig, UserAccount, WebChatMessage } from '../types';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import { TAROT_CARDS } from '../data/tarotCards';
import { subscribeToDirectChatMessages, sendDirectChatMessage } from '../lib/firebase';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface CartomanteWebChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SiteConfig;
  currentUser: UserAccount | null;
  initialCartomante?: CartomanteProfile | null;
  onSelectPlan?: (plan: any) => void;
  onOpenWhatsAppDirect?: (cartomanteName: string) => void;
}

// Gentle synthetic chimes for chat
function playChatChime(type: 'sent' | 'received') {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    if (type === 'sent') {
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
    } else {
      osc.frequency.setValueAtTime(880, now); // A5
      osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.18); // E5
    }

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.26);
  } catch (e) {
    // Autoplay policy fallback
  }
}

export function CartomanteWebChatModal({
  isOpen,
  onClose,
  config,
  currentUser,
  initialCartomante,
  onSelectPlan,
  onOpenWhatsAppDirect
}: CartomanteWebChatModalProps) {
  const [cartomantesList, setCartomantesList] = useState<CartomanteProfile[]>(CARTOMANTES_PROFILES);
  const [selectedCartomante, setSelectedCartomante] = useState<CartomanteProfile>(() => {
    return initialCartomante || CARTOMANTES_PROFILES[0];
  });

  const [clientGuestName, setClientGuestName] = useState(() => {
    return localStorage.getItem('cartomante24h_guest_name') || '';
  });
  const [messages, setMessages] = useState<WebChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [soundMuted, setSoundMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync initialCartomante if prop changes
  useEffect(() => {
    if (initialCartomante) {
      setSelectedCartomante(initialCartomante);
    }
  }, [initialCartomante]);

  // Load custom cartomantes from config if available
  useEffect(() => {
    if (config.customCartomantes && config.customCartomantes.length > 0) {
      setCartomantesList(config.customCartomantes);
    }
  }, [config.customCartomantes]);

  // Determine current effective client identity
  const effectiveClientId = currentUser?.id || 'guest_' + (clientGuestName || 'visitante').toLowerCase().replace(/\s+/g, '_');
  const effectiveClientName = currentUser?.name || clientGuestName || 'Consulente';
  const effectiveClientAvatar = currentUser?.avatar || '';

  // Unique chat room ID for this pair
  const chatId = `chat_${selectedCartomante.id}_${effectiveClientId}`;

  // Helper to generate personalized greeting based on cartomante's egrégora
  const getCartomanteGreeting = (c: CartomanteProfile): string => {
    const greetings: Record<string, string> = {
      '1': `Axé e bênçãos sagradas! Sou ${c.name}. Meus Guias e a força dos caminhos estão abertos para você. O que seu coração busca saber hoje?`,
      '2': `Optchá! Que Santa Sara Kali ilumine seus passos. Sou ${c.name}. Meu Baralho Cigano está pronto na mesa. Como posso te orientar?`,
      '3': `Saravá e bênçãos da mata! Sou ${c.name}. As folhas sagradas e os búzios mostram a verdade dos seus caminhos. Sinta-se em paz para conversar comigo.`,
      '4': `Paz de Oxalá e a sabedoria dos Pretos Velhos estejam com você, meu filho(a). Sou ${c.name}. Diga com fé o que aflige sua alma.`
    };
    return greetings[c.id] || `Olá, seja muito bem-vindo(a)! Sou ${c.name}. Estou online no plantão para jogar suas cartas e tirar suas dúvidas. O que deseja saber?`;
  };

  // Subscribe to real-time messages in Firebase Firestore
  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = subscribeToDirectChatMessages(chatId, (dbMessages) => {
      if (dbMessages && dbMessages.length > 0) {
        setMessages(dbMessages);
      } else {
        // Fallback: check localStorage or initialize with welcome greeting
        const localSaved = localStorage.getItem(`cartomante24h_chat_${chatId}`);
        if (localSaved) {
          try {
            setMessages(JSON.parse(localSaved));
            return;
          } catch (e) {}
        }

        // Default greeting message
        const welcomeMsg: WebChatMessage = {
          id: 'welcome_' + selectedCartomante.id,
          chatId,
          senderId: selectedCartomante.id,
          senderName: selectedCartomante.name,
          senderAvatar: selectedCartomante.avatar,
          senderRole: 'cartomante',
          text: getCartomanteGreeting(selectedCartomante),
          timestamp: new Date().toISOString()
        };
        setMessages([welcomeMsg]);
      }
    });

    return () => unsubscribe();
  }, [isOpen, chatId, selectedCartomante.id]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (customText?: string) => {
    const text = (customText || inputText).trim();
    if (!text) return;

    if (!clientGuestName && !currentUser) {
      const defaultName = 'Consulente ' + Math.floor(100 + Math.random() * 900);
      setClientGuestName(defaultName);
      localStorage.setItem('cartomante24h_guest_name', defaultName);
    }

    const newMsg: WebChatMessage = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      chatId,
      senderId: effectiveClientId,
      senderName: effectiveClientName,
      senderAvatar: effectiveClientAvatar,
      senderRole: currentUser?.role === 'admin' ? 'admin' : (currentUser?.role || 'client'),
      text,
      timestamp: new Date().toISOString()
    };

    const updated = [...messages, newMsg];
    setMessages(updated);
    localStorage.setItem(`cartomante24h_chat_${chatId}`, JSON.stringify(updated));
    setInputText('');

    if (!soundMuted) {
      playChatChime('sent');
    }

    // Send to Firebase Firestore
    await sendDirectChatMessage(chatId, newMsg, {
      cartomanteId: selectedCartomante.id,
      cartomanteName: selectedCartomante.name,
      cartomanteAvatar: selectedCartomante.avatar,
      cartomanteTitle: selectedCartomante.title,
      clientId: effectiveClientId,
      clientName: effectiveClientName,
      clientAvatar: effectiveClientAvatar
    });

    // Simulate instant mystical reply from cartomante if not responding in real time
    simulateCartomanteReply(text);
  };

  // Instant mystical wisdom response
  const simulateCartomanteReply = (clientQuestion: string) => {
    setIsTyping(true);

    setTimeout(async () => {
      setIsTyping(false);

      const lower = clientQuestion.toLowerCase();
      let replyText = '';
      let tarotAttachment: WebChatMessage['tarotCard'] | undefined = undefined;

      // Draw a random card to accompany guidance if relevant
      const randomCard = TAROT_CARDS[Math.floor(Math.random() * TAROT_CARDS.length)];

      if (lower.includes('amor') || lower.includes('namoro') || lower.includes('casamento') || lower.includes('voltar') || lower.includes('ele') || lower.includes('ela')) {
        replyText = `Sinto a vibração do seu campo amoroso. As energias mostram momentos de decisão e reavaliação. Para uma resposta precisa, mentalize sua pergunta e veja a carta que tirei agora na mesa para você:`;
        tarotAttachment = {
          name: randomCard.name,
          image: randomCard.image,
          suit: randomCard.suit,
          meaning: randomCard.meaning,
          advice: randomCard.advice
        };
      } else if (lower.includes('dinheiro') || lower.includes('trabalho') || lower.includes('emprego') || lower.includes('financeiro')) {
        replyText = `Caminhos de prosperidade exigem foco e corte de energias pesadas. O baralho aponta oportunidades se abrindo nos próximos dias. Veja a carta revelada:`;
        tarotAttachment = {
          name: randomCard.name,
          image: randomCard.image,
          suit: randomCard.suit,
          meaning: randomCard.meaning,
          advice: randomCard.advice
        };
      } else if (lower.includes('banho') || lower.includes('limpeza') || lower.includes('proteção')) {
        replyText = `Recomendo para você um banho de arruda, alecrim e manjericão do pescoço para baixo após o banho de higiene. Acenda uma vela branca com um copo de água ao lado e faça seus pedidos com fé.`;
      } else {
        replyText = `Recebi sua mensagem com muito carinho e respeito aos seus orixás e guias. Tirei uma carta de luz para iluminar sua questão agora:`;
        tarotAttachment = {
          name: randomCard.name,
          image: randomCard.image,
          suit: randomCard.suit,
          meaning: randomCard.meaning,
          advice: randomCard.advice
        };
      }

      const cartomanteMsg: WebChatMessage = {
        id: 'reply_' + Date.now(),
        chatId,
        senderId: selectedCartomante.id,
        senderName: selectedCartomante.name,
        senderAvatar: selectedCartomante.avatar,
        senderRole: 'cartomante',
        text: replyText,
        tarotCard: tarotAttachment,
        timestamp: new Date().toISOString()
      };

      setMessages((prev) => {
        const next = [...prev, cartomanteMsg];
        localStorage.setItem(`cartomante24h_chat_${chatId}`, JSON.stringify(next));
        return next;
      });

      if (!soundMuted) {
        playChatChime('received');
      }

      await sendDirectChatMessage(chatId, cartomanteMsg);
    }, 1800);
  };

  // Instant card draw trigger button inside chat
  const handleDrawCardInChat = () => {
    const randomCard = TAROT_CARDS[Math.floor(Math.random() * TAROT_CARDS.length)];
    const cardMsg: WebChatMessage = {
      id: 'card_' + Date.now(),
      chatId,
      senderId: selectedCartomante.id,
      senderName: selectedCartomante.name,
      senderAvatar: selectedCartomante.avatar,
      senderRole: 'cartomante',
      text: `🃏 Tirei a lâmina sagrada "${randomCard.name}" para orientar seus caminhos agora:`,
      tarotCard: {
        name: randomCard.name,
        image: randomCard.image,
        suit: randomCard.suit,
        meaning: randomCard.meaning,
        advice: randomCard.advice
      },
      timestamp: new Date().toISOString()
    };

    setMessages((prev) => {
      const next = [...prev, cardMsg];
      localStorage.setItem(`cartomante24h_chat_${chatId}`, JSON.stringify(next));
      return next;
    });

    if (!soundMuted) {
      playChatChime('received');
    }

    sendDirectChatMessage(chatId, cardMsg);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0e061c] border-2 border-purple-500/40 rounded-3xl w-full max-w-4xl h-[92vh] max-h-[850px] shadow-2xl shadow-purple-950/80 flex flex-col overflow-hidden relative text-white">
        
        {/* Header with Cartomante Selector */}
        <div className="bg-[#140828] border-b border-purple-500/30 p-3 sm:p-4 shrink-0">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-purple-400/60 shadow-lg shadow-purple-950/50 shrink-0">
                <img
                  src={selectedCartomante.avatar}
                  alt={selectedCartomante.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#140828]" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-serif font-black text-base sm:text-lg text-white truncate">
                    {selectedCartomante.name}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[10px] font-extrabold text-emerald-400 flex items-center gap-1 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>CHAT WEB ONLINE</span>
                  </span>
                </div>
                <p className="text-xs text-purple-300 truncate">
                  {selectedCartomante.title} • {selectedCartomante.experienceYears} anos de dons
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {/* Sound Toggle */}
              <button
                onClick={() => setSoundMuted(!soundMuted)}
                className={`p-2 rounded-xl border transition-all cursor-pointer ${
                  !soundMuted 
                    ? 'bg-purple-900/50 text-amber-300 border-purple-500/40' 
                    : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                }`}
                title={soundMuted ? 'Ativar som de mensagens' : 'Silenciar som'}
                aria-label={soundMuted ? 'Ativar som do chat' : 'Silenciar som do chat'}
              >
                {soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              {/* Direct WhatsApp Call */}
              <button
                onClick={() => onOpenWhatsAppDirect?.(selectedCartomante.name)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 text-emerald-300 font-bold text-xs transition-all cursor-pointer"
                title="Migrar para o WhatsApp da Cartomante"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-emerald-400" />
                <span>WhatsApp</span>
              </button>

              {/* Close Button */}
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
                title="Fechar chat"
                aria-label="Fechar chat web"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Cartomantes Switcher Row */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            <span className="text-[11px] font-bold text-purple-300/80 uppercase tracking-wider shrink-0 mr-1">
              Trocar Cartomante:
            </span>
            {cartomantesList.map((c) => {
              const isSelected = c.id === selectedCartomante.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCartomante(c)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white shadow-md border border-purple-300'
                      : 'bg-[#1e0d3a]/60 hover:bg-[#28124d] text-purple-200 border border-purple-500/30'
                  }`}
                >
                  <img
                    src={c.avatar}
                    alt={c.name}
                    className="w-4 h-4 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span>{c.name.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Guest Name Bar (if not logged in) */}
        {!currentUser && (
          <div className="bg-[#120625] px-4 py-2 border-b border-purple-500/20 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-purple-200">
              <User className="w-3.5 h-3.5 text-purple-400" />
              <span>Seu Nome no Chat:</span>
              <input
                type="text"
                value={clientGuestName}
                onChange={(e) => {
                  setClientGuestName(e.target.value);
                  localStorage.setItem('cartomante24h_guest_name', e.target.value);
                }}
                placeholder="Digite seu nome ou apelido"
                className="bg-black/50 border border-purple-500/40 rounded-lg px-2 py-0.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-400 w-44"
              />
            </div>
            <span className="text-[11px] text-purple-400/80 hidden sm:inline">
              🔒 Conversa segura e privada no site
            </span>
          </div>
        )}

        {/* Quick Question / Action Bar */}
        <div className="bg-[#0b0317] px-4 py-2 border-b border-purple-500/20 flex items-center gap-2 overflow-x-auto text-xs shrink-0">
          <button
            onClick={handleDrawCardInChat}
            className="px-3 py-1 rounded-xl bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/40 text-amber-300 font-bold flex items-center gap-1.5 shrink-0 transition-all cursor-pointer shadow"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>🃏 Tirar Carta do Tarot</span>
          </button>

          <button
            onClick={() => handleSendMessage('Gostaria de saber o que o baralho mostra sobre meus caminhos no AMOR.')}
            className="px-2.5 py-1 rounded-xl bg-[#1c0c36] hover:bg-purple-900/60 border border-purple-500/30 text-purple-200 font-medium shrink-0 transition-all cursor-pointer"
          >
            ❤️ Amor & Relacionamento
          </button>

          <button
            onClick={() => handleSendMessage('Como estão as energias para meu TRABALHO e FINANÇAS?')}
            className="px-2.5 py-1 rounded-xl bg-[#1c0c36] hover:bg-purple-900/60 border border-purple-500/30 text-purple-200 font-medium shrink-0 transition-all cursor-pointer"
          >
            💰 Trabalho & Dinheiro
          </button>

          <button
            onClick={() => handleSendMessage('Preciso de uma orientação espiritual e indicação de banho de ervas.')}
            className="px-2.5 py-1 rounded-xl bg-[#1c0c36] hover:bg-purple-900/60 border border-purple-500/30 text-purple-200 font-medium shrink-0 transition-all cursor-pointer"
          >
            🌿 Banho & Proteção
          </button>
        </div>

        {/* Messages Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-gradient-to-b from-[#0e061c] via-[#090214] to-[#0d041a]">
          {messages.map((msg) => {
            const isMe = msg.senderId === effectiveClientId;
            const isCartomante = msg.senderRole === 'cartomante';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] sm:max-w-[75%] ${
                  isMe ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Sender Avatar */}
                <div className="w-8 h-8 rounded-full overflow-hidden border border-purple-400/40 shrink-0 shadow mt-1">
                  <img
                    src={msg.senderAvatar || (isMe ? catLogo : selectedCartomante.avatar)}
                    alt={msg.senderName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Message Bubble */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-[11px] text-purple-300 px-1">
                    <span className="font-bold text-white">{msg.senderName}</span>
                    <span className="text-[10px] text-neutral-400">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div
                    className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-lg ${
                      isMe
                        ? 'bg-gradient-to-r from-purple-700 to-fuchsia-700 text-white rounded-tr-none border border-purple-400/40'
                        : 'bg-[#1a0c32] text-purple-100 rounded-tl-none border border-purple-500/30'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>

                    {/* Embedded Tarot Card if attached */}
                    {msg.tarotCard && (
                      <div className="mt-3 p-3 rounded-xl bg-black/60 border border-amber-500/40 space-y-2">
                        <div className="flex items-center gap-3">
                          {msg.tarotCard.image && (
                            <img
                              src={msg.tarotCard.image}
                              alt={msg.tarotCard.name}
                              className="w-14 h-20 rounded-lg object-cover border border-amber-400/50 shadow-md shrink-0"
                            />
                          )}
                          <div>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                              Lâmina Sagrada do Destino
                            </span>
                            <h5 className="font-serif font-black text-sm text-white">
                              {msg.tarotCard.name}
                            </h5>
                            <p className="text-[11px] text-purple-200 mt-0.5">
                              {msg.tarotCard.meaning}
                            </p>
                          </div>
                        </div>

                        {msg.tarotCard.advice && (
                          <div className="pt-2 border-t border-purple-500/20 text-[11px] text-amber-200/90 italic">
                            ✨ <strong>Conselho dos Guias:</strong> {msg.tarotCard.advice}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-purple-300 animate-pulse pl-11">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span>{selectedCartomante.name} está jogando as cartas na mesa...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Bottom Consultation Offer Banner */}
        <div className="bg-[#120624] px-4 py-2 border-t border-purple-500/20 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>Valores Especiais no Chat:</span>
            </span>
            <span className="text-xs text-purple-200">
              1 Pergunta <strong>R$ {config.price1Question || 20},00</strong> • 3 Perguntas <strong>R$ {config.price3Questions || 50},00</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onSelectPlan?.({ id: '1-pergunta', name: '1 Pergunta Direta', price: config.price1Question || 20 });
              }}
              className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-xs shadow cursor-pointer transition-all"
            >
              Pagar 1 Pergunta (PIX)
            </button>
            <button
              onClick={() => {
                onSelectPlan?.({ id: '3-perguntas', name: '3 Perguntas Completas', price: config.price3Questions || 50 });
              }}
              className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow cursor-pointer transition-all"
            >
              Pagar 3 Perguntas (PIX)
            </button>
          </div>
        </div>

        {/* Input Bar */}
        <div className="bg-[#140828] p-3 sm:p-4 border-t border-purple-500/30 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Escreva sua pergunta ou mensagem para ${selectedCartomante.name.split(' ')[0]}...`}
              className="flex-1 bg-[#090314] border border-purple-500/40 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder-purple-300/50 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 transition-all"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className={`p-3 sm:px-5 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg transition-all cursor-pointer shrink-0 ${
                inputText.trim()
                  ? 'bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 text-white hover:brightness-110 shadow-purple-950/60'
                  : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
              }`}
              title="Enviar mensagem"
              aria-label="Enviar mensagem no chat"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Enviar</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
