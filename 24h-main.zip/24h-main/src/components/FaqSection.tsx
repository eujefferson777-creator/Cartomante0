import { useState } from 'react';
import { ChevronDown, HelpCircle, Sparkles } from 'lucide-react';
import { FAQS_DATA } from '../data/faqs';
import { SiteConfig } from '../types';

interface FaqSectionProps {
  config?: SiteConfig;
}

export function FaqSection({ config }: FaqSectionProps) {
  const [openFaqId, setOpenFaqId] = useState<string | null>('1');
  const faqs = config?.customFaqs && config.customFaqs.length > 0 ? config.customFaqs : FAQS_DATA;

  const toggleFaq = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  return (
    <section id="faq" className="py-16 md:py-24 bg-[#080314] relative border-t border-purple-500/20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-purple-300" />
            Dúvidas Frequentes
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-white">
            Perguntas & Respostas sobre o Atendimento
          </h2>
          <p className="mt-2 text-sm text-purple-200/80">
            Tudo o que você precisa saber sobre as chamadas de vídeo, grupo de WhatsApp e formas de pagamento.
          </p>
        </div>

        {/* Accordion FAQ List */}
        <div className="space-y-3.5">
          {faqs.map((faq) => {
            const isOpen = openFaqId === faq.id;

            return (
              <div
                key={faq.id}
                className={`rounded-2xl border transition-all overflow-hidden ${
                  isOpen
                    ? 'bg-[#140728] border-purple-500/50 shadow-xl shadow-purple-950/40'
                    : 'bg-[#0e051c]/90 border-purple-500/30 hover:border-purple-400/60'
                }`}
              >
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="text-sm sm:text-base font-bold text-white">
                    {faq.question}
                  </span>
                  <div
                    className={`p-1.5 rounded-lg bg-[#200d3d] text-purple-300 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 text-white bg-purple-600' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-5 sm:px-5 text-xs sm:text-sm text-purple-100/90 leading-relaxed border-t border-purple-500/20 pt-3 animate-fadeIn">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
