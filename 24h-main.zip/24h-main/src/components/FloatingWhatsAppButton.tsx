import { useState } from 'react';
import { MessageCircle, Users, Video, X, Edit3, Link as LinkIcon, ExternalLink } from 'lucide-react';
import { SiteConfig } from '../types';

interface FloatingWhatsAppButtonProps {
  config: SiteConfig;
  isAdmin?: boolean;
  onOpenWhatsAppGroup: () => void;
  onOpenLives: () => void;
  onOpenLinkManager?: (targetId?: string) => void;
}

export function FloatingWhatsAppButton({ 
  config, 
  isAdmin = false,
  onOpenWhatsAppGroup, 
  onOpenLives,
  onOpenLinkManager 
}: FloatingWhatsAppButtonProps) {
  const [isOpenMenu, setIsOpenMenu] = useState(false);

  const handleOpenPrivateChat = () => {
    const text = encodeURIComponent(
      config.floatingBalloonDirectMessage ||
      'Olá Cartomante 24h! Gostaria de tirar dúvidas sobre a consulta online e valores.'
    );
    window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
  };

  const handleMainClick = () => {
    const action = config.floatingBalloonAction || 'menu';
    if (action === 'direct_whatsapp') {
      handleOpenPrivateChat();
      return;
    }
    if (action === 'direct_group') {
      onOpenWhatsAppGroup();
      return;
    }
    if (action === 'custom_url' && config.floatingBalloonCustomUrl) {
      window.open(config.floatingBalloonCustomUrl, '_blank');
      return;
    }
    // Default: toggle quick action bubble
    setIsOpenMenu(!isOpenMenu);
  };

  return (
    <div id="floating-whatsapp-widget" className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2">
      {/* Quick Admin Balloon Edit Pill */}
      {isAdmin && (
        <button
          onClick={() => onOpenLinkManager?.('balloon')}
          className="px-2.5 py-1 rounded-full bg-purple-950/95 hover:bg-purple-800 border border-purple-400 text-amber-300 text-[10px] font-bold flex items-center gap-1 shadow-xl cursor-pointer transition-all hover:scale-105"
          title="Configurar Link, Ação e Mensagem deste Balão Flutuante"
        >
          <Edit3 className="w-3 h-3 text-amber-300" />
          <span>Editar Balão</span>
        </button>
      )}

      {/* Expanded Quick Action Bubble */}
      {isOpenMenu && (
        <div className="bg-neutral-900 border border-emerald-500/40 rounded-2xl p-3.5 shadow-2xl w-64 text-neutral-100 text-xs space-y-2 animate-fadeIn mb-1">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <span className="font-bold text-amber-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>{config.floatingBalloonNotice || 'Plantão 24h Ativo'}</span>
            </span>
            <button
              onClick={() => setIsOpenMenu(false)}
              className="text-neutral-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-[11px] text-neutral-300">
            Como deseja ser atendido(a) agora?
          </p>

          <button
            id="floating-join-group-btn"
            onClick={() => {
              setIsOpenMenu(false);
              onOpenWhatsAppGroup();
            }}
            className="w-full py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-2 transition-all cursor-pointer"
          >
            <Users className="w-4 h-4" />
            <span>Entrar no Grupo VIP</span>
          </button>

          <button
            id="floating-private-chat-btn"
            onClick={() => {
              setIsOpenMenu(false);
              handleOpenPrivateChat();
            }}
            className="w-full py-2 px-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-semibold flex items-center gap-2 transition-all cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>Chamar no Privado</span>
          </button>

          <button
            id="floating-live-stream-btn"
            onClick={() => {
              setIsOpenMenu(false);
              onOpenLives();
            }}
            className="w-full py-2 px-2.5 rounded-xl bg-purple-950 hover:bg-purple-900 border border-purple-500/40 text-purple-200 text-[11px] font-semibold flex items-center gap-2 transition-all cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            <span>Assistir Lives ao Vivo</span>
          </button>

          {/* Admin Direct Configuration Button */}
          {isAdmin && (
            <button
              onClick={() => {
                setIsOpenMenu(false);
                onOpenLinkManager?.('balloon');
              }}
              className="w-full py-1.5 px-2 rounded-lg bg-purple-950/80 hover:bg-purple-900/90 border border-purple-400/50 text-purple-200 text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer mt-1"
            >
              <Edit3 className="w-3 h-3 text-amber-300" />
              <span>Editar Links & Balão (Admin)</span>
            </button>
          )}
        </div>
      )}

      {/* Main Floating Pulsing Button */}
      <button
        id="main-floating-whatsapp-trigger"
        onClick={handleMainClick}
        className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-400 hover:from-emerald-500 hover:to-emerald-300 text-neutral-950 flex items-center justify-center shadow-2xl shadow-emerald-950/60 border-2 border-emerald-300/40 hover:scale-105 transition-all cursor-pointer relative group"
        aria-label="Atendimento no WhatsApp 24h"
        title="Atendimento no WhatsApp 24h"
      >
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full border-2 border-neutral-950 flex items-center justify-center text-[9px] font-extrabold text-neutral-950">
          1
        </span>
        <MessageCircle className="w-7 h-7 fill-neutral-950 group-hover:scale-110 transition-transform" />
      </button>
    </div>
  );
}
