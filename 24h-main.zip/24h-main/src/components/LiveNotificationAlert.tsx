import { useState, useEffect, useRef } from 'react';
import { 
  Bell, 
  BellRing, 
  Video, 
  X, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Radio, 
  ExternalLink,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { LiveStreamSession, SiteConfig } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface LiveNotificationAlertProps {
  streams: LiveStreamSession[];
  config: SiteConfig;
  onSelectStream: (stream: LiveStreamSession) => void;
}

// Generates a gentle spiritual notification chime using Web Audio API
function playLiveAlertChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    // Harmonic bell chime notes (F#5, A#5, C#6)
    const freqs = [739.99, 932.33, 1108.73];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.12);

      gain.gain.setValueAtTime(0, now + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.15, now + idx * 0.12 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 1.3);
    });
  } catch (e) {
    // AudioContext autoplay restrictions
    console.debug('Audio chime silent fallback', e);
  }
}

export function LiveNotificationAlert({
  streams,
  config,
  onSelectStream
}: LiveNotificationAlertProps) {
  const [activeAlertStream, setActiveAlertStream] = useState<LiveStreamSession | null>(null);
  const [isDismissed, setIsDismissed] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('cartomante24h_live_sound') !== 'false';
  });
  const [pushPermission, setPushPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });
  const [permissionRequestedNotice, setPermissionRequestedNotice] = useState<string | null>(null);

  // Track previously seen stream IDs so we only chime on new lives
  const prevStreamIdsRef = useRef<Set<string>>(new Set());

  // Filter currently active live streams
  const liveStreams = streams.filter(s => s.isLive);

  useEffect(() => {
    if (liveStreams.length === 0) {
      setActiveAlertStream(null);
      return;
    }

    const currentLive = liveStreams[0];
    const prevIds = prevStreamIdsRef.current;
    const isBrandNewLive = !prevIds.has(currentLive.id);

    // If there is a brand new live started
    if (isBrandNewLive) {
      prevIds.add(currentLive.id);
      setActiveAlertStream(currentLive);
      setIsDismissed(false);

      // Play audio chime if enabled
      if (soundEnabled) {
        playLiveAlertChime();
      }

      // Fire Native Browser Push Notification if permission granted
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        try {
          const notification = new Notification(`🔴 Live Começou: ${currentLive.cartomanteName}`, {
            body: `"${currentLive.title}" está ao vivo agora no Cartomante 24h! Clique para assistir.`,
            icon: currentLive.cartomanteAvatar || catLogo,
            badge: catLogo,
            tag: `live-${currentLive.id}`
          });

          notification.onclick = () => {
            window.focus();
            onSelectStream(currentLive);
            notification.close();
          };
        } catch (err) {
          console.warn('Native notification error:', err);
        }
      }
    } else if (!activeAlertStream && !isDismissed) {
      // Keep alert visible for active live if not dismissed
      setActiveAlertStream(currentLive);
    }
  }, [liveStreams, soundEnabled, isDismissed]);

  const requestNotificationPermission = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPermissionRequestedNotice('Seu navegador não suporta notificações de área de trabalho.');
      return;
    }

    try {
      const perm = await Notification.requestPermission();
      setPushPermission(perm);
      if (perm === 'granted') {
        setPermissionRequestedNotice('🔔 Notificações ativadas com sucesso! Você será avisado quando uma cartomante entrar ao vivo.');
        playLiveAlertChime();

        // Welcome notification
        new Notification('✨ Notificações Cartomante 24h Ativadas', {
          body: 'Você receberá avisos automáticos sempre que uma cartomante iniciar uma live ao vivo!',
          icon: catLogo
        });
      } else if (perm === 'denied') {
        setPermissionRequestedNotice('As notificações foram bloqueadas nas configurações do seu navegador.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    localStorage.setItem('cartomante24h_live_sound', String(next));
    if (next) {
      playLiveAlertChime();
    }
  };

  // Test manual live alert (useful for user confirmation)
  const triggerTestAlert = () => {
    if (liveStreams.length > 0) {
      setActiveAlertStream(liveStreams[0]);
      setIsDismissed(false);
      playLiveAlertChime();
    }
  };

  if (!activeAlertStream || isDismissed) {
    // Show compact floating notification indicator if there is an active live
    if (liveStreams.length > 0 && isDismissed) {
      return (
        <aside 
          aria-label="Alerta de live ao vivo"
          className="fixed top-20 right-4 z-40 animate-fadeIn"
        >
          <button
            onClick={() => setIsDismissed(false)}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-red-950/90 border border-red-500/50 text-white shadow-2xl hover:bg-red-900 transition-all cursor-pointer group"
            title="Ver alerta de Live Ao Vivo"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-bold text-red-200 group-hover:text-white">
              🔴 Live no Ar: {liveStreams[0].cartomanteName.split(' ')[0]}
            </span>
          </button>
        </aside>
      );
    }
    return null;
  }

  return (
    <aside 
      aria-label="Alerta de transmissão ao vivo de cartomante"
      className="fixed top-20 right-4 sm:right-6 z-50 max-w-md w-[calc(100vw-2rem)] animate-bounce-subtle"
    >
      <div className="bg-[#130726]/95 backdrop-blur-xl border-2 border-red-500/60 rounded-3xl p-4 shadow-2xl shadow-red-950/80 text-white relative overflow-hidden">
        
        {/* Glow background accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-purple-600/20 rounded-full blur-2xl pointer-events-none" />

        {/* Top bar */}
        <div className="flex items-center justify-between gap-2 mb-2.5 relative z-10">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            <span className="text-[11px] font-black uppercase tracking-wider text-red-400 bg-red-950/80 px-2 py-0.5 rounded-full border border-red-500/40">
              🔴 LIVE AO VIVO AGORA
            </span>
            <span className="text-[10px] text-purple-300 font-semibold flex items-center gap-1">
              <span>{activeAlertStream.viewersCount || 14} assistindo</span>
            </span>
          </div>

          <div className="flex items-center gap-1">
            {/* Sound toggle button */}
            <button
              onClick={toggleSound}
              className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                soundEnabled 
                  ? 'bg-purple-900/60 text-purple-200 border-purple-500/40 hover:text-white' 
                  : 'bg-neutral-800 text-neutral-400 border-neutral-700'
              }`}
              title={soundEnabled ? 'Silenciar som do sino de lives' : 'Ativar sino de som para novas lives'}
              aria-label={soundEnabled ? 'Silenciar som de alerta de lives' : 'Ativar som de alerta de lives'}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-amber-300" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            {/* Dismiss button */}
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1.5 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
              title="Fechar alerta temporariamente"
              aria-label="Fechar alerta de live"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Live details info */}
        <div className="flex items-center gap-3.5 mb-3 relative z-10">
          <div className="relative w-14 h-14 rounded-2xl overflow-hidden border-2 border-red-500/70 shrink-0 shadow-md shadow-red-950/50">
            <img
              src={activeAlertStream.cartomanteAvatar || catLogo}
              alt={activeAlertStream.cartomanteName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 ring-1 ring-inset ring-red-400/40" />
          </div>

          <div className="flex-1 min-w-0">
            <h4 className="font-serif font-black text-sm text-white truncate flex items-center gap-1">
              <span>{activeAlertStream.cartomanteName}</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            </h4>
            <p className="text-[11px] text-purple-200/90 font-medium line-clamp-1">
              {activeAlertStream.title}
            </p>
            <p className="text-[10px] text-red-300/80 mt-0.5 font-sans">
              Tiragem de cartas e perguntas abertas no chat ao vivo!
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 relative z-10">
          <button
            onClick={() => {
              onSelectStream(activeAlertStream);
              setIsDismissed(true);
            }}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-black rounded-xl shadow-lg shadow-red-950/60 flex items-center justify-center gap-1.5 transition-all cursor-pointer hover:scale-[1.02]"
          >
            <Video className="w-3.5 h-3.5" />
            <span>Assistir Agora</span>
          </button>

          {pushPermission !== 'granted' ? (
            <button
              onClick={requestNotificationPermission}
              className="w-full py-2.5 px-3 bg-purple-900/60 hover:bg-purple-800 border border-purple-500/40 text-purple-200 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="Receber notificações quando uma cartomante entrar ao vivo"
            >
              <BellRing className="w-3.5 h-3.5 text-amber-300" />
              <span>Ativar Alertas</span>
            </button>
          ) : (
            <div className="w-full py-2 px-2 bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold rounded-xl flex items-center justify-center gap-1">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Alertas Ativos</span>
            </div>
          )}
        </div>

        {/* Feedback message when activating push */}
        {permissionRequestedNotice && (
          <div className="mt-2.5 p-2 rounded-xl bg-purple-950/90 border border-purple-400/40 text-[11px] text-purple-200 flex items-start gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0 mt-0.5" />
            <p className="flex-1">{permissionRequestedNotice}</p>
          </div>
        )}
      </div>
    </aside>
  );
}
