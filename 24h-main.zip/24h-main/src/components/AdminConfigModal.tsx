import { useState, type FormEvent, useEffect } from 'react';
import {
  Settings, Check, X, Phone, MessageCircle, QrCode, RefreshCw, Users, ShieldCheck,
  CheckCircle2, XCircle, DollarSign, Clock, ExternalLink, Camera, Edit3, Trash2,
  PlusCircle, User, Sparkles, Mail, Calendar, Heart, BookOpen, Star, Search, Shield, Facebook
} from 'lucide-react';
import { SiteConfig, CartomanteCandidate, CartomanteProfile, UserAccount, ClientProfileData } from '../types';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import { AvatarPicker } from './AvatarPicker';

interface AdminConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SiteConfig;
  onSave: (newConfig: SiteConfig) => void;
  onProfilesChanged?: () => void;
}

export function AdminConfigModal({
  isOpen,
  onClose,
  config,
  onSave,
  onProfilesChanged
}: AdminConfigModalProps) {
  const [activeTab, setActiveTab] = useState<'cartomantes' | 'clients' | 'candidates' | 'config'>('cartomantes');
  const [formData, setFormData] = useState<SiteConfig>(config);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [successNotice, setSuccessNotice] = useState('');

  // 1. Cartomantes state (all active profiles)
  const [cartomantes, setCartomantes] = useState<CartomanteProfile[]>([]);
  const [editingCartomante, setEditingCartomante] = useState<CartomanteProfile | null>(null);
  const [isCreatingCartomante, setIsCreatingCartomante] = useState(false);

  // 2. Clients state
  const [clients, setClients] = useState<UserAccount[]>([]);
  const [editingClient, setEditingClient] = useState<UserAccount | null>(null);
  const [clientProfileDetail, setClientProfileDetail] = useState<ClientProfileData | null>(null);
  const [clientSearchQuery, setClientSearchQuery] = useState('');

  // 3. Candidates list state
  const [candidates, setCandidates] = useState<CartomanteCandidate[]>([]);
  const [editingCandidate, setEditingCandidate] = useState<CartomanteCandidate | null>(null);

  // Load all data on open
  useEffect(() => {
    if (isOpen) {
      // 1. Load Cartomantes
      const storedCartomantes = localStorage.getItem('cartomante24h_all_cartomantes');
      if (storedCartomantes) {
        try {
          setCartomantes(JSON.parse(storedCartomantes));
        } catch {
          setCartomantes(CARTOMANTES_PROFILES);
        }
      } else {
        setCartomantes(CARTOMANTES_PROFILES);
        localStorage.setItem('cartomante24h_all_cartomantes', JSON.stringify(CARTOMANTES_PROFILES));
      }

      // 2. Load Users / Clients
      const storedUsers = localStorage.getItem('cartomante24h_users');
      if (storedUsers) {
        try {
          const parsed = JSON.parse(storedUsers);
          setClients(parsed);
        } catch {
          setClients([]);
        }
      } else {
        // Initial mock users if none exist
        const initialUsers: UserAccount[] = [
          {
            id: 'admin-master',
            name: 'Jefferson (Admin Master)',
            email: 'eujefferson777@gmail.com',
            role: 'admin',
            phone: '(11) 99999-8888',
            birthDate: '1990-05-20',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
            createdAt: new Date().toISOString()
          },
          {
            id: 'client-demo-1',
            name: 'Mariana Fernandes',
            email: 'mariana.consultas@gmail.com',
            role: 'client',
            phone: '(11) 98888-7777',
            birthDate: '1996-03-12',
            avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
            createdAt: new Date().toISOString()
          },
          {
            id: 'client-demo-2',
            name: 'Carlos Eduardo Silva',
            email: 'carlos.silva@outlook.com',
            role: 'client',
            phone: '(21) 97654-3210',
            birthDate: '1988-11-28',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
            createdAt: new Date().toISOString()
          }
        ];
        setClients(initialUsers);
        localStorage.setItem('cartomante24h_users', JSON.stringify(initialUsers));
      }

      // 3. Load Candidates
      const storedCandidates = localStorage.getItem('cartomante24h_candidates');
      if (storedCandidates) {
        try {
          setCandidates(JSON.parse(storedCandidates));
        } catch {
          setCandidates([]);
        }
      } else {
        const defaultCandidate: CartomanteCandidate = {
          id: 'cand-demo-1',
          name: 'Mãe Valéria de Ogum',
          email: 'valeria.cartomante@gmail.com',
          phone: '(11) 97777-6666',
          avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&auto=format&fit=crop&q=80',
          experienceYears: 14,
          specialties: ['Amor e Reconciliação', 'Caminhos Financeiros'],
          deckTypes: ['Baralho Cigano (Lenormand)', 'Tarot dos Orixás'],
          bio: 'Trabalho com aconselhamento espiritual há mais de 14 anos, trazendo verdades e caminhos de luz.',
          groupLink: 'https://chat.whatsapp.com/invite-mae-valeria-vip',
          status: 'pendente',
          appliedAt: new Date().toLocaleDateString('pt-BR'),
          pricePer1Question: 20.0,
          pricePer3Questions: 50.0
        };
        setCandidates([defaultCandidate]);
        localStorage.setItem('cartomante24h_candidates', JSON.stringify([defaultCandidate]));
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setSuccessNotice(msg);
    setTimeout(() => setSuccessNotice(''), 3000);
  };

  // --- CARTOMANTES MANAGEMENT ---
  const handleSaveCartomante = (e: FormEvent) => {
    e.preventDefault();
    if (!editingCartomante) return;

    let updatedList: CartomanteProfile[];
    if (isCreatingCartomante) {
      updatedList = [editingCartomante, ...cartomantes];
    } else {
      updatedList = cartomantes.map((c) =>
        c.id === editingCartomante.id ? editingCartomante : c
      );
    }

    setCartomantes(updatedList);
    localStorage.setItem('cartomante24h_all_cartomantes', JSON.stringify(updatedList));
    localStorage.setItem('cartomante24h_approved_profiles', JSON.stringify(updatedList));

    setEditingCartomante(null);
    setIsCreatingCartomante(false);
    showToast('Perfil da Cartomante salvo com sucesso!');
    if (onProfilesChanged) onProfilesChanged();
  };

  const handleDeleteCartomante = (id: string) => {
    if (!confirm('Deseja realmente remover esta Cartomante do site?')) return;
    const updatedList = cartomantes.filter((c) => c.id !== id);
    setCartomantes(updatedList);
    localStorage.setItem('cartomante24h_all_cartomantes', JSON.stringify(updatedList));
    localStorage.setItem('cartomante24h_approved_profiles', JSON.stringify(updatedList));
    showToast('Cartomante removida com sucesso.');
    if (onProfilesChanged) onProfilesChanged();
  };

  const handleStartCreateCartomante = () => {
    const newCartomante: CartomanteProfile = {
      id: 'cartomante-' + Date.now(),
      name: '',
      title: 'Mestra em Baralho Cigano',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
      rating: 5.0,
      consultationsCount: 150,
      experienceYears: 10,
      isOnline: true,
      statusText: 'Disponível Agora no Plantão 24h',
      specialties: ['Amor e Reconciliação', 'Caminhos Financeiros', 'Baralho Cigano'],
      deckTypes: ['Baralho Cigano (Lenormand)', 'Tarot de Marselha'],
      bio: 'Atendimento com sigilo absoluto e sabedoria ancestral.',
      voiceGreetingText: 'Olá! Sou a cartomante do plantão 24h. Estou pronta para ler suas cartas agora.',
      whatsappMessage: 'Olá! Quero jogar 1 pergunta (R$ 20) ou 3 perguntas (R$ 50) com você agora.'
    };
    setEditingCartomante(newCartomante);
    setIsCreatingCartomante(true);
  };

  // --- CLIENTS MANAGEMENT ---
  const handleOpenEditClient = (user: UserAccount) => {
    setEditingClient({ ...user });
    const stored = localStorage.getItem(`cartomante24h_profile_${user.id}`);
    if (stored) {
      try {
        setClientProfileDetail(JSON.parse(stored));
      } catch {
        setClientProfileDetail(null);
      }
    } else {
      setClientProfileDetail({
        userId: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone || '',
        birthDate: user.birthDate || '',
        astrologicalSign: 'Gêmeos ♊',
        preferredDeck: 'cigano',
        avatar: user.avatar,
        notes: '',
        consultationsHistory: []
      });
    }
  };

  const handleSaveClient = (e: FormEvent) => {
    e.preventDefault();
    if (!editingClient) return;

    const updatedList = clients.map((c) =>
      c.id === editingClient.id ? editingClient : c
    );
    setClients(updatedList);
    localStorage.setItem('cartomante24h_users', JSON.stringify(updatedList));

    // Also update profile details
    if (clientProfileDetail) {
      const updatedProfile: ClientProfileData = {
        ...clientProfileDetail,
        name: editingClient.name,
        email: editingClient.email,
        phone: editingClient.phone || '',
        birthDate: editingClient.birthDate || '',
        avatar: editingClient.avatar
      };
      localStorage.setItem(`cartomante24h_profile_${editingClient.id}`, JSON.stringify(updatedProfile));
    }

    // If current logged-in user was edited, update currentUser too
    const currentLogged = localStorage.getItem('cartomante24h_current_user');
    if (currentLogged) {
      try {
        const parsed = JSON.parse(currentLogged);
        if (parsed.id === editingClient.id) {
          localStorage.setItem('cartomante24h_current_user', JSON.stringify(editingClient));
        }
      } catch (e) {
        console.error(e);
      }
    }

    setEditingClient(null);
    setClientProfileDetail(null);
    showToast('Perfil de Cliente atualizado com sucesso!');
    if (onProfilesChanged) onProfilesChanged();
  };

  const handleDeleteClient = (userId: string) => {
    if (!confirm('Deseja realmente excluir a conta deste usuário?')) return;
    const updatedList = clients.filter((c) => c.id !== userId);
    setClients(updatedList);
    localStorage.setItem('cartomante24h_users', JSON.stringify(updatedList));
    localStorage.removeItem(`cartomante24h_profile_${userId}`);
    showToast('Conta excluída com sucesso.');
    if (onProfilesChanged) onProfilesChanged();
  };

  // --- CANDIDATES MANAGEMENT ---
  const handleApproveCandidate = (cand: CartomanteCandidate) => {
    const updated = candidates.map((c) =>
      c.id === cand.id ? { ...c, status: 'aprovado' as const, approvedAt: new Date().toLocaleDateString('pt-BR') } : c
    );
    setCandidates(updated);
    localStorage.setItem('cartomante24h_candidates', JSON.stringify(updated));

    // Convert candidate to active Cartomante Profile
    const newProfile: CartomanteProfile = {
      id: cand.id,
      name: cand.name,
      title: `Mestra em ${cand.deckTypes[0] || 'Baralho Cigano'}`,
      avatar: cand.avatar || 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&auto=format&fit=crop&q=80',
      rating: 5.0,
      consultationsCount: 1,
      experienceYears: cand.experienceYears,
      isOnline: true,
      statusText: 'Disponível no Grupo VIP',
      specialties: cand.specialties,
      deckTypes: cand.deckTypes,
      bio: cand.bio,
      voiceGreetingText: `Olá! Sou ${cand.name}. Estou pronta para jogar suas cartas agora!`,
      whatsappMessage: `Olá ${cand.name}! Vi seu perfil no Cartomante 24h e quero jogar 1 pergunta (R$ 20) ou 3 perguntas (R$ 50) com você!`
    };

    const existingProfiles = [...cartomantes];
    if (!existingProfiles.some((p) => p.id === newProfile.id)) {
      existingProfiles.push(newProfile);
      setCartomantes(existingProfiles);
      localStorage.setItem('cartomante24h_all_cartomantes', JSON.stringify(existingProfiles));
      localStorage.setItem('cartomante24h_approved_profiles', JSON.stringify(existingProfiles));
    }

    showToast(`Cartomante ${cand.name} aprovada com sucesso!`);
    if (onProfilesChanged) onProfilesChanged();
  };

  const handleRejectCandidate = (candidateId: string) => {
    const updated = candidates.map((c) =>
      c.id === candidateId ? { ...c, status: 'rejeitado' as const } : c
    );
    setCandidates(updated);
    localStorage.setItem('cartomante24h_candidates', JSON.stringify(updated));

    // Remove from approved profiles if it was there
    const updatedProfiles = cartomantes.filter((p) => p.id !== candidateId);
    setCartomantes(updatedProfiles);
    localStorage.setItem('cartomante24h_all_cartomantes', JSON.stringify(updatedProfiles));
    localStorage.setItem('cartomante24h_approved_profiles', JSON.stringify(updatedProfiles));

    showToast('Inscrição rejeitada.');
    if (onProfilesChanged) onProfilesChanged();
  };

  const handleSaveGeneralConfig = (e: FormEvent) => {
    e.preventDefault();
    onSave(formData);
    showToast('Configurações salvas com sucesso!');
  };

  const pendingCount = candidates.filter((c) => c.status === 'pendente').length;
  const filteredClients = clients.filter(
    (c) =>
      c.name.toLowerCase().includes(clientSearchQuery.toLowerCase()) ||
      c.email.toLowerCase().includes(clientSearchQuery.toLowerCase()) ||
      (c.phone && c.phone.includes(clientSearchQuery))
  );

  return (
    <div id="admin-config-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div id="admin-config-modal-content" className="w-full max-w-4xl bg-neutral-900 border border-amber-500/40 rounded-3xl p-4 sm:p-6 shadow-2xl text-neutral-100 max-h-[94vh] overflow-y-auto flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-serif font-bold text-amber-200">Painel do Administrador Master</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-extrabold">
                  ADMIN EU
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Gerencie e edite todos os perfis de Cartomantes, Clientes, Inscrições e Valores
              </p>
            </div>
          </div>

          <button
            id="close-admin-config-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Toast / Success Message */}
        {successNotice && (
          <div className="my-3 p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-emerald-200 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex flex-wrap border-b border-neutral-800 my-4 gap-2">
          <button
            onClick={() => {
              setActiveTab('cartomantes');
              setEditingCartomante(null);
            }}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'cartomantes'
                ? 'bg-amber-500 text-neutral-950 shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-950'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Editar Cartomantes ({cartomantes.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('clients');
              setEditingClient(null);
            }}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'clients'
                ? 'bg-amber-500 text-neutral-950 shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-950'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Editar Clientes ({clients.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('candidates')}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'candidates'
                ? 'bg-amber-500 text-neutral-950 shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-950'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Aprovar Inscrições</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px]">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('config')}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'config'
                ? 'bg-amber-500 text-neutral-950 shadow-md'
                : 'text-neutral-400 hover:text-white bg-neutral-950'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Valores & PIX</span>
          </button>
        </div>

        {/* ======================================================== */}
        {/* TAB 1: CARTOMANTES PROFILES MANAGER & EDITOR */}
        {/* ======================================================== */}
        {activeTab === 'cartomantes' && (
          <div className="space-y-4">
            {editingCartomante ? (
              /* --- EDIT / CREATE CARTOMANTE FORM --- */
              <form onSubmit={handleSaveCartomante} className="p-5 bg-neutral-950 rounded-2xl border border-amber-500/40 space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                  <h3 className="font-serif font-bold text-base text-amber-300 flex items-center gap-2">
                    <Edit3 className="w-4 h-4" />
                    {isCreatingCartomante ? 'Cadastrar Nova Cartomante' : `Editar Perfil: ${editingCartomante.name}`}
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCartomante(null);
                      setIsCreatingCartomante(false);
                    }}
                    className="text-xs text-neutral-400 hover:text-white px-2 py-1 bg-neutral-900 rounded-lg"
                  >
                    Voltar para a Lista
                  </button>
                </div>

                {/* Avatar Picker for Cartomante */}
                <div className="p-4 bg-neutral-900/70 rounded-2xl border border-neutral-800 flex flex-col items-center">
                  <AvatarPicker
                    currentAvatar={editingCartomante.avatar}
                    onAvatarChange={(newAv) => setEditingCartomante({ ...editingCartomante, avatar: newAv })}
                    userName={editingCartomante.name || 'Cartomante'}
                    size="md"
                    label="Alterar Foto da Cartomante"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Nome Espiritual / Profissional *</label>
                    <input
                      type="text"
                      required
                      value={editingCartomante.name}
                      onChange={(e) => setEditingCartomante({ ...editingCartomante, name: e.target.value })}
                      placeholder="Ex: Mãe Yara do Oriente"
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Título / Especialidade Principal</label>
                    <input
                      type="text"
                      value={editingCartomante.title}
                      onChange={(e) => setEditingCartomante({ ...editingCartomante, title: e.target.value })}
                      placeholder="Ex: Mestra em Baralho Cigano & União de Almas"
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Anos de Experiência</label>
                    <input
                      type="number"
                      value={editingCartomante.experienceYears}
                      onChange={(e) => setEditingCartomante({ ...editingCartomante, experienceYears: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Avaliação (Estrelas de 1 a 5)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="1"
                      max="5"
                      value={editingCartomante.rating}
                      onChange={(e) => setEditingCartomante({ ...editingCartomante, rating: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Status de Atendimento</label>
                    <select
                      value={editingCartomante.isOnline ? 'online' : 'offline'}
                      onChange={(e) => setEditingCartomante({ ...editingCartomante, isOnline: e.target.value === 'online' })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    >
                      <option value="online">🟢 Online no Plantão 24h</option>
                      <option value="offline">⚪ Em Atendimento / Offline</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">Texto de Status / Chamada</label>
                  <input
                    type="text"
                    value={editingCartomante.statusText}
                    onChange={(e) => setEditingCartomante({ ...editingCartomante, statusText: e.target.value })}
                    placeholder="Disponível Agora para Chamada de Vídeo e Perguntas"
                    className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">Biografia & Apresentação Espiritual</label>
                  <textarea
                    rows={3}
                    value={editingCartomante.bio}
                    onChange={(e) => setEditingCartomante({ ...editingCartomante, bio: e.target.value })}
                    className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">Mensagem de Voz / Saudação do Botão Ouvir</label>
                  <input
                    type="text"
                    value={editingCartomante.voiceGreetingText}
                    onChange={(e) => setEditingCartomante({ ...editingCartomante, voiceGreetingText: e.target.value })}
                    className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                  />
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCartomante(null);
                      setIsCreatingCartomante(false);
                    }}
                    className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded-xl cursor-pointer"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>Salvar Perfil da Cartomante</span>
                  </button>
                </div>
              </form>
            ) : (
              /* --- CARTOMANTES LIST --- */
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <div>
                    <span className="text-xs font-bold text-neutral-200 block">Equipe de Cartomantes Ativas no Site</span>
                    <span className="text-[11px] text-neutral-400">Você como Admin pode alterar qualquer foto, nome, bio e status.</span>
                  </div>
                  <button
                    onClick={handleStartCreateCartomante}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow cursor-pointer transition-all self-start sm:self-auto"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Adicionar Nova Cartomante</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {cartomantes.map((c) => (
                    <div
                      key={c.id}
                      className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 hover:border-amber-500/30 transition-all flex flex-col justify-between"
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="w-16 h-16 rounded-2xl overflow-hidden bg-neutral-900 border border-amber-400/60 shrink-0">
                          <img
                            src={c.avatar}
                            alt={c.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-sm text-neutral-100 truncate">{c.name}</h4>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                                c.isOnline
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-neutral-800 text-neutral-400'
                              }`}
                            >
                              {c.isOnline ? 'Online' : 'Offline'}
                            </span>
                          </div>
                          <p className="text-xs text-amber-400 truncate">{c.title}</p>
                          <div className="flex items-center gap-3 text-[11px] text-neutral-400 mt-1">
                            <span className="flex items-center gap-1 text-amber-300 font-bold">
                              <Star className="w-3 h-3 fill-amber-300" />
                              {c.rating.toFixed(2)}
                            </span>
                            <span>•</span>
                            <span>{c.experienceYears} anos exp.</span>
                            <span>•</span>
                            <span>{c.consultationsCount} consultas</span>
                          </div>
                        </div>
                      </div>

                      <p className="text-xs text-neutral-300 mt-3 line-clamp-2 italic">
                        "{c.bio}"
                      </p>

                      <div className="flex items-center justify-between mt-4 pt-3 border-t border-neutral-800">
                        <span className="text-[10px] text-neutral-500 font-mono">ID: {c.id}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleDeleteCartomante(c.id)}
                            className="p-1.5 text-neutral-400 hover:text-rose-400 hover:bg-neutral-900 rounded-lg transition-colors cursor-pointer"
                            title="Remover Cartomante"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setEditingCartomante({ ...c });
                              setIsCreatingCartomante(false);
                            }}
                            className="px-3 py-1.5 bg-neutral-900 hover:bg-amber-500 hover:text-neutral-950 border border-amber-500/40 text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Editar Perfil</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: CLIENT PROFILES MANAGER & EDITOR */}
        {/* ======================================================== */}
        {activeTab === 'clients' && (
          <div className="space-y-4">
            {editingClient ? (
              /* --- EDIT CLIENT PROFILE FORM --- */
              <form onSubmit={handleSaveClient} className="p-5 bg-neutral-950 rounded-2xl border border-amber-500/40 space-y-4 animate-fadeIn">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                  <h3 className="font-serif font-bold text-base text-amber-300 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Editar Perfil do Cliente: {editingClient.name}
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingClient(null);
                      setClientProfileDetail(null);
                    }}
                    className="text-xs text-neutral-400 hover:text-white px-2 py-1 bg-neutral-900 rounded-lg"
                  >
                    Voltar para a Lista
                  </button>
                </div>

                {/* Avatar Picker for Client */}
                <div className="p-4 bg-neutral-900/70 rounded-2xl border border-neutral-800 flex flex-col items-center">
                  <AvatarPicker
                    currentAvatar={editingClient.avatar}
                    onAvatarChange={(newAv) => setEditingClient({ ...editingClient, avatar: newAv })}
                    userName={editingClient.name}
                    size="md"
                    label="Alterar Foto de Perfil do Cliente"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Nome Completo</label>
                    <input
                      type="text"
                      required
                      value={editingClient.name}
                      onChange={(e) => setEditingClient({ ...editingClient, name: e.target.value })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">E-mail</label>
                    <input
                      type="email"
                      required
                      value={editingClient.email}
                      onChange={(e) => setEditingClient({ ...editingClient, email: e.target.value })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">WhatsApp</label>
                    <input
                      type="tel"
                      value={editingClient.phone || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, phone: e.target.value })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Data de Nascimento</label>
                    <input
                      type="date"
                      value={editingClient.birthDate || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, birthDate: e.target.value })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Nível de Acesso (Cargo)</label>
                    <select
                      value={editingClient.role}
                      onChange={(e) => setEditingClient({ ...editingClient, role: e.target.value as any })}
                      className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    >
                      <option value="client">Cliente VIP</option>
                      <option value="admin">Administrador Master</option>
                      <option value="cartomante">Cartomante Atendente</option>
                    </select>
                  </div>
                </div>

                {clientProfileDetail && (
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">Signo Zodiacal / Notas Espirituais</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        value={clientProfileDetail.astrologicalSign}
                        onChange={(e) => setClientProfileDetail({ ...clientProfileDetail, astrologicalSign: e.target.value })}
                        placeholder="Ex: Escorpião ♏"
                        className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                      />
                      <input
                        type="text"
                        value={clientProfileDetail.notes}
                        onChange={(e) => setClientProfileDetail({ ...clientProfileDetail, notes: e.target.value })}
                        placeholder="Notas para atendimentos..."
                        className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                      />
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingClient(null);
                      setClientProfileDetail(null);
                    }}
                    className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded-xl cursor-pointer"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>Salvar Dados do Cliente</span>
                  </button>
                </div>
              </form>
            ) : (
              /* --- CLIENTS LIST --- */
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={clientSearchQuery}
                      onChange={(e) => setClientSearchQuery(e.target.value)}
                      placeholder="Buscar cliente por nome, email ou whatsapp..."
                      className="w-full pl-9 pr-3 py-1.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-200"
                    />
                  </div>
                  <span className="text-xs text-neutral-400 font-semibold">
                    Total: <strong className="text-amber-300">{filteredClients.length}</strong> cadastrados
                  </span>
                </div>

                <div className="space-y-2.5">
                  {filteredClients.map((user) => (
                    <div
                      key={user.id}
                      className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-neutral-700 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-full bg-neutral-900 border border-amber-400/60 overflow-hidden flex items-center justify-center font-bold text-amber-300 shrink-0">
                          {user.avatar ? (
                            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            user.name.charAt(0).toUpperCase()
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-neutral-100">{user.name}</span>
                            <span
                              className={`px-2 py-0.2 rounded-full text-[9px] font-bold uppercase ${
                                user.role === 'admin'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              }`}
                            >
                              {user.role === 'admin' ? 'Admin Master' : 'Cliente VIP'}
                            </span>
                          </div>
                          <p className="text-xs text-neutral-400">
                            {user.email} {user.phone ? `• ${user.phone}` : ''} {user.birthDate ? `• Nasc: ${user.birthDate}` : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <button
                          onClick={() => handleDeleteClient(user.id)}
                          className="p-2 text-neutral-400 hover:text-rose-400 hover:bg-neutral-900 rounded-xl transition-colors cursor-pointer"
                          title="Excluir Conta"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEditClient(user)}
                          className="px-3.5 py-1.5 bg-neutral-900 hover:bg-amber-500 hover:text-neutral-950 border border-neutral-700 hover:border-amber-400 text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Editar Perfil</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: CANDIDATES QUEUE & APPROVAL */}
        {/* ======================================================== */}
        {activeTab === 'candidates' && (
          <div className="space-y-4">
            <div className="p-3.5 bg-neutral-950/80 border border-neutral-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs text-neutral-300">
                Inscrições de pessoas que querem trabalhar como <strong>Cartomante</strong>. Somente você (Admin) pode aprovar.
              </span>
              <span className="text-xs text-amber-300 font-bold">
                1 Pergunta: R$ 20,00 • 3 Perguntas: R$ 50,00
              </span>
            </div>

            {candidates.length === 0 ? (
              <div className="text-center py-10 text-neutral-500 text-xs">
                Nenhuma inscrição pendente no momento.
              </div>
            ) : (
              <div className="space-y-4">
                {candidates.map((cand) => (
                  <div
                    key={cand.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      cand.status === 'aprovado'
                        ? 'bg-emerald-950/30 border-emerald-500/40'
                        : cand.status === 'rejeitado'
                        ? 'bg-rose-950/20 border-rose-500/30 opacity-70'
                        : 'bg-neutral-950 border-amber-500/30 shadow-md'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-neutral-800">
                      <div className="flex items-start gap-3.5">
                        <div className="w-14 h-14 rounded-2xl overflow-hidden bg-neutral-900 border border-amber-400 shrink-0">
                          {cand.avatar ? (
                            <img src={cand.avatar} alt={cand.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center font-bold text-amber-300 text-lg">
                              {cand.name.charAt(0)}
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-sm text-neutral-100">{cand.name}</h4>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                                cand.status === 'aprovado'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : cand.status === 'rejeitado'
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                              }`}
                            >
                              {cand.status === 'aprovado'
                                ? '✓ Aprovado por você'
                                : cand.status === 'rejeitado'
                                ? 'Rejeitado'
                                : 'Pendente de Aprovação'}
                            </span>
                          </div>
                          <p className="text-xs text-neutral-400 mt-0.5">
                            {cand.phone} • {cand.email} • {cand.experienceYears} anos de experiência
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-start">
                        {cand.status !== 'aprovado' && (
                          <button
                            onClick={() => handleApproveCandidate(cand)}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Aprovar Cartomante</span>
                          </button>
                        )}

                        {cand.status !== 'rejeitado' && (
                          <button
                            onClick={() => handleRejectCandidate(cand.id)}
                            className="px-3 py-1.5 bg-neutral-800 hover:bg-rose-950 hover:text-rose-200 text-neutral-400 font-semibold text-xs rounded-xl flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Rejeitar</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-neutral-500 block font-medium">Link do Grupo do WhatsApp:</span>
                        <a
                          href={cand.groupLink}
                          target="_blank"
                          rel="noreferrer"
                          className="text-emerald-400 hover:underline flex items-center gap-1 font-semibold break-all"
                        >
                          <span>{cand.groupLink}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </a>
                      </div>

                      <div>
                        <span className="text-neutral-500 block font-medium">Valores Fixos:</span>
                        <span className="text-amber-300 font-bold">1 Pergunta: R$ 20,00 | 3 Perguntas: R$ 50,00</span>
                      </div>
                    </div>

                    <div className="mt-2.5 text-xs text-neutral-300">
                      <span className="text-neutral-500">Bio:</span> {cand.bio}
                    </div>

                    <div className="mt-2 flex flex-wrap gap-1">
                      {cand.deckTypes.map((deck, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-[10px] rounded text-neutral-300">
                          {deck}
                        </span>
                      ))}
                      {cand.specialties.map((spec, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-purple-950/60 border border-purple-800/40 text-[10px] rounded text-purple-200">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: GENERAL CONFIGURATIONS & PIX */}
        {/* ======================================================== */}
        {activeTab === 'config' && (
          <div>
            <form onSubmit={handleSaveGeneralConfig} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                    Valor de 1 Pergunta (R$)
                  </label>
                  <input
                    type="number"
                    value={formData.price1Question || 20}
                    onChange={(e) => setFormData({ ...formData, price1Question: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    Valor de 3 Perguntas (R$)
                  </label>
                  <input
                    type="number"
                    value={formData.price3Questions || 50}
                    onChange={(e) => setFormData({ ...formData, price3Questions: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  Número do WhatsApp Principal do Site (com DDI e DDD)
                </label>
                <input
                  type="text"
                  value={formData.phoneWhatsApp}
                  onChange={(e) => setFormData({ ...formData, phoneWhatsApp: e.target.value })}
                  placeholder="Ex: 5511999998888"
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-200"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                  Link do Grupo de WhatsApp Geral dos Clientes
                </label>
                <input
                  type="url"
                  value={formData.groupWhatsAppLink}
                  onChange={(e) => setFormData({ ...formData, groupWhatsAppLink: e.target.value })}
                  placeholder="https://chat.whatsapp.com/..."
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-200"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1 flex items-center gap-1.5">
                  <Facebook className="w-3.5 h-3.5 text-blue-400" />
                  Link da Página / Grupo do Facebook (Clonagem & Social)
                </label>
                <input
                  type="url"
                  value={formData.facebookLink || ''}
                  onChange={(e) => setFormData({ ...formData, facebookLink: e.target.value })}
                  placeholder="https://facebook.com/cartomante24h.oficial"
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-200"
                />
              </div>

              {/* PIX Key Configuration */}
              <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-amber-400" />
                  Dados do PIX para Recebimento de Jogos
                </h3>

                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Chave PIX (E-mail, CPF, CNPJ ou Telefone)</label>
                  <input
                    type="text"
                    value={formData.pixKey}
                    onChange={(e) => setFormData({ ...formData, pixKey: e.target.value })}
                    placeholder="contato@cartomante24h.com.br"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-200"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-neutral-400 mb-1">Nome do Titular da Chave PIX</label>
                    <input
                      type="text"
                      value={formData.pixReceiverName}
                      onChange={(e) => setFormData({ ...formData, pixReceiverName: e.target.value })}
                      placeholder="Cartomante 24h"
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-200"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-400 mb-1">Cidade do Titular</label>
                    <input
                      type="text"
                      value={formData.pixCity}
                      onChange={(e) => setFormData({ ...formData, pixCity: e.target.value })}
                      placeholder="São Paulo - SP"
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-200"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex items-center justify-between">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  Salvar Todas as Configurações
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
