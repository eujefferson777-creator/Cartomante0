import { useState, useEffect } from 'react';
import { Sparkles, Video, MessageCircle, Star, Users, Volume2, VolumeX, ArrowRight, UserPlus, CheckCircle2, Edit3, ShieldCheck } from 'lucide-react';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import { CartomanteProfile, SiteConfig, UserAccount } from '../types';

interface CartomantesOnDutyProps {
  config: SiteConfig;
  currentUser?: UserAccount | null;
  onSelectCartomanteLive?: (cartomante: CartomanteProfile) => void;
  onSelectCartomanteVideo?: (cartomante: CartomanteProfile) => void;
  onSelectCartomanteWhatsApp: (cartomante: CartomanteProfile) => void;
  onSelectCartomanteWebChat?: (cartomante: CartomanteProfile) => void;
  onSelectPlayWithCartomante: (cartomante: CartomanteProfile, questionsCount: 1 | 3) => void;
  onOpenWorkWithUs: () => void;
  onOpenAdminEdit?: () => void;
}

export function CartomantesOnDuty({
  config,
  currentUser,
  onSelectCartomanteLive,
  onSelectCartomanteVideo,
  onSelectCartomanteWhatsApp,
  onSelectCartomanteWebChat,
  onSelectPlayWithCartomante,
  onOpenWorkWithUs,
  onOpenAdminEdit
}: CartomantesOnDutyProps) {
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [allProfiles, setAllProfiles] = useState<CartomanteProfile[]>(CARTOMANTES_PROFILES);

  // Load dynamically all profiles & approved cartomantes from config or localStorage
  const loadProfiles = () => {
    if (config.customCartomantes && config.customCartomantes.length > 0) {
      setAllProfiles(config.customCartomantes);
      return;
    }

    try {
      const storedAll = localStorage.getItem('cartomante24h_all_cartomantes');
      if (storedAll) {
        const parsed = JSON.parse(storedAll);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setAllProfiles(parsed);
          return;
        }
      }

      const approvedStr = localStorage.getItem('cartomante24h_approved_profiles');
      if (approvedStr) {
        const approved: CartomanteProfile[] = JSON.parse(approvedStr);
        const combined = [...CARTOMANTES_PROFILES];
        approved.forEach((app) => {
          const idx = combined.findIndex((c) => c.id === app.id);
          if (idx >= 0) {
            combined[idx] = app;
          } else {
            combined.push(app);
          }
        });
        setAllProfiles(combined);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadProfiles();
  }, [config]);

  const toggleVoiceGreeting = (id: string, text: string) => {
    if (playingVoiceId === id) {
      window.speechSynthesis?.cancel();
      setPlayingVoiceId(null);
      return;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'pt-BR';
      utterance.rate = 0.95;
      utterance.pitch = 1.05;
      utterance.onend = () => setPlayingVoiceId(null);
      utterance.onerror = () => setPlayingVoiceId(null);
      window.speechSynthesis.speak(utterance);
      setPlayingVoiceId(id);
    }
  };

  return (
    <section id="cartomantes" className="py-16 md:py-24 bg-[#080313] relative border-t border-purple-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            Equipe Aprovada 24 Horas
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-white">
            Escolha a Cartomante para Jogar Suas Cartas
          </h2>
          <p className="mt-3 text-sm sm:text-base text-purple-200/80">
            Mestres consagradas prontas para tirar <strong className="text-purple-300">1 Pergunta (R$ {config.price1Question || 20},00)</strong> ou{' '}
            <strong className="text-emerald-300">3 Perguntas (R$ {config.price3Questions || 50},00)</strong> direto no grupo e no WhatsApp.
          </p>

          {/* Quick Work with us CTA Banner */}
          <div className="mt-4 inline-flex items-center gap-3 p-1.5 pr-4 rounded-full bg-[#130726] border border-purple-500/40 text-xs text-purple-200">
            <span className="px-3 py-1 rounded-full bg-purple-600 text-white font-bold text-[11px]">
              Vagas Abertas
            </span>
            <span>É cartomante e quer atender conosco?</span>
            <button
              onClick={onOpenWorkWithUs}
              className="text-purple-300 font-bold hover:text-white underline cursor-pointer"
            >
              Envie sua inscrição →
            </button>
          </div>
        </div>

        {/* Cartomantes Profiles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {allProfiles.map((c) => {
            const isSpeaking = playingVoiceId === c.id;

            return (
              <div
                key={c.id}
                className="rounded-3xl bg-[#120724] border border-purple-500/30 hover:border-purple-400 transition-all duration-300 overflow-hidden shadow-xl shadow-purple-950/40 flex flex-col justify-between group"
              >
                {/* Photo & Live Status */}
                <div className="relative aspect-[4/3] overflow-hidden bg-[#0a0416]">
                  <img
                    src={c.avatar}
                    alt={c.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-95 group-hover:brightness-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#120724] via-transparent to-transparent" />

                  {/* Online Badge */}
                  <div className="absolute top-3 left-3 bg-[#0a0416]/90 backdrop-blur-md px-2.5 py-1 rounded-xl border border-emerald-500/50 text-[11px] font-bold text-emerald-400 flex items-center gap-1.5 shadow">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    <span>ONLINE NO PLANTÃO</span>
                  </div>

                  {/* Admin Quick Edit Button */}
                  {currentUser?.role === 'admin' && (
                    <button
                      onClick={onOpenAdminEdit}
                      className="absolute top-3 right-3 bg-purple-600 hover:bg-purple-500 text-white px-2.5 py-1 rounded-xl font-bold text-[11px] flex items-center gap-1 shadow-lg transition-all cursor-pointer border border-white/30"
                      title="Editar foto, nome e dados desta cartomante no Painel Admin"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Editar Perfil (Admin)</span>
                    </button>
                  )}

                  {/* Audio Voice Greeting Trigger Button */}
                  <button
                    id={`voice-btn-${c.id}`}
                    onClick={() => toggleVoiceGreeting(c.id, c.voiceGreetingText)}
                    className={`absolute bottom-3 right-3 px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md border transition-all flex items-center gap-1.5 shadow-lg cursor-pointer ${
                      isSpeaking
                        ? 'bg-purple-600 text-white border-purple-400 animate-pulse'
                        : 'bg-[#0e051c]/90 text-purple-200 border-purple-500/40 hover:bg-[#1a0c32]'
                    }`}
                  >
                    {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span>{isSpeaking ? 'Ouvindo...' : 'Ouvir Voz'}</span>
                  </button>
                </div>

                {/* Body Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1 text-purple-300">
                        <Star className="w-4 h-4 fill-purple-400 text-purple-400" />
                        <span className="text-xs font-bold text-white">{c.rating}</span>
                        <span className="text-[11px] text-purple-300/70">({c.consultationsCount} atendimentos)</span>
                      </div>
                      <span className="text-[11px] text-purple-300 font-medium">{c.experienceYears} anos de dons</span>
                    </div>

                    <h3 className="text-xl font-serif font-black text-white">{c.name}</h3>
                    <p className="text-xs text-purple-300 font-medium mb-3">{c.title}</p>
                    <p className="text-xs text-purple-100/80 leading-relaxed mb-4">{c.bio}</p>

                    {/* Specialties Tags */}
                    <div className="flex flex-wrap gap-1.5 mb-6">
                      {c.specialties.map((spec, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-0.5 rounded-lg bg-[#0b0416] text-[11px] font-medium text-purple-200 border border-purple-500/30"
                        >
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions & Question Buttons */}
                  <div className="space-y-2 pt-4 border-t border-purple-500/20">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        id={`play-1-question-${c.id}`}
                        onClick={() => onSelectPlayWithCartomante(c, 1)}
                        className="py-2.5 px-2 bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-black text-xs rounded-xl flex flex-col items-center justify-center shadow-md shadow-purple-950/50 transition-all cursor-pointer"
                      >
                        <span>1 Pergunta</span>
                        <span className="text-[11px] font-extrabold">R$ {config.price1Question || 20},00</span>
                      </button>

                      <button
                        id={`play-3-questions-${c.id}`}
                        onClick={() => onSelectPlayWithCartomante(c, 3)}
                        className="py-2.5 px-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl flex flex-col items-center justify-center shadow-md shadow-emerald-950/50 transition-all cursor-pointer"
                      >
                        <span>3 Perguntas</span>
                        <span className="text-[11px] font-extrabold">R$ {config.price3Questions || 50},00</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        id={`whatsapp-cartomante-${c.id}`}
                        onClick={() => onSelectCartomanteWhatsApp(c)}
                        className="py-2.5 px-2 bg-[#1a0c32] hover:bg-[#251246] border border-purple-500/40 text-purple-200 hover:text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                        <span>WhatsApp VIP</span>
                      </button>

                      <button
                        id={`webchat-cartomante-${c.id}`}
                        onClick={() => onSelectCartomanteWebChat?.(c)}
                        className="py-2.5 px-2 bg-gradient-to-r from-purple-800/80 to-indigo-800/80 hover:from-purple-700 hover:to-indigo-700 border border-purple-400/50 text-purple-100 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md shadow-purple-950/40"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>💬 Chat Web</span>
                      </button>
                    </div>

                    <button
                      id={`live-cartomante-${c.id}`}
                      onClick={() => (onSelectCartomanteLive || onSelectCartomanteVideo)?.(c)}
                      className="w-full py-2.5 px-3 bg-red-950/70 hover:bg-red-900 border border-red-500/50 hover:border-red-400 text-red-200 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-red-950/40"
                    >
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                      <span>🔴 Assistir Live ao Vivo de {c.name.split(' ')[0]}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
