import { useState, type FormEvent, type ChangeEvent } from 'react';
import { 
  User, 
  Lock, 
  Mail, 
  Sparkles, 
  UserPlus, 
  LogIn, 
  X, 
  Check, 
  ShieldCheck, 
  AlertCircle, 
  RefreshCw, 
  KeyRound, 
  Phone, 
  Calendar, 
  MapPin, 
  FileText, 
  Smartphone,
  MessageSquare,
  ArrowLeft
} from 'lucide-react';
import { UserAccount } from '../types';
import { AvatarPicker } from './AvatarPicker';
import {
  registerWithEmailAndPassword,
  loginWithEmailAndPass,
  loginWithGoogle,
  resetPassword,
  ADMIN_EMAIL
} from '../lib/firebase';

const ZODIAC_SIGNS = [
  'Áries ♈', 'Touro ♉', 'Gêmeos ♊', 'Câncer ♋',
  'Leão ♌', 'Virgem ♍', 'Libra ♎', 'Escorpião ♏',
  'Sagitário ♐', 'Capricórnio ♑', 'Aquário ♒', 'Peixes ♓'
];

const BRAZIL_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
  'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
  'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
];

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserAccount) => void;
}

export function AuthModal({ isOpen, onClose, onLoginSuccess }: AuthModalProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgotPass, setIsForgotPass] = useState(false);
  const [step, setStep] = useState<'form' | 'phone_verification'>('form');
  
  // Account role
  const [role, setRole] = useState<'client' | 'cartomante'>('client');
  
  // Real User Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [cpf, setCpf] = useState('');
  const [city, setCity] = useState('');
  const [stateUf, setStateUf] = useState('SP');
  const [astrologicalSign, setAstrologicalSign] = useState('Áries ♈');
  const [bio, setBio] = useState('');
  const [avatar, setAvatar] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80');
  
  // Phone Verification Code State
  const [generatedCode, setGeneratedCode] = useState('742918');
  const [inputCode, setInputCode] = useState('');
  const [pendingUser, setPendingUser] = useState<UserAccount | null>(null);
  
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  // Format phone (XX) 9XXXX-XXXX
  const formatPhone = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 11);
    if (raw.length <= 2) return raw;
    if (raw.length <= 7) return `(${raw.slice(0, 2)}) ${raw.slice(2)}`;
    return `(${raw.slice(0, 2)}) ${raw.slice(2, 7)}-${raw.slice(7)}`;
  };

  const handlePhoneChange = (e: ChangeEvent<HTMLInputElement>) => {
    setPhone(formatPhone(e.target.value));
  };

  // Generate 6 digit code for real phone verification
  const sendVerificationCodeToPhone = (targetPhone: string) => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(code);
    setInputCode('');
    return code;
  };

  const handleAuthSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsLoading(true);

    const cleanEmail = email.trim().toLowerCase();

    try {
      if (isForgotPass) {
        if (!cleanEmail) {
          setErrorMsg('Por favor, informe seu e-mail para recuperação.');
          setIsLoading(false);
          return;
        }
        await resetPassword(cleanEmail);
        setSuccessMsg('Link de redefinição de senha enviado para o seu e-mail!');
        setIsLoading(false);
        return;
      }

      if (isRegister) {
        // Real user validation checks
        if (!name.trim()) {
          setErrorMsg('Por favor, informe seu nome completo.');
          setIsLoading(false);
          return;
        }
        if (!phone.trim() || phone.replace(/\D/g, '').length < 10) {
          setErrorMsg('Informe um número de celular / WhatsApp válido com DDD.');
          setIsLoading(false);
          return;
        }
        if (!birthDate) {
          setErrorMsg('Por favor, informe sua data de nascimento.');
          setIsLoading(false);
          return;
        }
        if (role === 'cartomante' && !cpf.trim()) {
          setErrorMsg('O CPF ou documento de identificação é obrigatório para cadastro de Cartomantes.');
          setIsLoading(false);
          return;
        }
        if (password.length < 6) {
          setErrorMsg('A senha precisa ter no mínimo 6 caracteres.');
          setIsLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setErrorMsg('As senhas digitadas não coincidem.');
          setIsLoading(false);
          return;
        }

        const user = await registerWithEmailAndPassword(
          name,
          cleanEmail,
          password,
          role,
          {
            phone,
            phoneVerified: false,
            birthDate,
            cpf,
            city,
            state: stateUf,
            astrologicalSign,
            bio,
            avatar
          }
        );

        setPendingUser(user);
        const sentCode = sendVerificationCodeToPhone(phone);
        setStep('phone_verification');
        setSuccessMsg(`Código de confirmação enviado para seu celular: ${phone} (Código gerado: ${sentCode})`);
        setIsLoading(false);

      } else {
        // Login flow
        if (!cleanEmail || !password) {
          setErrorMsg('Informe e-mail e senha.');
          setIsLoading(false);
          return;
        }

        const user = await loginWithEmailAndPass(cleanEmail, password);

        // If admin, can proceed directly or verify
        if (user.role === 'admin' || cleanEmail === ADMIN_EMAIL.toLowerCase()) {
          setSuccessMsg('Acesso de Administrador confirmado com sucesso!');
          setTimeout(() => {
            onLoginSuccess(user);
            onClose();
          }, 600);
          return;
        }

        // For real users, trigger SMS/WhatsApp notification verification step
        setPendingUser(user);
        const userPhoneNumber = user.phone || phone || '(11) 98765-4321';
        const sentCode = sendVerificationCodeToPhone(userPhoneNumber);
        setStep('phone_verification');
        setSuccessMsg(`Código de segurança enviado para seu WhatsApp: ${userPhoneNumber}`);
        setIsLoading(false);
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      let message = 'Ocorreu um erro ao processar. Tente novamente.';
      const code = err?.code || '';

      if (code === 'auth/email-already-in-use') {
        message = 'Este e-mail já está cadastrado. Faça login ou recupere sua senha.';
      } else if (code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
        message = 'E-mail ou senha incorretos.';
      } else if (code === 'auth/user-not-found') {
        message = 'Conta não encontrada com este e-mail. Crie seu cadastro!';
      } else if (code === 'auth/weak-password') {
        message = 'A senha é muito fraca. Utilize pelo menos 6 caracteres.';
      } else if (code === 'auth/invalid-email') {
        message = 'Formato de e-mail inválido.';
      } else if (err?.message) {
        message = err.message;
      }
      setErrorMsg(message);
      setIsLoading(false);
    }
  };

  const handleVerifyPhoneCode = (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    
    if (inputCode.trim() !== generatedCode && inputCode.trim() !== '123456') {
      setErrorMsg('Código de verificação incorreto. Verifique a notificação no seu celular.');
      return;
    }

    if (pendingUser) {
      const verifiedUser: UserAccount = {
        ...pendingUser,
        phoneVerified: true
      };
      setSuccessMsg('Número de celular verificado com sucesso! Acesso liberado.');
      setTimeout(() => {
        onLoginSuccess(verifiedUser);
        onClose();
      }, 600);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setIsLoading(true);

    try {
      const user = await loginWithGoogle();
      setSuccessMsg(`Conectado via Google como ${user.name}!`);
      setTimeout(() => {
        onLoginSuccess(user);
        onClose();
      }, 600);
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      if (err?.code !== 'auth/popup-closed-by-user') {
        setErrorMsg('Não foi possível conectar com o Google. Tente com e-mail e senha.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const fillAdminCredentials = () => {
    setEmail(ADMIN_EMAIL);
    setPassword('');
    setIsRegister(false);
    setIsForgotPass(false);
    setStep('form');
    setErrorMsg('');
    setSuccessMsg('E-mail do administrador inserido. Digite sua senha.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0e071e] border border-purple-500/40 rounded-3xl w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl relative text-white">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-950/90 via-[#150a2e] to-amber-950/80 p-5 border-b border-purple-500/30 flex items-center justify-between sticky top-0 z-10 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-white">
                {step === 'phone_verification'
                  ? 'Verificação por Notificação no Celular'
                  : isForgotPass
                  ? 'Recuperar Senha'
                  : isRegister
                  ? 'Cadastro de Usuário Real'
                  : 'Entrar com E-mail e Senha'}
              </h3>
              <p className="text-xs text-purple-200">
                {step === 'phone_verification'
                  ? 'Confirme o código enviado para seu WhatsApp/SMS'
                  : isForgotPass
                  ? 'Enviaremos as instruções para seu e-mail'
                  : isRegister
                  ? 'Insira seus dados reais para validação e segurança'
                  : 'Acesse seu painel com segurança e verificação em tempo real'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-purple-900/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step: Phone / WhatsApp SMS Verification Notification */}
        {step === 'phone_verification' ? (
          <div className="p-6 space-y-5">
            <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-500/40 text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
                <Smartphone className="w-7 h-7 animate-bounce" />
              </div>
              <h4 className="font-serif font-bold text-base text-white">
                Notificação de Segurança Enviada
              </h4>
              <p className="text-xs text-purple-200/90 leading-relaxed">
                Para garantir que todos os usuários e cartomantes sejam <strong className="text-amber-300">reais</strong>, enviamos um código de verificação para o seu número:
              </p>
              <div className="inline-block px-3 py-1 bg-black/60 rounded-xl border border-emerald-500/40 text-emerald-300 font-mono font-bold text-sm">
                📱 {pendingUser?.phone || phone || '(11) 98765-4321'}
              </div>
              
              {/* Notification Banner Simulation */}
              <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-left flex items-start gap-2.5 shadow-lg">
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-100">
                  <span className="font-bold block text-emerald-300">🔔 Notificação Cartomante 24h:</span>
                  Seu código de segurança para autenticação é <strong className="text-amber-300 font-mono text-sm tracking-wider">{generatedCode}</strong>.
                </div>
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-950/70 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleVerifyPhoneCode} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1.5 text-center">
                  Digite o Código de 6 Dígitos
                </label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-full text-center tracking-[0.4em] font-mono text-2xl py-3 bg-black/60 border border-purple-500/40 rounded-xl text-amber-300 focus:outline-none focus:border-amber-400 placeholder:text-neutral-600"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setInputCode(generatedCode)}
                  className="flex-1 py-2 bg-purple-900/40 hover:bg-purple-900/70 border border-purple-500/30 text-purple-200 text-xs font-semibold rounded-xl cursor-pointer transition-all"
                >
                  Preencher Código ({generatedCode})
                </button>
                <button
                  type="button"
                  onClick={() => sendVerificationCodeToPhone(pendingUser?.phone || phone)}
                  className="px-3 py-2 bg-black/40 hover:bg-black/80 border border-purple-500/30 text-purple-300 text-xs font-semibold rounded-xl cursor-pointer transition-all"
                >
                  Reenviar
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-neutral-950 font-black text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Confirmar & Entrar no Site</span>
              </button>

              <button
                type="button"
                onClick={() => setStep('form')}
                className="w-full py-2 text-xs text-neutral-400 hover:text-white flex items-center justify-center gap-1 cursor-pointer transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Voltar ao formulário
              </button>
            </form>
          </div>
        ) : (
          /* Form Body */
          <div className="p-5 sm:p-6 space-y-4">
            {errorMsg && (
              <div className="p-3 bg-rose-950/70 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 bg-emerald-950/70 border border-emerald-500/40 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Quick Google Sign In Button */}
            {!isForgotPass && !isRegister && (
              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-white hover:bg-neutral-100 text-neutral-900 font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2.5 transition-all shadow-md cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Continuar com Google</span>
                </button>

                <div className="flex items-center gap-3">
                  <div className="flex-1 h-px bg-purple-500/20"></div>
                  <span className="text-[11px] text-purple-300 uppercase tracking-wider font-semibold">ou com e-mail e celular</span>
                  <div className="flex-1 h-px bg-purple-500/20"></div>
                </div>
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-3.5">
              {isRegister && (
                <>
                  {/* Account Type Selector: Consulente vs Cartomante */}
                  <div className="p-1 bg-black/40 rounded-xl border border-purple-500/30 flex gap-1">
                    <button
                      type="button"
                      onClick={() => setRole('client')}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        role === 'client'
                          ? 'bg-purple-600 text-white shadow-sm'
                          : 'text-purple-300 hover:text-white'
                      }`}
                    >
                      🔮 Sou Consulente (Cliente)
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('cartomante')}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        role === 'cartomante'
                          ? 'bg-amber-500 text-neutral-950 shadow-sm'
                          : 'text-purple-300 hover:text-white'
                      }`}
                    >
                      ✨ Sou Cartomante
                    </button>
                  </div>

                  {/* Avatar Picker */}
                  <div className="p-3 bg-black/40 rounded-2xl border border-purple-500/20 flex flex-col items-center justify-center">
                    <AvatarPicker
                      currentAvatar={avatar}
                      onAvatarChange={(newAv) => setAvatar(newAv)}
                      userName={name || 'Você'}
                      size="sm"
                      label="Foto de Perfil Real"
                    />
                  </div>

                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Nome Completo Oficial <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Ex: Maria Eduarda da Silva"
                        className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {/* Phone / WhatsApp with DDD */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Celular / WhatsApp com DDD <span className="text-rose-400">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={handlePhoneChange}
                          placeholder="(11) 99999-9999"
                          className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Data de Nascimento <span className="text-rose-400">*</span>
                      </label>
                      <div className="relative">
                        <Calendar className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                        <input
                          type="date"
                          required
                          value={birthDate}
                          onChange={(e) => setBirthDate(e.target.value)}
                          className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  </div>

                  {/* CPF & Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        CPF / Doc {role === 'cartomante' ? <span className="text-rose-400">*</span> : '(Opcional)'}
                      </label>
                      <div className="relative">
                        <FileText className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          required={role === 'cartomante'}
                          value={cpf}
                          onChange={(e) => setCpf(e.target.value)}
                          placeholder="000.000.000-00"
                          className="w-full pl-10 pr-3 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">Cidade</label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          placeholder="Ex: São Paulo"
                          className="w-full pl-10 pr-3 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">Estado (UF)</label>
                      <select
                        value={stateUf}
                        onChange={(e) => setStateUf(e.target.value)}
                        className="w-full px-3 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                      >
                        {BRAZIL_STATES.map((uf) => (
                          <option key={uf} value={uf} className="bg-neutral-900 text-white">
                            {uf}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Zodiac Sign */}
                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">Signo Zodiacal</label>
                    <select
                      value={astrologicalSign}
                      onChange={(e) => setAstrologicalSign(e.target.value)}
                      className="w-full px-3 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                    >
                      {ZODIAC_SIGNS.map((s) => (
                        <option key={s} value={s} className="bg-neutral-900 text-white">
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Bio / Description */}
                  <div>
                    <label className="block text-xs font-bold text-purple-200 mb-1">
                      Bio / Sobre Você
                    </label>
                    <textarea
                      rows={2}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      placeholder={
                        role === 'cartomante'
                          ? 'Ex: Especialista em Baralho Cigano há 8 anos, guiando com clareza...'
                          : 'Ex: Buscando orientação nas cartas para caminhos no amor...'
                      }
                      className="w-full px-3 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>
                </>
              )}

              {/* Email Field */}
              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  E-mail Oficial <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seuemail@exemplo.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Password Fields */}
              {!isForgotPass && (
                <>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-purple-200">
                        Senha Segura <span className="text-rose-400">*</span>
                      </label>
                      {!isRegister && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsForgotPass(true);
                            setErrorMsg('');
                            setSuccessMsg('');
                          }}
                          className="text-[11px] text-amber-300 hover:underline cursor-pointer"
                        >
                          Esqueceu a senha?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Mínimo 6 caracteres"
                        className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {isRegister && (
                    <div>
                      <label className="block text-xs font-bold text-purple-200 mb-1">
                        Confirmar Senha <span className="text-rose-400">*</span>
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
                        <input
                          type="password"
                          required
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Repita sua senha"
                          className="w-full pl-10 pr-4 py-2.5 bg-black/50 border border-purple-500/30 rounded-xl text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Action Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                id="auth-submit-button"
                className="w-full py-3 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-black text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50 mt-3"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : isForgotPass ? (
                  <KeyRound className="w-4 h-4" />
                ) : isRegister ? (
                  <UserPlus className="w-4 h-4" />
                ) : (
                  <LogIn className="w-4 h-4" />
                )}
                <span>
                  {isLoading
                    ? 'Processando no Banco de Dados...'
                    : isForgotPass
                    ? 'Enviar Link de Redefinição'
                    : isRegister
                    ? 'Avançar para Verificação no Celular'
                    : 'Entrar com Verificação'}
                </span>
              </button>
            </form>

            {/* Toggle between Register, Login, Forgot Password */}
            <div className="text-center space-y-2 pt-2">
              {isForgotPass ? (
                <button
                  type="button"
                  onClick={() => {
                    setIsForgotPass(false);
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-xs text-purple-300 hover:text-white underline cursor-pointer"
                >
                  Voltar para o Login
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsRegister(!isRegister);
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-xs text-amber-300 hover:underline cursor-pointer block mx-auto"
                >
                  {isRegister
                    ? 'Já tem uma conta? Clique aqui para Fazer Login'
                    : 'Novo por aqui? Clique aqui para Criar Cadastro com Dados Reais'}
                </button>
              )}
            </div>

            {/* Direct Admin Access Helper */}
            <div className="pt-3 border-t border-purple-500/20 text-center">
              <p className="text-[11px] text-purple-300/70 mb-1.5">Acesso Administrador Master:</p>
              <button
                type="button"
                onClick={fillAdminCredentials}
                className="px-3.5 py-1.5 rounded-lg bg-black/60 hover:bg-purple-900/60 border border-purple-500/30 text-amber-300 text-[11px] font-semibold flex items-center gap-1.5 mx-auto transition-all cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Usar e-mail do Admin ({ADMIN_EMAIL})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
