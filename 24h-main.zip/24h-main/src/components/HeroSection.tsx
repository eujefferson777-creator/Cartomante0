import { Video, MessageCircle, Sparkles, ShieldCheck, Clock, CheckCircle2, ArrowRight, Edit3, Link as LinkIcon, Radio, Music } from 'lucide-react';
import { SiteConfig, UserAccount } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface HeroSectionProps {
  config: SiteConfig;
  currentUser?: UserAccount | null;
  onOpenWhatsAppGroup: () => void;
  onOpenLives: () => void;
  onOpenRadio?: () => void;
  onScrollToPricing: () => void;
  onScrollToFreeDraw: () => void;
  onOpenLinkManager?: (targetLinkId?: string) => void;
}

export function HeroSection({
  config,
  currentUser,
  onOpenWhatsAppGroup,
  onOpenLives,
  onOpenRadio,
  onScrollToPricing,
  onScrollToFreeDraw,
  onOpenLinkManager
}: HeroSectionProps) {
  return (
    <section id="hero" className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 bg-[#07040e]">
      {/* Mystical Cosmic Purple Orbs & Tarot Aura */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-purple-900/30 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-fuchsia-900/20 rounded-full blur-[110px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-1/4 w-[350px] h-[350px] bg-indigo-950/40 rounded-full blur-[100px] pointer-events-none -z-10" />

      {/* Subtle Arcane Tarot Constellation Grid Lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#a855f7_1px,transparent_1px)] [background-size:32px_32px] opacity-10 pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-3xl mx-auto">
          {/* Logo Cat Badge & Live Indicator */}
          <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#120724]/95 border-2 border-purple-500/50 text-white text-xs font-semibold mb-6 shadow-xl shadow-purple-950/50 backdrop-blur-md">
            <div className="w-6 h-6 rounded-full overflow-hidden border border-purple-400 shrink-0">
              <img
                src={catLogo}
                alt="Gatinho Místico"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-purple-100 font-bold">
              {config.heroBadge || 'Plantão Espiritual 24h • Cartomantes em Live ao Vivo'}
            </span>
          </div>

          {/* Main Title with Tarot Mystique */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-black text-white tracking-tight leading-[1.15] drop-shadow-[0_4px_20px_rgba(168,85,247,0.3)]">
            {config.heroTitle || (
              <>
                Cartomante 24h Online{' '}
                <span className="bg-gradient-to-r from-purple-300 via-white to-fuchsia-300 bg-clip-text text-transparent block mt-1">
                  Lives ao Vivo & WhatsApp
                </span>
              </>
            )}
          </h1>

          {/* Subtitle */}
          <p className="mt-5 text-base sm:text-lg text-purple-100/90 leading-relaxed max-w-2xl mx-auto">
            {config.heroSubtitle || (
              <>
                Assista às cartomantes em <strong className="text-white underline decoration-purple-400/60">lives ao vivo</strong> com
                tiragem de cartas na mesa, comente em tempo real e peça suas perguntas. Ouça a nossa <strong className="text-amber-300">Rádio Macumba</strong> com
                toques e pontos sagrados, e participe do <strong className="text-emerald-300">grupo VIP no WhatsApp</strong>.
              </>
            )}
          </p>

          {/* Action CTAs with Admin Quick Link triggers */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-md sm:max-w-none mx-auto relative flex-wrap">
            <div className="relative w-full sm:w-auto">
              <button
                id="hero-whatsapp-group-btn"
                onClick={onOpenWhatsAppGroup}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2.5 shadow-xl shadow-emerald-950/60 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                <span>Entrar no Grupo de WhatsApp</span>
                <ArrowRight className="w-4 h-4 opacity-80" />
              </button>
              {currentUser?.role === 'admin' && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenLinkManager?.('whatsapp');
                  }}
                  className="absolute -top-3 -right-2 bg-purple-600 hover:bg-purple-500 text-white p-1.5 rounded-full border border-white/40 shadow-lg text-[10px] flex items-center gap-1 cursor-pointer z-10"
                  title="Atualizar link deste botão (Admin)"
                >
                  <Edit3 className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="relative w-full sm:w-auto">
              <button
                id="hero-live-stream-btn"
                onClick={onOpenLives}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-purple-700 to-fuchsia-700 hover:from-purple-600 hover:to-fuchsia-600 border-2 border-purple-400/60 text-white font-black text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2.5 shadow-xl shadow-purple-950/60 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
                <span>🔴 Assistir Lives ao Vivo (Comentar & Perguntar)</span>
              </button>
            </div>

            <a
              href="#radio-macumba"
              className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-400/40 text-amber-300 font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Radio className="w-4 h-4 text-amber-400" />
              <span>📻 Rádio Macumba & Espiritualidade</span>
            </a>
          </div>

          {/* Trust Highlights Grid */}
          <div className="mt-12 pt-8 border-t border-purple-500/30 grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
            <div className="p-4 rounded-2xl bg-[#110722]/80 border border-purple-500/30 flex items-start gap-3 shadow-lg shadow-purple-950/30">
              <div className="p-2.5 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">Plantão 24 Horas</h2>
                <p className="text-[11px] text-purple-300/80 mt-0.5">Atendimento de dia, noite e madrugada sem parar</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#110722]/80 border border-purple-500/30 flex items-start gap-3 shadow-lg shadow-purple-950/30">
              <div className="p-2.5 rounded-xl bg-red-600/20 border border-red-500/40 text-red-300">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">Lives com Cartomantes</h2>
                <p className="text-[11px] text-purple-300/80 mt-0.5">Assista, comente e peça perguntas na mesa ao vivo</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#110722]/80 border border-purple-500/30 flex items-start gap-3 shadow-lg shadow-purple-950/30">
              <div className="p-2.5 rounded-xl bg-amber-600/20 border border-amber-500/40 text-amber-300">
                <Radio className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">Rádio Macumba 24H</h2>
                <p className="text-[11px] text-purple-300/80 mt-0.5">Pontos, toques sagrados e energias de fé</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#110722]/80 border border-purple-500/30 flex items-start gap-3 shadow-lg shadow-purple-950/30">
              <div className="p-2.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">Comunidade VIP</h2>
                <p className="text-[11px] text-purple-300/80 mt-0.5">Tiragens, conselhos e grupos no WhatsApp</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#110722]/80 border border-purple-500/30 flex items-start gap-3 shadow-lg shadow-purple-950/30">
              <div className="p-2.5 rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-300">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xs font-bold text-white">100% Sigiloso</h2>
                <p className="text-[11px] text-purple-300/80 mt-0.5">Ética, acolhimento e discrição absoluta</p>
              </div>
            </div>
          </div>

          {/* Quick Free Oracle Teaser Banner */}
          <div className="mt-8 p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-[#1a0f33] to-purple-950/60 border border-purple-500/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-left shadow-xl shadow-purple-950/40">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-400 text-purple-200 flex items-center justify-center font-bold">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h2 className="text-xs sm:text-sm font-bold text-white">Experimente Grátis: Tire a sua Carta do Dia</h2>
                <p className="text-xs text-purple-200/80">Receba uma revelação imediata e conselho espiritual em poucos segundos.</p>
              </div>
            </div>
            <button
              id="hero-free-draw-btn"
              onClick={onScrollToFreeDraw}
              className="px-4 py-2 text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white border border-purple-400 rounded-xl transition-all whitespace-nowrap cursor-pointer shadow-md shadow-purple-900/40"
            >
              Tirar Carta Agora
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
