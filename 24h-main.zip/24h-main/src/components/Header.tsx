import { Moon, Video, Users, Sparkles, MessageCircle, Settings, Shield, User, LogIn, UserPlus, ShieldCheck, Link as LinkIcon, Edit3, Facebook, Radio, Gamepad2 } from 'lucide-react';
import { SiteConfig, UserAccount } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface HeaderProps {
  config: SiteConfig;
  currentUser: UserAccount | null;
  onOpenAdmin: () => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenWorkWithUs: () => void;
  onOpenWhatsAppGroup: () => void;
  onOpenLinkManager?: (targetLinkId?: string) => void;
  onOpenCommunity?: () => void;
  onOpenLives?: () => void;
  onOpenRadio?: () => void;
}

export function Header({
  config,
  currentUser,
  onOpenAdmin,
  onOpenAuth,
  onOpenProfile,
  onOpenWorkWithUs,
  onOpenWhatsAppGroup,
  onOpenLinkManager,
  onOpenCommunity,
  onOpenLives,
  onOpenRadio
}: HeaderProps) {
  return (
    <header id="main-header" className="sticky top-0 z-40 w-full bg-[#080411]/90 backdrop-blur-md border-b border-purple-500/30 text-white">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-purple-950/95 via-[#180d30] to-purple-950/95 border-b border-purple-500/30 px-3 py-1.5 text-center text-xs font-medium flex items-center justify-center gap-2 flex-wrap text-purple-100">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span className="text-white font-semibold">{config.onlineNotice}</span>
        <span className="hidden md:inline text-purple-400">•</span>
        <span className="text-purple-200 font-bold">1 Pergunta: R$ {config.price1Question?.toFixed(2).replace('.', ',') || '20,00'} | 3 Perguntas: R$ {config.price3Questions?.toFixed(2).replace('.', ',') || '50,00'}</span>
        <span className="hidden md:inline text-purple-400">•</span>
        <button
          onClick={onOpenWorkWithUs}
          className="text-emerald-300 hover:text-emerald-200 underline font-semibold cursor-pointer"
        >
          Trabalhe Conosco (Cartomante)
        </button>

        {currentUser?.role === 'admin' && (
          <button
            onClick={() => onOpenLinkManager?.('whatsapp')}
            className="ml-2 px-2 py-0.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-bold flex items-center gap-1 shadow cursor-pointer transition-all"
            title="Atualizar Links e Textos do Topo"
          >
            <LinkIcon className="w-3 h-3" />
            <span>Atualizar Links (Admin)</span>
          </button>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand Logo with Mystical Cat Emblem */}
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="relative w-11 h-11 rounded-2xl bg-[#0e071c] border-2 border-purple-500/60 flex items-center justify-center overflow-hidden shadow-lg shadow-purple-950/60 group-hover:scale-105 group-hover:border-purple-400 transition-all">
            <img
              src={catLogo}
              alt="Logo Gatinho Místico - Cartomante 24h"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 ring-1 ring-inset ring-purple-400/40 rounded-2xl pointer-events-none" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-serif font-black tracking-wide text-white drop-shadow-[0_2px_10px_rgba(168,85,247,0.5)]">
                CARTOMANTE
              </span>
              <span className="text-xs font-black px-1.5 py-0.5 rounded bg-gradient-to-r from-purple-500 to-fuchsia-500 text-white tracking-wider shadow-sm">
                24H
              </span>
            </div>
            <p className="text-[10px] text-purple-300/80 tracking-wider uppercase flex items-center gap-1">
              <span>{config.siteSlogan || 'Tarot Místico & WhatsApp 24h'}</span>
            </p>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-purple-200">
          <button
            onClick={onOpenCommunity}
            className="hover:text-white transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-900/70 border border-purple-500/30 text-purple-200 font-bold cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>🌟 Comunidade & Feed</span>
          </button>

          <button
            onClick={onOpenLives}
            className="hover:text-white transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900/80 border border-red-500/40 text-red-200 font-bold cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            <span>🔴 Lives Ao Vivo</span>
          </button>

          <a
            href="#radio-macumba"
            onClick={onOpenRadio}
            className="hover:text-amber-200 transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 text-amber-300 font-bold cursor-pointer"
          >
            <Radio className="w-4 h-4 text-amber-400" />
            <span>📻 Rádio Macumba</span>
          </a>

          <a
            href="#jogos-misticos"
            className="hover:text-amber-200 transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/80 border border-purple-400/40 text-amber-300 font-bold cursor-pointer"
          >
            <Gamepad2 className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>🎮 Jogos & Distrações</span>
          </a>

          <a href="#valores" className="hover:text-white transition-colors">
            Valores
          </a>
          <a href="#cartomantes" className="hover:text-white transition-colors flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-purple-400" />
            Cartomantes
          </a>
          <a href="#grupo-whatsapp" className="hover:text-emerald-300 transition-colors flex items-center gap-1">
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            Grupo VIP
          </a>
          <a
            href={config.facebookLink || 'https://facebook.com/cartomante24h.oficial'}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-blue-300 transition-colors flex items-center gap-1 text-blue-400"
            title="Facebook Oficial Cartomante 24h"
          >
            <Facebook className="w-3.5 h-3.5" />
            Facebook
          </a>
          <a href="#oraculo-gratis" className="hover:text-purple-200 transition-colors flex items-center gap-1 text-purple-300">
            Tiragem Grátis
          </a>
        </nav>

        {/* User Profile & Admin Actions */}
        <div className="flex items-center gap-2">
          {/* Quick Link Editor Trigger for Admin */}
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => onOpenLinkManager?.('all')}
              className="px-2.5 py-1.5 rounded-xl bg-purple-600/90 hover:bg-purple-500 border border-purple-400 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-purple-900/40 transition-all cursor-pointer"
              title="Gerenciador Rápido de Todos os Links & Cliques"
            >
              <LinkIcon className="w-3.5 h-3.5 text-purple-200" />
              <span className="hidden sm:inline">Atualizar Links</span>
            </button>
          )}

          {/* Admin Master Panel Button */}
          <button
            id="header-admin-btn"
            onClick={onOpenAdmin}
            title="Painel Master Admin Eu (Aprovar Cartomantes & Configurações)"
            className={`p-2 rounded-xl border transition-all flex items-center gap-1 text-xs font-bold cursor-pointer ${
              currentUser?.role === 'admin'
                ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white border-purple-400 shadow-lg shadow-purple-900/40'
                : 'text-purple-300 hover:text-white hover:bg-purple-950/60 border-purple-500/30'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-purple-200" />
            <span className="hidden sm:inline">Admin Eu</span>
          </button>

          {/* Mobile quick community button */}
          <button
            onClick={onOpenCommunity}
            className="lg:hidden p-2 rounded-xl bg-purple-900/50 hover:bg-purple-800 border border-purple-400/40 text-amber-300 transition-all cursor-pointer"
            title="Comunidade & Feed"
            aria-label="Comunidade e Feed"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* User Auth or Profile Button */}
          {currentUser ? (
            <button
              id="header-profile-btn"
              onClick={onOpenProfile}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#140b27] hover:bg-[#1a0f33] border border-purple-500/40 text-xs text-white transition-all cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-purple-600/30 border border-purple-400 flex items-center justify-center text-purple-200 text-xs font-bold overflow-hidden">
                {currentUser.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  currentUser.name.charAt(0).toUpperCase()
                )}
              </div>
              <span className="max-w-[100px] truncate hidden md:inline font-semibold">
                {currentUser.name.split(' ')[0]}
              </span>
            </button>
          ) : (
            <button
              id="header-login-btn"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#140b27] hover:bg-[#1c0f38] border border-purple-500/40 text-xs font-semibold text-white transition-all cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5 text-purple-400" />
              <span>Entrar / Perfil</span>
            </button>
          )}

          <button
            id="header-whatsapp-btn"
            onClick={onOpenWhatsAppGroup}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-neutral-950 font-bold text-xs shadow-md shadow-emerald-900/30 transition-all cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-neutral-950" />
            <span className="hidden sm:inline">Grupo 24h</span>
          </button>
        </div>
      </div>
    </header>
  );
}
