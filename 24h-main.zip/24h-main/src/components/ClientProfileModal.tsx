import { useState, type FormEvent } from 'react';
import { User, Phone, Mail, Sparkles, X, Check, Clock, Calendar, Heart, Shield, LogOut, MessageCircle, Video, Camera } from 'lucide-react';
import { UserAccount, ClientProfileData, SiteConfig } from '../types';
import { AvatarPicker } from './AvatarPicker';

interface ClientProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount | null;
  config: SiteConfig;
  onLogout: () => void;
  onOpenVideoRoom?: () => void;
  onOpenLives?: () => void;
  onOpenWhatsAppDirect: (topic: string, price: number) => void;
  onUpdateUser?: (updatedUser: UserAccount) => void;
}

export function ClientProfileModal({
  isOpen,
  onClose,
  currentUser,
  config,
  onLogout,
  onOpenVideoRoom,
  onOpenWhatsAppDirect,
  onUpdateUser
}: ClientProfileModalProps) {
  if (!isOpen || !currentUser) return null;

  // Profile data from storage or default
  const [profileData, setProfileData] = useState<ClientProfileData>(() => {
    const saved = localStorage.getItem(`cartomante24h_profile_${currentUser.id}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          avatar: parsed.avatar || currentUser.avatar
        };
      } catch (e) {
        console.error(e);
      }
    }
    return {
      userId: currentUser.id,
      name: currentUser.name,
      email: currentUser.email,
      phone: currentUser.phone || '(11) 98765-4321',
      birthDate: currentUser.birthDate || '1995-06-15',
      astrologicalSign: 'Gêmeos ♊',
      preferredDeck: 'cigano',
      avatar: currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      notes: 'Gosto de leituras focadas no amor, reconciliação e abertura de caminhos financeiros.',
      consultationsHistory: [
        {
          id: 'cons-101',
          date: '14/08/2026',
          type: '3 Perguntas Completas (R$ 50,00)',
          questionsCount: 3,
          price: 50.0,
          cartomanteName: 'Mãe Yara do Oriente',
          status: 'concluida'
        },
        {
          id: 'cons-102',
          date: '10/08/2026',
          type: '1 Pergunta Direta (R$ 20,00)',
          questionsCount: 1,
          price: 20.0,
          cartomanteName: 'Mestra Serena d’Arc',
          status: 'concluida'
        }
      ]
    };
  });

  const [isEditing, setIsEditing] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleAvatarChange = (newAvatarUrl: string) => {
    const updatedProfile = { ...profileData, avatar: newAvatarUrl };
    setProfileData(updatedProfile);
    localStorage.setItem(`cartomante24h_profile_${currentUser.id}`, JSON.stringify(updatedProfile));

    // Update currentUser
    const updatedUser: UserAccount = {
      ...currentUser,
      avatar: newAvatarUrl
    };
    localStorage.setItem('cartomante24h_current_user', JSON.stringify(updatedUser));

    // Update user in users list
    const users: UserAccount[] = JSON.parse(localStorage.getItem('cartomante24h_users') || '[]');
    const updatedUsers = users.map((u) => (u.id === currentUser.id ? { ...u, avatar: newAvatarUrl } : u));
    localStorage.setItem('cartomante24h_users', JSON.stringify(updatedUsers));

    if (onUpdateUser) {
      onUpdateUser(updatedUser);
    }

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleSaveProfile = (e: FormEvent) => {
    e.preventDefault();
    localStorage.setItem(`cartomante24h_profile_${currentUser.id}`, JSON.stringify(profileData));
    
    // Also sync user name & phone
    const updatedUser: UserAccount = {
      ...currentUser,
      name: profileData.name,
      phone: profileData.phone,
      birthDate: profileData.birthDate,
      avatar: profileData.avatar
    };
    localStorage.setItem('cartomante24h_current_user', JSON.stringify(updatedUser));
    
    if (onUpdateUser) {
      onUpdateUser(updatedUser);
    }

    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-neutral-900 border border-amber-500/40 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl relative">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-purple-950/80 via-neutral-900 to-amber-950/80 p-6 border-b border-neutral-800 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3.5">
            <AvatarPicker
              currentAvatar={profileData.avatar || currentUser.avatar}
              onAvatarChange={handleAvatarChange}
              userName={currentUser.name}
              size="sm"
              label="Trocar Foto"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif font-bold text-lg text-neutral-100">{currentUser.name}</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 uppercase">
                  {currentUser.role === 'admin' ? 'Administrador' : 'Cliente VIP'}
                </span>
              </div>
              <p className="text-xs text-neutral-400">{currentUser.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              title="Sair da Conta"
              className="p-2 rounded-xl text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6">
          {savedSuccess && (
            <div className="p-3 bg-emerald-950/70 border border-emerald-500/50 rounded-2xl text-emerald-200 text-xs flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>Foto e dados do perfil atualizados com sucesso!</span>
            </div>
          )}

          {/* Quick Action Bar for Questions */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-neutral-950 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider block">
                Atendimento Rápido 24h
              </span>
              <p className="text-xs text-neutral-300">
                1 Pergunta: <strong className="text-amber-300">R$ 20,00</strong> • 3 Perguntas:{' '}
                <strong className="text-emerald-300">R$ 50,00</strong>
              </p>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => {
                  onClose();
                  onOpenWhatsAppDirect('1 Pergunta Direta', 20.0);
                }}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>1 Pergunta (R$ 20)</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenWhatsAppDirect('3 Perguntas Completas', 50.0);
                }}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>3 Perguntas (R$ 50)</span>
              </button>
            </div>
          </div>

          {/* Profile Details (View or Edit mode) */}
          <div className="bg-neutral-950/70 border border-neutral-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-neutral-800">
              <h4 className="text-sm font-bold text-neutral-200 flex items-center gap-1.5">
                <User className="w-4 h-4 text-amber-400" />
                Informações Pessoais & Espirituais
              </h4>
              <button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs text-amber-400 hover:underline cursor-pointer"
              >
                {isEditing ? 'Cancelar Edição' : 'Editar Dados'}
              </button>
            </div>

            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="space-y-4">
                {/* Avatar Picker in Edit View */}
                <div className="p-3 bg-neutral-900/60 rounded-xl border border-neutral-800 flex items-center justify-center">
                  <AvatarPicker
                    currentAvatar={profileData.avatar}
                    onAvatarChange={handleAvatarChange}
                    userName={profileData.name}
                    size="md"
                    label="Alterar Foto de Perfil"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-400 mb-1">Nome</label>
                    <input
                      type="text"
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-400 mb-1">WhatsApp</label>
                    <input
                      type="text"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-400 mb-1">Data de Nascimento</label>
                    <input
                      type="date"
                      value={profileData.birthDate}
                      onChange={(e) => setProfileData({ ...profileData, birthDate: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-400 mb-1">Signo Zodiacal</label>
                    <input
                      type="text"
                      value={profileData.astrologicalSign}
                      onChange={(e) => setProfileData({ ...profileData, astrologicalSign: e.target.value })}
                      placeholder="Ex: Áries, Touro, Gêmeos..."
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-400 mb-1">
                    Interesses & Notas para as Cartomantes
                  </label>
                  <textarea
                    rows={2}
                    value={profileData.notes}
                    onChange={(e) => setProfileData({ ...profileData, notes: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                  />
                </div>

                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer"
                >
                  Salvar Alterações
                </button>
              </form>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-neutral-500 block">WhatsApp:</span>
                  <span className="text-neutral-200 font-semibold">{profileData.phone || 'Não informado'}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Nascimento:</span>
                  <span className="text-neutral-200 font-semibold">{profileData.birthDate || 'Não informado'}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Signo:</span>
                  <span className="text-amber-300 font-semibold">{profileData.astrologicalSign}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Oráculo Preferido:</span>
                  <span className="text-neutral-200 font-semibold">Baralho Cigano</span>
                </div>
              </div>
            )}
          </div>

          {/* Consultations History */}
          <div>
            <h4 className="text-sm font-bold text-neutral-200 mb-3 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-emerald-400" />
              Histórico de Jogos & Consultas
            </h4>

            <div className="space-y-2.5">
              {profileData.consultationsHistory.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <span className="font-bold text-neutral-200 block">{item.type}</span>
                    <span className="text-neutral-400 text-[11px]">
                      Atendido(a) por: <strong className="text-amber-300">{item.cartomanteName}</strong> em {item.date}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-emerald-400 font-bold block">
                      R$ {item.price.toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                      Concluída
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
