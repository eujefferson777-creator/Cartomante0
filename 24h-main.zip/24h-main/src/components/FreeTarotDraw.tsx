import { useState } from 'react';
import { Sparkles, RotateCw, Video, MessageCircle, Heart, DollarSign, Shield, ArrowRight, Check } from 'lucide-react';
import { TAROT_CARDS } from '../data/tarotCards';
import { TarotCard, SiteConfig } from '../types';

interface FreeTarotDrawProps {
  config: SiteConfig;
  onOpenLiveWithQuestion: (question: string) => void;
  onOpenWhatsAppDirect: (topic: string, price: number) => void;
}

export function FreeTarotDraw({ config, onOpenLiveWithQuestion, onOpenWhatsAppDirect }: FreeTarotDrawProps) {
  const [topic, setTopic] = useState<'amor' | 'dinheiro' | 'espiritual' | 'geral'>('amor');
  const [clientName, setClientName] = useState('');
  const [question, setQuestion] = useState('');
  const [selectedCards, setSelectedCards] = useState<TarotCard[]>([]);
  const [isRevealed, setIsRevealed] = useState(false);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [aiInterpretation, setAiInterpretation] = useState<string | null>(null);

  const availableCards = TAROT_CARDS.slice(0, 12);

  const handleCardClick = (card: TarotCard) => {
    if (isRevealed) return;
    if (selectedCards.some((c) => c.id === card.id)) return;

    const newSelection = [...selectedCards, card];
    setSelectedCards(newSelection);

    // If 1 card selected, ready to interpret or user can choose up to 3
  };

  const handleRevealReading = async () => {
    if (selectedCards.length === 0) return;
    setIsRevealed(true);
    setIsLoadingAi(true);

    try {
      const response = await fetch('/api/oracle/reading', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: question || `Tiragem de cartas sobre ${topic}`,
          cards: selectedCards.map((c, idx) => ({
            name: c.name,
            summary: c.summary,
            positionName: idx === 0 ? 'Energia Central' : idx === 1 ? 'Desafio / Oportunidade' : 'Desfecho Astral'
          })),
          deckType: 'Baralho Cigano Tradicional',
          clientName: clientName || 'Irmão(ã) de Luz'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAiInterpretation(data.reading);
      } else {
        setAiInterpretation(
          `A carta ${selectedCards[0].name} indica forte abertura para seus caminhos em ${topic}. Acalme seu coração e mantenha a fé, pois novidades positivas estão a caminho!`
        );
      }
    } catch (e) {
      setAiInterpretation(
        `A energia de ${selectedCards[0].name} traz um chamado de atenção e proteção espiritual. Confie na sabedoria das cartas!`
      );
    } finally {
      setIsLoadingAi(false);
    }
  };

  const handleResetDraw = () => {
    setSelectedCards([]);
    setIsRevealed(false);
    setAiInterpretation(null);
  };

  return (
    <section id="oraculo-gratis" className="py-16 md:py-24 bg-[#070312] relative overflow-hidden border-t border-purple-500/20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-200 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            Tiragem Grátis Online 24h
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-white">
            Tire uma Carta do Oráculo Sagrado
          </h2>
          <p className="mt-2 text-sm text-purple-200/80">
            Concentre-se em sua dúvida, escolha seu tema e sinta a sabedoria do Baralho Cigano e do Tarot responder ao seu coração.
          </p>
        </div>

        {/* Step 1: Question & Topic Setup */}
        {!isRevealed && (
          <div className="bg-[#110722]/90 border-2 border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl mb-8 shadow-purple-950/60 backdrop-blur-md">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  1. Seu Primeiro Nome (Opcional)
                </label>
                <input
                  type="text"
                  id="free-draw-name-input"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Ex: Beatriz, Carlos..."
                  className="w-full px-3.5 py-2.5 bg-[#0a0416] border border-purple-500/40 rounded-xl text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-purple-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  2. Escolha o Tema da Consulta
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setTopic('amor')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      topic === 'amor'
                        ? 'bg-rose-950/80 border-rose-400 text-rose-100 shadow-md shadow-rose-950/50'
                        : 'bg-[#0a0416] border-purple-500/30 text-purple-300 hover:text-white'
                    }`}
                  >
                    <Heart className="w-3.5 h-3.5 text-rose-400" />
                    <span>Amor</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTopic('dinheiro')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      topic === 'dinheiro'
                        ? 'bg-emerald-950/80 border-emerald-400 text-emerald-100 shadow-md shadow-emerald-950/50'
                        : 'bg-[#0a0416] border-purple-500/30 text-purple-300 hover:text-white'
                    }`}
                  >
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Finanças</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTopic('espiritual')}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      topic === 'espiritual'
                        ? 'bg-purple-900/80 border-purple-300 text-purple-100 shadow-md shadow-purple-950/50'
                        : 'bg-[#0a0416] border-purple-500/30 text-purple-300 hover:text-white'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5 text-purple-300" />
                    <span>Caminhos</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-xs font-bold text-white mb-1.5">
                3. Digite sua Dúvida ou Pense com Firmeza
              </label>
              <input
                type="text"
                id="free-draw-question-input"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ex: Vou ter volta com meu amor? Vou conseguir o emprego este mês?"
                className="w-full px-3.5 py-2.5 bg-[#0a0416] border border-purple-500/40 rounded-xl text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-purple-300"
              />
            </div>

            {/* Interactive Card Selection Deck */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-purple-200">
                  4. Clique em até 3 cartas abaixo para puxar sua tiragem ({selectedCards.length}/3 selecionadas):
                </span>
                {selectedCards.length > 0 && (
                  <button
                    onClick={handleRevealReading}
                    className="px-4 py-1.5 bg-gradient-to-r from-purple-600 via-fuchsia-600 to-purple-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-black text-xs rounded-xl shadow-lg shadow-purple-900/50 transition-all cursor-pointer"
                  >
                    Revelar Interpretação ✨
                  </button>
                )}
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-12 gap-2">
                {availableCards.map((card, idx) => {
                  const isPicked = selectedCards.some((c) => c.id === card.id);
                  return (
                    <button
                      key={card.id}
                      type="button"
                      onClick={() => handleCardClick(card)}
                      className={`aspect-[2/3] rounded-xl border transition-all duration-300 flex flex-col items-center justify-center p-1 relative group cursor-pointer ${
                        isPicked
                          ? 'bg-[#261048] border-purple-300 ring-2 ring-purple-400 -translate-y-2 shadow-lg shadow-purple-900/60'
                          : 'bg-gradient-to-b from-[#180d32] to-[#0d061c] border-purple-500/40 hover:border-purple-300 hover:-translate-y-1'
                      }`}
                    >
                      {isPicked ? (
                        <div className="text-center">
                          <span className="text-lg">{card.imageIcon}</span>
                          <span className="text-[9px] font-bold text-white block line-clamp-1">
                            {card.name.split('-')[0]}
                          </span>
                        </div>
                      ) : (
                        <div className="text-center">
                          <span className="text-purple-300 font-serif text-sm opacity-80 group-hover:scale-110 transition-transform block">
                            ✦
                          </span>
                          <span className="text-[9px] text-purple-400/60 mt-1 block">#{idx + 1}</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Revealed Reading */}
        {isRevealed && (
          <div className="bg-[#110722] border-2 border-purple-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl animate-fadeIn shadow-purple-950/70">
            <div className="flex items-center justify-between pb-4 border-b border-purple-500/30">
              <div className="flex items-center gap-2 text-purple-300">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg font-serif font-black text-white">
                  Revelação do Oráculo Espiritual 24h
                </h3>
              </div>
              <button
                onClick={handleResetDraw}
                className="px-3 py-1.5 text-xs text-purple-200 hover:text-white flex items-center gap-1 bg-[#1d0e38] border border-purple-500/40 rounded-xl transition-all cursor-pointer"
              >
                <RotateCw className="w-3.5 h-3.5" /> Tirar Novamente
              </button>
            </div>

            {/* Revealed Cards Header */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-6">
              {selectedCards.map((card, idx) => (
                <div key={card.id} className="p-4 rounded-2xl bg-[#0b0416] border border-purple-500/40 text-center shadow-lg shadow-purple-950/40">
                  <div className="text-3xl mb-1">{card.imageIcon}</div>
                  <span className="text-[10px] text-purple-300 uppercase font-black tracking-wider">
                    {idx === 0 ? 'Momento Atual' : idx === 1 ? 'Obstáculo / Influência' : 'Caminho Futuro'}
                  </span>
                  <h4 className="text-sm font-serif font-bold text-white mt-0.5">{card.name}</h4>
                  <p className="text-xs text-purple-200/80 mt-2 leading-relaxed">{card.summary}</p>
                </div>
              ))}
            </div>

            {/* AI Canalized Interpretation */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-[#180c30] to-purple-950/60 border border-purple-500/40 shadow-inner">
              <h4 className="text-xs font-bold uppercase tracking-wider text-purple-200 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-300" />
                Mensagem Canalizada pela Cartomante
              </h4>

              {isLoadingAi ? (
                <div className="py-6 flex flex-col items-center justify-center text-purple-300 gap-2">
                  <div className="w-6 h-6 border-2 border-purple-400 border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-xs text-purple-200">Canalizando as vibrações astrais das cartas...</span>
                </div>
              ) : (
                <div className="text-sm text-white leading-relaxed whitespace-pre-line space-y-3">
                  {aiInterpretation}
                </div>
              )}
            </div>

            {/* High Converting Next Step CTAs */}
            <div className="mt-8 pt-6 border-t border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-white">
                  Deseja aprofundar essa resposta ao vivo?
                </h4>
                <p className="text-xs text-purple-200/80">
                  Entre na live das cartomantes, comente em tempo real e tire sua dúvida na mesa!
                </p>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                <button
                  id="open-live-from-draw-btn"
                  onClick={() => onOpenLiveWithQuestion(question)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-red-600 via-purple-600 to-fuchsia-600 hover:from-red-500 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-lg shadow-purple-950/60 transition-all cursor-pointer"
                >
                  <span className="w-2 h-2 rounded-full bg-red-400 animate-ping"></span>
                  <span>Perguntar em Live ao Vivo</span>
                </button>

                <button
                  id="open-whatsapp-from-draw-btn"
                  onClick={() => onOpenWhatsAppDirect(question || 'Tiragem do Oráculo', 39.90)}
                  className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
