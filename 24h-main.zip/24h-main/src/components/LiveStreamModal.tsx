import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Video, 
  MessageCircle, 
  Users, 
  Sparkles, 
  Send, 
  ShieldCheck, 
  ExternalLink, 
  Radio, 
  Eye, 
  Heart, 
  Volume2, 
  VolumeX, 
  Camera, 
  Mic, 
  MicOff, 
  Play, 
  Square, 
  Plus, 
  Share2,
  Check,
  SwitchCamera,
  AlertCircle,
  UserCheck,
  Crown,
  HelpCircle,
  ThumbsUp,
  Flame,
  Music,
  Layers
} from 'lucide-react';
import { LiveStreamSession, LiveChatMessage, LiveQuestion, UserAccount, SiteConfig } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';
import { TAROT_CARDS } from '../data/tarotCards';
import { spiritualAudioEngine } from '../lib/spiritualAudioEngine';
import { 
  subscribeToLivePresence, 
  joinLivePresence, 
  leaveLivePresence, 
  subscribeToLiveMessages, 
  sendLiveMessage, 
  subscribeToLiveQuestions,
  sendLiveQuestion,
  updateLiveQuestion,
  upvoteLiveQuestion,
  endLiveStream,
  LiveViewerPresence
} from '../lib/firebase';

interface LiveStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  stream: LiveStreamSession | null;
  currentUser: UserAccount | null;
  config: SiteConfig;
  onEndStream?: (streamId: string) => void;
  onOpenAuth?: () => void;
}

export function LiveStreamModal({
  isOpen,
  onClose,
  stream,
  currentUser,
  config,
  onEndStream,
  onOpenAuth
}: LiveStreamModalProps) {
  const [messages, setMessages] = useState<LiveChatMessage[]>([]);
  const [realViewers, setRealViewers] = useState<LiveViewerPresence[]>([]);
  const [questions, setQuestions] = useState<LiveQuestion[]>([]);
  const [activeSideTab, setActiveSideTab] = useState<'chat' | 'questions' | 'viewers'>('chat');
  const [inputMessage, setInputMessage] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [revealedCard, setRevealedCard] = useState('O Coração + Os Lírios (Harmonia & Amor Verdadeiro)');
  const [copiedLink, setCopiedLink] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [heartsCount, setHeartsCount] = useState(128);
  const [isRadioPlaying, setIsRadioPlaying] = useState(false);

  // Question Ask Form State
  const [isAskModalOpen, setIsAskModalOpen] = useState(false);
  const [questionText, setQuestionText] = useState('');
  const [questionCategory, setQuestionCategory] = useState<'amor' | 'financeiro' | 'espiritual' | 'saude' | 'geral'>('amor');
  const [questionType, setQuestionType] = useState<'1_pergunta' | '3_perguntas' | 'geral'>('1_pergunta');
  const [questionSentSuccess, setQuestionSentSuccess] = useState(false);

  // Currently answering question on live video screen
  const [currentActiveQuestion, setCurrentActiveQuestion] = useState<LiveQuestion | null>(null);
  const [drawnCardsForQuestion, setDrawnCardsForQuestion] = useState<string[]>([]);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const isBroadcaster = 
    currentUser?.role === 'admin' || 
    currentUser?.role === 'cartomante' ||
    currentUser?.name === stream?.cartomanteName || 
    currentUser?.id === stream?.cartomanteId;

  // 1. Initialize Real Camera when Live is opened
  useEffect(() => {
    if (!isOpen || !stream) {
      stopCamera();
      return;
    }

    // If broadcaster, request real camera and mic
    if (isBroadcaster) {
      startCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, stream?.id, facingMode, isBroadcaster]);

  const startCamera = async () => {
    try {
      setCameraError(null);
      stopCamera(); // Clean previous tracks if any

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError('Seu navegador não suporta acesso direto à câmera.');
        return;
      }

      const streamObj = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: true
      });

      mediaStreamRef.current = streamObj;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = streamObj;
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.warn('Camera access issue:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraError('Permissão de câmera negada. Habilite a câmera nas configurações do seu navegador para transmitir ao vivo.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraError('Nenhuma câmera ou microfone foi detectado no seu dispositivo.');
      } else {
        setCameraError('Não foi possível iniciar a câmera diretamente: ' + (err.message || 'Verifique as permissões.'));
      }
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => {
        track.stop();
      });
      mediaStreamRef.current = null;
    }
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // Toggle Video Track
  const toggleVideoTrack = () => {
    if (mediaStreamRef.current) {
      const videoTrack = mediaStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOn(videoTrack.enabled);
      }
    } else {
      setIsVideoOn(!isVideoOn);
    }
  };

  // Toggle Mic Track
  const toggleMicTrack = () => {
    if (mediaStreamRef.current) {
      const audioTrack = mediaStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMicOn(audioTrack.enabled);
      }
    } else {
      setIsMicOn(!isMicOn);
    }
  };

  // Switch between front/back camera
  const handleFlipCamera = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  // 2. Real-Time Presence: Register user as viewer in Firestore
  useEffect(() => {
    if (!isOpen || !stream) return;

    if (currentUser) {
      joinLivePresence(stream.id, currentUser);
    }

    // Subscribe to live viewers
    const unsubPresence = subscribeToLivePresence(stream.id, (viewers) => {
      setRealViewers(viewers);
    });

    // Subscribe to real-time chat messages
    const unsubMessages = subscribeToLiveMessages(stream.id, (msgs) => {
      if (msgs.length > 0) {
        setMessages(msgs);
      }
    });

    // Subscribe to live questions in the broadcast
    const unsubQuestions = subscribeToLiveQuestions(stream.id, (qList) => {
      if (qList.length > 0) {
        setQuestions(qList);
        const responding = qList.find(q => q.status === 'respondendo');
        if (responding) {
          setCurrentActiveQuestion(responding);
          if (responding.revealedCards && responding.revealedCards.length > 0) {
            setDrawnCardsForQuestion(responding.revealedCards);
          }
        }
      } else {
        // Initial interactive questions in the room
        const initialSeed: LiveQuestion[] = [
          {
            id: 'demo-q-1',
            streamId: stream.id,
            authorId: 'client-demo-1',
            authorName: 'Juliana Mendes',
            authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
            authorRole: 'client',
            question: 'Ele vai me procurar ainda este mês? Tivemos uma briga boba e nos bloqueamos.',
            category: 'amor',
            type: '1_pergunta',
            status: 'respondendo',
            revealedCards: ['O Cavaleiro de Copas', 'Os Enamorados', 'A Estrela Cigana'],
            upvotes: 12,
            createdAt: 'Há 4 min'
          },
          {
            id: 'demo-q-2',
            streamId: stream.id,
            authorId: 'client-demo-2',
            authorName: 'Marcos Vinicius',
            authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
            authorRole: 'client',
            question: 'Vou conseguir fechar o contrato de trabalho ou é melhor aguardar?',
            category: 'financeiro',
            type: '3_perguntas',
            status: 'aguardando',
            upvotes: 7,
            createdAt: 'Há 2 min'
          }
        ];
        setQuestions(initialSeed);
        setCurrentActiveQuestion(initialSeed[0]);
        setDrawnCardsForQuestion(initialSeed[0].revealedCards || []);
      }
    });

    return () => {
      if (currentUser && stream) {
        leaveLivePresence(stream.id, currentUser.id);
      }
      unsubPresence();
      unsubMessages();
      unsubQuestions();
    };
  }, [isOpen, stream?.id, currentUser?.id]);

  // Auto scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen || !stream) return null;

  // Ask Question Submission
  const handleAskQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;

    if (!currentUser) {
      onOpenAuth?.();
      return;
    }

    const price = questionType === '1_pergunta' ? (config.price1Question || 20) : questionType === '3_perguntas' ? (config.price3Questions || 50) : 0;

    const newQuestion: Omit<LiveQuestion, 'id'> = {
      streamId: stream.id,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar || catLogo,
      authorRole: currentUser.role,
      question: questionText.trim(),
      category: questionCategory,
      type: questionType,
      price: price,
      status: 'aguardando',
      upvotes: 1,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const tempId = 'temp-q-' + Date.now();
    setQuestions(prev => [{ id: tempId, ...newQuestion }, ...prev]);
    setActiveSideTab('questions');

    // Announce question in live chat
    const chatAlert: Omit<LiveChatMessage, 'id'> = {
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar || catLogo,
      senderRole: currentUser.role,
      message: `🔮 Pediu uma pergunta na mesa: "${questionText.trim()}"`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isHighlight: true
    };
    setMessages(prev => [...prev, { id: 'temp-' + Date.now(), ...chatAlert }]);

    setQuestionSentSuccess(true);
    setTimeout(() => {
      setQuestionSentSuccess(false);
      setIsAskModalOpen(false);
      setQuestionText('');
    }, 2000);

    try {
      await sendLiveQuestion(stream.id, newQuestion);
      await sendLiveMessage(stream.id, chatAlert);
    } catch (err) {
      console.error('Error submitting live question:', err);
    }
  };

  // Cartomante draws cards for a question live
  const handleAnswerQuestion = async (q: LiveQuestion) => {
    const shuffled = [...TAROT_CARDS].sort(() => 0.5 - Math.random());
    const cards = [shuffled[0].name, shuffled[1].name, shuffled[2].name];

    setCurrentActiveQuestion(q);
    setDrawnCardsForQuestion(cards);
    setRevealedCard(`${cards[0]} + ${cards[1]} (Para ${q.authorName})`);

    setQuestions(prev => prev.map(item => item.id === q.id ? { ...item, status: 'respondendo', revealedCards: cards } : item));

    const announceMsg: Omit<LiveChatMessage, 'id'> = {
      senderId: currentUser?.id || stream.cartomanteId,
      senderName: stream.cartomanteName,
      senderAvatar: stream.cartomanteAvatar,
      senderRole: 'cartomante',
      message: `🃏 Tirando as cartas ao vivo para ${q.authorName}: [${cards.join(' • ')}]. Cartas abertas na mesa!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isHighlight: true
    };
    setMessages(prev => [...prev, { id: 'temp-' + Date.now(), ...announceMsg }]);

    try {
      await updateLiveQuestion(stream.id, q.id, {
        status: 'respondendo',
        revealedCards: cards
      });
      await sendLiveMessage(stream.id, announceMsg);
    } catch (err) {
      console.error('Error answering question:', err);
    }
  };

  // Mark question as finished
  const handleFinishQuestion = async (qId: string) => {
    setQuestions(prev => prev.map(item => item.id === qId ? { ...item, status: 'respondida' } : item));
    if (currentActiveQuestion?.id === qId) {
      setCurrentActiveQuestion(null);
      setDrawnCardsForQuestion([]);
    }
    try {
      await updateLiveQuestion(stream.id, qId, {
        status: 'respondida',
        answeredAt: new Date().toISOString()
      });
    } catch (err) {
      console.error('Error finishing question:', err);
    }
  };

  // Upvote Question
  const handleUpvoteQuestion = async (qId: string, currentVotes: number = 0) => {
    setQuestions(prev => prev.map(item => item.id === qId ? { ...item, upvotes: (item.upvotes || 0) + 1 } : item));
    try {
      await upvoteLiveQuestion(stream.id, qId, currentVotes);
    } catch (err) {
      console.error('Error upvoting question:', err);
    }
  };

  // Toggle Background Rádio Macumba during Live
  const handleToggleRadioInLive = () => {
    if (isRadioPlaying) {
      spiritualAudioEngine.stop();
      setIsRadioPlaying(false);
    } else {
      spiritualAudioEngine.startStation('barravento');
      setIsRadioPlaying(true);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    if (!currentUser) {
      onOpenAuth?.();
      return;
    }

    const newMsg: Omit<LiveChatMessage, 'id'> = {
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar || catLogo,
      senderRole: currentUser.role,
      message: inputMessage.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isHighlight: isBroadcaster
    };

    // Optimistic update
    setMessages((prev) => [
      ...prev,
      { id: 'temp-' + Date.now(), ...newMsg }
    ]);
    setInputMessage('');

    try {
      await sendLiveMessage(stream.id, newMsg);
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const handleEndLiveStream = async () => {
    if (window.confirm('Tem certeza que deseja encerrar esta transmissão ao vivo para todos os espectadores?')) {
      stopCamera();
      try {
        await endLiveStream(stream.id);
      } catch (err) {
        console.error('Error ending live in DB:', err);
      }
      onEndStream?.(stream.id);
      onClose();
    }
  };

  const handleOpenWhatsAppGroup = () => {
    const groupLink = stream.whatsappGroupLink || config.groupWhatsAppLink;
    if (groupLink) {
      window.open(groupLink, '_blank');
    }
  };

  const handleCallWhatsAppDirect = () => {
    const phone = stream.whatsappPhone || config.phoneWhatsApp;
    const text = encodeURIComponent(
      `Olá ${stream.cartomanteName}! Estou assistindo sua Live na Comunidade Cartomante 24h e gostaria de tirar uma dúvida no WhatsApp!`
    );
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  const handleCopyShareLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const totalViewersCount = Math.max(realViewers.length, stream.viewersCount || 1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-lg animate-fadeIn font-sans">
      <div className="bg-[#0b0517] border-2 border-purple-500/50 rounded-3xl w-full max-w-6xl h-[95vh] flex flex-col shadow-2xl shadow-purple-950/80 overflow-hidden relative">
        
        {/* Top Live Bar */}
        <div className="px-4 py-3 bg-gradient-to-r from-purple-950/95 via-[#150a2b] to-purple-950/95 border-b border-purple-500/30 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-red-600/90 text-white font-extrabold text-xs uppercase tracking-wider rounded-full shadow-lg shadow-red-900/50 animate-pulse">
              <Radio className="w-3.5 h-3.5" />
              <span>AO VIVO</span>
            </div>

            <div className="flex items-center gap-2">
              <img
                src={stream.cartomanteAvatar || catLogo}
                alt={stream.cartomanteName}
                className="w-9 h-9 rounded-full border-2 border-purple-400 object-cover shadow"
                referrerPolicy="no-referrer"
              />
              <div>
                <h3 className="font-bold text-white text-sm leading-tight flex items-center gap-1.5">
                  {stream.cartomanteName}
                  <span className="px-1.5 py-0.5 rounded bg-purple-600/50 text-[10px] text-purple-200 border border-purple-400/40">
                    {isBroadcaster ? 'Você (Ao Vivo)' : 'Cartomante Oficial'}
                  </span>
                </h3>
                <p className="text-xs text-purple-300 line-clamp-1">{stream.title}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSideTab('viewers')}
              className="flex items-center gap-1.5 px-3 py-1 bg-purple-900/50 hover:bg-purple-800/70 border border-purple-500/40 rounded-full text-purple-200 text-xs font-bold transition-all cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-emerald-400" />
              <span>{totalViewersCount} Real{totalViewersCount > 1 ? 's' : ''}</span>
            </button>

            <button
              onClick={handleCopyShareLink}
              className="p-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 border border-purple-500/30 text-xs flex items-center gap-1 transition-all cursor-pointer"
              title="Compartilhar Live"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>

            {isBroadcaster && (
              <button
                onClick={handleEndLiveStream}
                className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-lg cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-white" />
                <span>Encerrar Live</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-neutral-900/60 hover:bg-red-950 text-neutral-400 hover:text-red-300 border border-neutral-800 transition-all cursor-pointer"
              aria-label="Fechar Live"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content: Video Broadcast Frame (Left) + Live Chat & Users (Right) */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden bg-[#07030e]">
          
          {/* Video Stream Stage (Left - 8 cols on desktop) */}
          <div className="lg:col-span-8 flex flex-col justify-between relative bg-black overflow-hidden border-b lg:border-b-0 lg:border-r border-purple-500/20">
            
            {/* Real Video Stream from WebCam / Camera Feed */}
            <div className="absolute inset-0 flex items-center justify-center overflow-hidden bg-[#0a0418]">
              {/* Real HTML5 Video element */}
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted={isMuted || isBroadcaster}
                className={`w-full h-full object-cover ${!isVideoOn ? 'hidden' : 'block'}`}
              />

              {/* If camera is disabled or fallback background */}
              {(!isVideoOn || !isCameraActive) && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-[#14082c] via-[#0b0318] to-black">
                  <div className="relative mb-4">
                    <img
                      src={stream.cartomanteAvatar || catLogo}
                      alt={stream.cartomanteName}
                      className="w-28 h-28 rounded-full border-4 border-purple-400 object-cover shadow-2xl animate-pulse"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-purple-950 border border-purple-400 text-amber-300">
                      <Sparkles className="w-5 h-5" />
                    </div>
                  </div>
                  <h3 className="text-xl font-serif font-black text-white mb-1">
                    {stream.cartomanteName}
                  </h3>
                  <p className="text-xs text-purple-300 max-w-md">
                    {isBroadcaster 
                      ? 'Câmera pausada ou desativada. Clique no botão de câmera abaixo para transmitir ao vivo.' 
                      : 'Transmissão mística ao vivo. Conecte-se com a energia do Tarot e Baralho Cigano.'}
                  </p>
                </div>
              )}

              {/* Camera Error Notice Banner */}
              {cameraError && isBroadcaster && (
                <div className="absolute top-4 inset-x-4 p-3.5 rounded-2xl bg-amber-950/90 border border-amber-500 text-amber-200 text-xs flex items-start gap-2.5 shadow-xl backdrop-blur-md z-30">
                  <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-amber-300">Aviso de Câmera</div>
                    <p className="text-[11px] leading-relaxed">{cameraError}</p>
                  </div>
                  <button
                    onClick={startCamera}
                    className="px-2.5 py-1 bg-amber-500 text-black font-bold text-[11px] rounded-lg hover:bg-amber-400 transition-colors"
                  >
                    Tentar Novamente
                  </button>
                </div>
              )}

              {/* Overlay Gradient for readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

              {/* Top Left Live Badge on Video */}
              <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Mesa Mística 24H</span>
                </span>
                {isCameraActive && (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-[11px] font-bold flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    Câmera Ativa
                  </span>
                )}
              </div>

              {/* Active Question Being Answered Overlay on Video */}
              {currentActiveQuestion && (
                <div className="absolute top-16 inset-x-4 z-20 max-w-lg mx-auto">
                  <div className="p-3.5 rounded-2xl bg-[#120626]/95 border-2 border-amber-400/60 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in duration-300">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="relative flex h-2.5 w-2.5">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                        </span>
                        <span className="text-[11px] font-black uppercase text-amber-300 tracking-wider">
                          Mesa Ao Vivo • Respondendo Agora
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-purple-900/80 border border-purple-400/40 text-[10px] text-purple-200 font-medium">
                        {currentActiveQuestion.authorName}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm font-semibold text-white mb-2.5 italic">
                      "{currentActiveQuestion.question}"
                    </p>

                    {/* Drawn Cards on Video */}
                    {drawnCardsForQuestion.length > 0 && (
                      <div className="pt-2 border-t border-purple-500/30">
                        <div className="text-[10px] uppercase font-bold text-purple-300 mb-1.5 flex items-center gap-1">
                          <Layers className="w-3 h-3 text-amber-400" />
                          <span>Cartas Tiradas para esta Consulta:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {drawnCardsForQuestion.map((card, idx) => (
                            <span
                              key={idx}
                              className="px-2.5 py-1 rounded-lg bg-amber-400/20 border border-amber-400/50 text-amber-200 text-xs font-bold shadow-sm"
                            >
                              🃏 {card}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {isBroadcaster && (
                      <div className="mt-2.5 pt-2 border-t border-purple-500/30 flex justify-end">
                        <button
                          onClick={() => handleFinishQuestion(currentActiveQuestion.id)}
                          className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Concluir Resposta</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Floating Arcane Card on Video bottom */}
              <div className="absolute bottom-16 inset-x-4 z-20 max-w-md mx-auto">
                <div className="p-3.5 rounded-2xl bg-[#120724]/90 border border-purple-400/40 backdrop-blur-md shadow-2xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-950 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider block">
                      Carta Revelada na Mesa
                    </span>
                    <p className="text-xs sm:text-sm font-bold text-white truncate">
                      {revealedCard}
                    </p>
                  </div>
                  <button
                    onClick={() => setHeartsCount((c) => c + 1)}
                    className="p-2.5 rounded-xl bg-pink-600/30 hover:bg-pink-600/50 border border-pink-500/40 text-pink-300 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Heart className="w-4 h-4 fill-pink-400 text-pink-400 animate-pulse" />
                    <span>{heartsCount}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Broadcaster / Viewer Controls Bar (Bottom Left) */}
            <div className="relative z-20 p-3 bg-[#0c051a]/95 backdrop-blur-md border-t border-purple-500/30 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-2 rounded-xl bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-purple-200 text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Áudio da Live"
                >
                  {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-purple-300" />}
                  <span className="hidden sm:inline">{isMuted ? 'Mudo' : 'Áudio Ativo'}</span>
                </button>

                {/* Ambient Rádio Macumba toggle */}
                <button
                  onClick={handleToggleRadioInLive}
                  className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    isRadioPlaying 
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow' 
                      : 'bg-purple-950/60 hover:bg-purple-900 border-purple-500/30 text-purple-200'
                  }`}
                  title="Música de fundo sagrada com toques e atabaques"
                >
                  <Music className={`w-4 h-4 ${isRadioPlaying ? 'text-amber-400 animate-bounce' : 'text-purple-300'}`} />
                  <span className="hidden sm:inline">
                    {isRadioPlaying ? 'Rádio Macumba Ligada' : 'Rádio Macumba'}
                  </span>
                </button>

                {isBroadcaster && (
                  <>
                    <button
                      onClick={toggleMicTrack}
                      className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                        isMicOn ? 'bg-purple-900/60 border-purple-400 text-white' : 'bg-red-950 border-red-500 text-red-300'
                      }`}
                      title={isMicOn ? 'Desativar Microfone' : 'Ativar Microfone'}
                    >
                      {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                      <span className="hidden sm:inline">{isMicOn ? 'Mic Ligado' : 'Mic Mudo'}</span>
                    </button>

                    <button
                      onClick={toggleVideoTrack}
                      className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                        isVideoOn ? 'bg-purple-900/60 border-purple-400 text-white' : 'bg-red-950 border-red-500 text-red-300'
                      }`}
                      title={isVideoOn ? 'Desativar Câmera' : 'Ativar Câmera'}
                    >
                      <Camera className="w-4 h-4" />
                      <span className="hidden sm:inline">{isVideoOn ? 'Câmera Ligada' : 'Câmera Desligada'}</span>
                    </button>

                    <button
                      onClick={handleFlipCamera}
                      className="p-2 rounded-xl bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-purple-200 text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Alternar Câmera Frontal / Traseira"
                    >
                      <SwitchCamera className="w-4 h-4" />
                      <span className="hidden sm:inline">Inverter</span>
                    </button>
                  </>
                )}
              </div>

              {/* Broadcaster Action or Viewer Action */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAskModalOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>Pedir Pergunta na Mesa</span>
                </button>

                {isBroadcaster ? (
                  <button
                    onClick={handleEndLiveStream}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <Square className="w-3.5 h-3.5 fill-white" />
                    <span>Encerrar</span>
                  </button>
                ) : (
                  <button
                    onClick={handleOpenWhatsAppGroup}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950 cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp Dela</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Chat, Perguntas na Mesa & Real Viewers (4 cols on desktop) */}
          <div className="lg:col-span-4 flex flex-col h-full bg-[#0e071e] border-t lg:border-t-0 border-purple-500/30 overflow-hidden">
            
            {/* Tabs Header: Chat vs Perguntas vs Real Users */}
            <div className="p-2 bg-[#140b2b] border-b border-purple-500/30 flex items-center gap-1.5">
              <button
                onClick={() => setActiveSideTab('chat')}
                className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeSideTab === 'chat'
                    ? 'bg-purple-600 text-white shadow'
                    : 'text-purple-300 hover:bg-purple-950/60'
                }`}
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Chat ({messages.length})</span>
              </button>

              <button
                onClick={() => setActiveSideTab('questions')}
                className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeSideTab === 'questions'
                    ? 'bg-amber-500 text-neutral-950 font-black shadow'
                    : 'text-amber-300 hover:bg-purple-950/60'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Perguntas ({questions.filter(q => q.status !== 'respondida').length})</span>
              </button>

              <button
                onClick={() => setActiveSideTab('viewers')}
                className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                  activeSideTab === 'viewers'
                    ? 'bg-purple-600 text-white shadow'
                    : 'text-purple-300 hover:bg-purple-950/60'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ao Vivo ({realViewers.length})</span>
              </button>
            </div>

            {/* TAB CONTENT: CHAT */}
            {activeSideTab === 'chat' && (
              <>
                {/* Banner to encourage asking questions */}
                <div className="p-2.5 bg-gradient-to-r from-purple-900/60 to-amber-950/40 border-b border-purple-500/20 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                    <span className="text-[11px] text-purple-200">
                      Quer sua pergunta tirada no Tarot agora?
                    </span>
                  </div>
                  <button
                    onClick={() => setIsAskModalOpen(true)}
                    className="px-2 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-black text-[10px] uppercase transition-all cursor-pointer shrink-0"
                  >
                    Pedir Pergunta
                  </button>
                </div>

                {/* Chat Messages List */}
                <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
                  <div className="p-2.5 rounded-xl bg-purple-950/70 border border-purple-500/30 text-[11px] text-purple-200 text-center">
                    ✨ Bem-vindo(a) à Live Oficial da Cartomante 24h! Comente abaixo ou envie sua pergunta para a mesa.
                  </div>

                  {messages.map((msg) => {
                    const isMsgBroadcaster = msg.senderRole === 'cartomante' || msg.senderRole === 'admin';
                    return (
                      <div
                        key={msg.id}
                        className={`flex items-start gap-2 p-2.5 rounded-xl transition-all ${
                          isMsgBroadcaster
                            ? 'bg-purple-900/50 border border-purple-400/50 text-white shadow'
                            : msg.isHighlight
                            ? 'bg-amber-950/40 border border-amber-500/40 text-amber-100'
                            : 'bg-[#150a28]/70 border border-purple-500/20 text-purple-100'
                        }`}
                      >
                        <img
                          src={msg.senderAvatar || catLogo}
                          alt={msg.senderName}
                          className="w-7 h-7 rounded-full object-cover border border-purple-400/40 shrink-0 mt-0.5"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`font-bold text-[11px] ${isMsgBroadcaster ? 'text-amber-300' : 'text-purple-200'}`}>
                              {msg.senderName}
                            </span>
                            {isMsgBroadcaster && (
                              <span className="px-1.5 py-0.2 bg-purple-600 text-white text-[9px] rounded font-bold">
                                Cartomante
                              </span>
                            )}
                            <span className="text-[9px] text-purple-400 ml-auto">
                              {msg.timestamp}
                            </span>
                          </div>
                          <p className="text-xs text-neutral-200 mt-0.5 leading-relaxed break-words">
                            {msg.message}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={chatEndRef} />
                </div>

                {/* Chat Input Form */}
                <form onSubmit={handleSendMessage} className="p-3 bg-[#120826] border-t border-purple-500/30">
                  {currentUser ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        placeholder="Escreva sua mensagem ou oração..."
                        className="flex-1 px-3 py-2 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/60 focus:outline-none focus:border-purple-400"
                      />
                      <button
                        type="submit"
                        disabled={!inputMessage.trim()}
                        className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white transition-all cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="text-center p-2 bg-purple-950/60 border border-purple-500/30 rounded-xl">
                      <p className="text-[11px] text-purple-300 mb-1.5">
                        Identifique-se para comentar com seu perfil real na live:
                      </p>
                      <button
                        type="button"
                        onClick={onOpenAuth}
                        className="px-4 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs transition-colors cursor-pointer"
                      >
                        Entrar / Criar Cadastro Real
                      </button>
                    </div>
                  )}
                </form>
              </>
            )}

            {/* TAB CONTENT: QUESTIONS QUEUE */}
            {activeSideTab === 'questions' && (
              <div className="flex-1 overflow-y-auto p-3 space-y-3 text-xs">
                <div className="p-3 rounded-2xl bg-gradient-to-br from-[#1b0d36] to-[#261047] border border-amber-400/40 shadow">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-amber-400" />
                      <span className="font-bold text-white text-xs">Fila de Perguntas da Live</span>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold text-[10px]">
                      {questions.length} na mesa
                    </span>
                  </div>
                  <p className="text-[11px] text-purple-200 mb-2.5">
                    Envie sua pergunta direta. A cartomante abre o Baralho Cigano e Tarot ao vivo durante a transmissão!
                  </p>
                  <button
                    onClick={() => setIsAskModalOpen(true)}
                    className="w-full py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 transition-all shadow cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Pedir Minha Pergunta ao Vivo</span>
                  </button>
                </div>

                {/* Questions List */}
                <div className="space-y-2.5">
                  {questions.length === 0 ? (
                    <div className="text-center py-8 text-purple-400/60 text-xs">
                      Nenhuma pergunta na mesa ainda. Seja a primeira pessoa a perguntar!
                    </div>
                  ) : (
                    questions.map((q) => {
                      const isAnswering = q.status === 'respondendo';
                      const isFinished = q.status === 'respondida';
                      return (
                        <div
                          key={q.id}
                          className={`p-3 rounded-2xl border transition-all ${
                            isAnswering
                              ? 'bg-amber-950/40 border-amber-400 shadow-md ring-1 ring-amber-400'
                              : isFinished
                              ? 'bg-[#100720]/60 border-purple-500/20 opacity-75'
                              : 'bg-[#15092a] border-purple-500/30'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <div className="flex items-center gap-2 min-w-0">
                              <img
                                src={q.authorAvatar || catLogo}
                                alt={q.authorName}
                                className="w-6 h-6 rounded-full object-cover border border-purple-400/40 shrink-0"
                                referrerPolicy="no-referrer"
                              />
                              <span className="font-bold text-white text-xs truncate">
                                {q.authorName}
                              </span>
                              <span className="px-1.5 py-0.2 rounded bg-purple-900/60 text-[9px] text-purple-300 uppercase font-bold">
                                {q.category}
                              </span>
                            </div>
                            
                            {/* Status badge */}
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isAnswering
                                  ? 'bg-red-500/20 text-red-300 border border-red-500/50 animate-pulse'
                                  : isFinished
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              }`}
                            >
                              {isAnswering ? 'Respondendo' : isFinished ? 'Respondida' : 'Na Fila'}
                            </span>
                          </div>

                          <p className="text-xs text-neutral-100 font-medium mb-2 leading-relaxed">
                            "{q.question}"
                          </p>

                          {/* Revealed cards if any */}
                          {q.revealedCards && q.revealedCards.length > 0 && (
                            <div className="mb-2 p-2 rounded-xl bg-purple-950/60 border border-purple-500/30">
                              <span className="text-[10px] text-amber-300 font-bold block mb-1">
                                🃏 Cartas Reveladas:
                              </span>
                              <div className="flex flex-wrap gap-1 text-[11px] text-purple-200">
                                {q.revealedCards.map((c, i) => (
                                  <span key={i} className="px-2 py-0.5 rounded bg-purple-900/80 border border-purple-400/30">
                                    {c}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex items-center justify-between pt-1 border-t border-purple-500/20">
                            <button
                              onClick={() => handleUpvoteQuestion(q.id, q.upvotes)}
                              className="px-2 py-1 rounded-lg bg-purple-950/60 hover:bg-purple-900 text-purple-300 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <ThumbsUp className="w-3 h-3 text-amber-400" />
                              <span>{q.upvotes || 0}</span>
                            </button>

                            {/* Cartomante actions */}
                            {isBroadcaster && !isFinished && (
                              <div className="flex items-center gap-1.5">
                                {!isAnswering && (
                                  <button
                                    onClick={() => handleAnswerQuestion(q)}
                                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-black text-[11px] flex items-center gap-1 transition-all cursor-pointer"
                                  >
                                    <Sparkles className="w-3 h-3" />
                                    <span>Tirar Cartas</span>
                                  </button>
                                )}
                                {isAnswering && (
                                  <button
                                    onClick={() => handleFinishQuestion(q.id)}
                                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
                                  >
                                    <Check className="w-3 h-3" />
                                    <span>Concluir</span>
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* TAB CONTENT: REAL USERS & PARTICIPANTS */}
            {activeSideTab === 'viewers' && (
              <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
                <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    Usuários reais autenticados conectados nesta sala de live:
                  </span>
                </div>

                {realViewers.length === 0 ? (
                  <div className="text-center py-8 text-neutral-400 text-xs">
                    Nenhum outro usuário conectado no momento.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {realViewers.map((viewer) => (
                      <div
                        key={viewer.userId}
                        className="p-2.5 rounded-xl bg-[#130926] border border-purple-500/20 flex items-center justify-between gap-2"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={viewer.userAvatar || catLogo}
                            alt={viewer.userName}
                            className="w-8 h-8 rounded-full object-cover border border-purple-400/40 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="font-bold text-white text-xs truncate flex items-center gap-1.5">
                              {viewer.userName}
                              {viewer.userRole === 'admin' && (
                                <Crown className="w-3 h-3 text-amber-400 shrink-0" />
                              )}
                            </div>
                            <span className="text-[10px] text-purple-300 capitalize block">
                              {viewer.userRole === 'admin' ? 'Administrador' : viewer.userRole === 'cartomante' ? 'Cartomante' : 'Consulente'}
                            </span>
                          </div>
                        </div>

                        <span className="px-2 py-0.5 rounded-md bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold">
                          Online
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>

        </div>

      </div>

      {/* ASK A QUESTION MODAL OVERLAY */}
      {isAskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-[#130728] border-2 border-purple-500/40 p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAskModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-purple-950/60 hover:bg-purple-900 text-purple-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-400 flex items-center justify-center text-amber-300">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-serif font-bold text-white">
                  Pedir Pergunta na Mesa ao Vivo
                </h3>
                <p className="text-xs text-purple-300">
                  A cartomante tira as cartas ao vivo para você na transmissão!
                </p>
              </div>
            </div>

            {questionSentSuccess ? (
              <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500 mx-auto flex items-center justify-center text-emerald-300">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-white">Pergunta Enviada com Sucesso!</h4>
                <p className="text-xs text-emerald-200">
                  Sua pergunta entrou na fila da mesa ao vivo. Fique atento(a) à transmissão!
                </p>
              </div>
            ) : (
              <form onSubmit={handleAskQuestionSubmit} className="space-y-4">
                {/* Category Selection */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1.5">
                    Categoria da Dúvida:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'amor', label: 'Amor' },
                      { id: 'financeiro', label: 'Dinheiro' },
                      { id: 'espiritual', label: 'Espiritual' },
                      { id: 'saude', label: 'Saúde' },
                      { id: 'geral', label: 'Geral' }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setQuestionCategory(cat.id as any)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          questionCategory === cat.id
                            ? 'bg-purple-600 text-white border border-purple-400 shadow'
                            : 'bg-purple-950/50 text-purple-300 border border-purple-500/30 hover:bg-purple-900/60'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Question Type / Package */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1.5">
                    Modalidade na Live:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setQuestionType('1_pergunta')}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        questionType === '1_pergunta'
                          ? 'bg-amber-500/20 border-amber-400 text-white shadow'
                          : 'bg-purple-950/40 border-purple-500/30 text-purple-300 hover:bg-purple-900/40'
                      }`}
                    >
                      <div className="font-bold text-xs">1 Pergunta Objetiva</div>
                      <div className="text-[11px] text-amber-300 font-extrabold mt-0.5">
                        R$ {config.price1Question || 20},00
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setQuestionType('3_perguntas')}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        questionType === '3_perguntas'
                          ? 'bg-amber-500/20 border-amber-400 text-white shadow'
                          : 'bg-purple-950/40 border-purple-500/30 text-purple-300 hover:bg-purple-900/40'
                      }`}
                    >
                      <div className="font-bold text-xs">3 Perguntas Abertas</div>
                      <div className="text-[11px] text-amber-300 font-extrabold mt-0.5">
                        R$ {config.price3Questions || 50},00
                      </div>
                    </button>
                  </div>
                </div>

                {/* Question text */}
                <div>
                  <label className="block text-xs font-bold text-purple-200 mb-1.5">
                    Sua Pergunta para o Baralho Cigano / Tarot:
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={questionText}
                    onChange={(e) => setQuestionText(e.target.value)}
                    placeholder="Ex: Vou ter novidades no amor esta semana? Ou devo mudar de emprego agora?"
                    className="w-full px-3.5 py-2.5 bg-black/60 border border-purple-500/40 rounded-2xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-amber-400 resize-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={!questionText.trim()}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-neutral-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg disabled:opacity-40 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Enviar Pergunta para a Live</span>
                  </button>
                  <p className="text-[10px] text-purple-400/70 text-center mt-2">
                    Sua pergunta será exibida na tela da transmissão para a cartomante abrir as cartas.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

