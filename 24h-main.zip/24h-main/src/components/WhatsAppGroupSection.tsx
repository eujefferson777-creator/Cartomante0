import { MessageCircle, Users, Sparkles, Bell, Gift, ShieldCheck, ArrowRight, Heart, Edit3, Star, Check } from 'lucide-react';
import { SiteConfig, UserAccount, CartomanteProfile } from '../types';
import { WHATSAPP_GROUP_BENEFITS } from '../data/pricingPlans';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import catLogo from '../assets/images/mystical_cat_logo_1787014257234.jpg';

interface WhatsAppGroupSectionProps {
  config: SiteConfig;
  currentUser?: UserAccount | null;
  cartomantes?: CartomanteProfile[];
  onJoinGroup: (cartomante?: CartomanteProfile) => void;
  onSelectCartomanteToPlay?: (cartomante: CartomanteProfile) => void;
  onTalkPrivate: () => void;
  onOpenLinkManager?: (targetLinkId?: string) => void;
}

export function WhatsAppGroupSection({
  config,
  currentUser,
  cartomantes = CARTOMANTES_PROFILES,
  onJoinGroup,
  onSelectCartomanteToPlay,
  onTalkPrivate,
  onOpenLinkManager
}: WhatsAppGroupSectionProps) {
  const activeCartomantes = cartomantes && cartomantes.length > 0 ? cartomantes : CARTOMANTES_PROFILES;

  return (
    <section id="grupo-whatsapp" className="py-16 md:py-24 bg-[#0a0518] relative overflow-hidden border-t border-purple-500/20">
      {/* Decorative Orbs */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-purple-900/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute left-0 bottom-0 w-80 h-80 bg-emerald-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Information & Perks */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-3">
              <Users className="w-3.5 h-3.5" />
              Atendimento Centralizado no WhatsApp
            </div>

            <h2 className="text-3xl sm:text-4xl font-serif font-black text-white leading-tight">
              Entre no Grupo de WhatsApp e{' '}
              <span className="bg-gradient-to-r from-purple-300 via-white to-emerald-300 bg-clip-text text-transparent">
                Escolha Sua Cartomante para Jogar
              </span>
            </h2>

            <p className="mt-4 text-sm sm:text-base text-purple-100/90 leading-relaxed">
              O acesso oficial e as tiragens são feitas <strong className="text-emerald-300">exclusivamente dentro do nosso Grupo VIP no WhatsApp</strong>. Escolha abaixo com qual cartomante você quer jogar agora mesmo e receba suas revelações ao vivo na mesa!
            </p>

            {/* NEW: Choose Cartomante to Play Inside the Group */}
            <div className="mt-6 p-4.5 rounded-3xl bg-[#120726]/90 border border-amber-500/40 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" /> Escolha sua Cartomante para Jogar no Grupo:
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold">🟢 Plantão Ativo 24h</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {activeCartomantes.slice(0, 3).map((c) => (
                  <div
                    key={c.id}
                    className="p-3 rounded-2xl bg-[#090314] border border-purple-500/30 hover:border-amber-400 transition-all flex flex-col justify-between group"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={c.avatar}
                        alt={c.name}
                        className="w-10 h-10 rounded-xl object-cover border border-amber-400/40 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <h4 className="font-bold text-white text-xs truncate">{c.name}</h4>
                        <p className="text-[10px] text-purple-300/80 truncate">{c.deckTypes[0] || 'Baralho Cigano'}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (onSelectCartomanteToPlay) {
                          onSelectCartomanteToPlay(c);
                        } else {
                          onJoinGroup(c);
                        }
                      }}
                      className="mt-2.5 w-full py-1.5 px-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-[11px] rounded-xl flex items-center justify-center gap-1 shadow cursor-pointer transition-all"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Jogar com Ela no Grupo</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Benefits List */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {WHATSAPP_GROUP_BENEFITS.map((b, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-[#120722] border border-purple-500/30 hover:border-emerald-500/40 transition-all shadow-md shadow-purple-950/40">
                  <div className="flex items-center gap-2.5 text-emerald-400 font-bold text-xs mb-1">
                    {idx === 0 && <Sparkles className="w-4 h-4 text-purple-300" />}
                    {idx === 1 && <Gift className="w-4 h-4 text-emerald-400" />}
                    {idx === 2 && <Heart className="w-4 h-4 text-rose-400" />}
                    {idx === 3 && <Bell className="w-4 h-4 text-purple-400" />}
                    <span className="text-white">{b.title}</span>
                  </div>
                  <p className="text-xs text-purple-200/80 leading-relaxed">{b.description}</p>
                </div>
              ))}
            </div>

            {/* Group Action CTA Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-center gap-3.5 relative">
              <div className="relative w-full sm:w-auto">
                <button
                  id="join-group-whatsapp-btn"
                  onClick={() => onJoinGroup()}
                  className="w-full sm:w-auto px-7 py-3.5 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm sm:text-base rounded-2xl flex items-center justify-center gap-2.5 shadow-xl shadow-emerald-950/60 transition-all hover:scale-[1.02] cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                  <span>Entrar no Grupo VIP & Escolher Cartomante</span>
                  <ArrowRight className="w-4 h-4 opacity-80" />
                </button>
                {currentUser?.role === 'admin' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenLinkManager?.('whatsapp');
                    }}
                    className="absolute -top-3 -right-2 bg-purple-600 hover:bg-purple-500 text-white p-1.5 rounded-full border border-white/40 shadow-lg text-[10px] flex items-center gap-1 cursor-pointer z-10"
                    title="Atualizar link do grupo VIP (Admin)"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="relative w-full sm:w-auto">
                <button
                  id="talk-private-whatsapp-btn"
                  onClick={onTalkPrivate}
                  className="w-full sm:w-auto px-5 py-3.5 bg-[#180d30] hover:bg-[#231346] border border-purple-500/40 text-purple-200 hover:text-white text-xs sm:text-sm font-bold rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-purple-950/40"
                >
                  <span>Falar no Privado com o Plantão</span>
                </button>
                {currentUser?.role === 'admin' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenLinkManager?.('whatsapp');
                    }}
                    className="absolute -top-3 -right-2 bg-purple-600 hover:bg-purple-500 text-white p-1.5 rounded-full border border-white/40 shadow-lg text-[10px] flex items-center gap-1 cursor-pointer z-10"
                    title="Atualizar WhatsApp Direto (Admin)"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Realistic WhatsApp Phone Mockup Preview */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="w-full max-w-sm bg-[#0e061c] border-4 border-purple-500/40 rounded-[36px] overflow-hidden shadow-2xl p-2.5 shadow-purple-950/80">
              <div className="bg-[#0b141a] rounded-[28px] overflow-hidden flex flex-col text-neutral-200 text-xs">
                {/* Simulated WhatsApp Header */}
                <div className="bg-[#202c33] px-3.5 py-3 flex items-center justify-between border-b border-[#2a3942]">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full overflow-hidden border border-purple-400 shrink-0">
                      <img
                        src={catLogo}
                        alt="Cartomante 24h VIP"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-xs">Cartomante 24h VIP • Grupo</h4>
                      <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                        1.480 membros • Jogos ao Vivo
                      </p>
                    </div>
                  </div>
                  <Users className="w-4 h-4 text-neutral-400" />
                </div>

                {/* Simulated Chat Feed Messages */}
                <div className="p-3.5 space-y-3 bg-[radial-gradient(#1f2c34_1px,transparent_1px)] [background-size:16px_16px] min-h-[300px]">
                  {/* System message */}
                  <div className="text-center">
                    <span className="bg-[#182229] text-[10px] text-purple-200 px-2.5 py-1 rounded-full border border-purple-500/30">
                      Previsão do Dia • Baralho Cigano & Tarot
                    </span>
                  </div>

                  {/* Cartomante Post in Group */}
                  <div className="bg-[#005c4b] p-3 rounded-2xl rounded-tl-none shadow text-xs space-y-1.5 text-white max-w-[90%]">
                    <div className="flex items-center justify-between text-[10px] text-purple-200 font-bold">
                      <span>Mãe Yara (Plantão no Grupo)</span>
                      <span>07:30</span>
                    </div>
                    <p className="text-[11px] leading-relaxed">
                      ✨ <strong>CARTA DO DIA: 31 - O SOL</strong> ☀️
                      <br />
                      Irmãos de Luz! Aquele assunto que parecia travado receberá uma resposta iluminada hoje!
                    </p>
                    <p className="text-[10px] text-emerald-200 italic pt-1 border-t border-emerald-700">
                      🔮 Quem escolheu jogar comigo aqui no grupo hoje: envie seu comprovante e sua pergunta que estou abrindo a mesa agora!
                    </p>
                  </div>

                  {/* Client Reply in Group */}
                  <div className="bg-[#202c33] p-2.5 rounded-2xl rounded-tr-none shadow text-[11px] text-neutral-200 max-w-[85%] ml-auto">
                    <div className="flex items-center justify-between text-[10px] text-emerald-400 font-semibold mb-0.5">
                      <span>Juliana P. (Membro VIP)</span>
                      <span>08:14</span>
                    </div>
                    <p>Acabei de jogar 3 perguntas com a Mãe Yara aqui no grupo e foi impressionante! Respondeu na hora com fotos das cartas! Gratidão 🙏❤️</p>
                  </div>

                  {/* Group notification alert */}
                  <div className="bg-purple-950/60 border border-purple-500/40 p-2.5 rounded-xl text-[11px] text-purple-200 text-center">
                    🎁 Escolha sua cartomante para jogar dentro do grupo e receba resposta com foto das cartas!
                  </div>
                </div>

                {/* Bottom Bar in Phone Mockup */}
                <div className="p-3 bg-[#202c33] flex items-center justify-between gap-2">
                  <span className="text-[11px] text-neutral-400">Entre para jogar no grupo...</span>
                  <button
                    onClick={() => onJoinGroup()}
                    className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-[11px] rounded-lg transition-all cursor-pointer"
                  >
                    Escolher Cartomante
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

