import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  MessageCircle, 
  Heart, 
  Send, 
  Image as ImageIcon, 
  Star, 
  UserPlus, 
  UserCheck, 
  Radio, 
  Video, 
  Users, 
  Clock, 
  Check, 
  Search, 
  Filter, 
  Share2, 
  Bookmark, 
  Plus, 
  Edit3, 
  X, 
  ShieldCheck, 
  Phone, 
  ExternalLink,
  ChevronRight,
  Eye,
  Camera,
  Layers,
  ArrowLeft
} from 'lucide-react';
import { 
  CommunityPost, 
  PostComment, 
  LiveStreamSession, 
  UserAccount, 
  SiteConfig, 
  CartomanteProfile 
} from '../types';
import { INITIAL_COMMUNITY_POSTS, INITIAL_LIVE_STREAMS } from '../data/communityData';
import { CARTOMANTES_PROFILES } from '../data/cartomantes';
import { AvatarPicker } from './AvatarPicker';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';
import {
  subscribeToCommunityPosts,
  createCommunityPost,
  toggleLikePost,
  addCommentToPost,
  subscribeToLiveStreams,
  saveLiveStream,
  saveUserProfile
} from '../lib/firebase';

interface CommunityPageProps {
  config: SiteConfig;
  currentUser: UserAccount | null;
  onOpenAuth: () => void;
  onOpenLiveStream: (stream: LiveStreamSession) => void;
  onStartLiveStreamModal?: () => void;
  onBackToHome: () => void;
  onUpdateCurrentUser: (updatedUser: UserAccount) => void;
}

export function CommunityPage({
  config,
  currentUser,
  onOpenAuth,
  onOpenLiveStream,
  onStartLiveStreamModal,
  onBackToHome,
  onUpdateCurrentUser
}: CommunityPageProps) {
  // Navigation tabs within Community
  const [activeTab, setActiveTab] = useState<'feed' | 'lives' | 'members' | 'favorites'>('feed');
  const [selectedTopicFilter, setSelectedTopicFilter] = useState<string>('todos');

  // Posts state from localStorage or initial
  const [posts, setPosts] = useState<CommunityPost[]>(() => {
    const saved = localStorage.getItem('cartomante24h_community_posts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_COMMUNITY_POSTS;
  });

  // Live Streams state
  const [liveStreams, setLiveStreams] = useState<LiveStreamSession[]>(() => {
    const saved = localStorage.getItem('cartomante24h_live_streams');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_LIVE_STREAMS;
  });

  // Favorites list (IDs of cartomantes or friends)
  const [favorites, setFavorites] = useState<string[]>(() => {
    if (currentUser?.favoriteUserIds) return currentUser.favoriteUserIds;
    const saved = localStorage.getItem(`cartomante24h_favorites_${currentUser?.id || 'guest'}`);
    return saved ? JSON.parse(saved) : ['cartomante-1', 'cartomante-2'];
  });

  // New Post Form State
  const [postContent, setPostContent] = useState('');
  const [postImageUrl, setPostImageUrl] = useState('');
  const [postTopic, setPostTopic] = useState<'relato' | 'duvida' | 'previsao' | 'amor' | 'prosperidade' | 'oraculo' | 'geral'>('geral');
  const [selectedTarotCard, setSelectedTarotCard] = useState<string>('');
  const [isAddingImage, setIsAddingImage] = useState(false);
  const [taggedPersonId, setTaggedPersonId] = useState<string>('');

  // Comment input per post
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});

  // Profile View / Edit Modal State
  const [viewingProfile, setViewingProfile] = useState<any | null>(null);
  const [isEditingMyProfile, setIsEditingMyProfile] = useState(false);
  const [myBio, setMyBio] = useState(currentUser?.bio || 'Buscando sabedoria nas cartas sagradas e paz interior ✨');
  const [mySign, setMySign] = useState(currentUser?.astrologicalSign || 'Gêmeos ♊');

  // Start Live Form State for Cartomantes/Admin
  const [isCreateLiveOpen, setIsCreateLiveOpen] = useState(false);
  const [newLiveTitle, setNewLiveTitle] = useState('');
  const [newLiveTopic, setNewLiveTopic] = useState('Tiragem de Amor & Abertura de Caminhos');
  const [newLiveFeaturedCard, setNewLiveFeaturedCard] = useState('Os Enamorados + A Aliança Cigana');

  // Live Firestore subscription for Community Posts
  useEffect(() => {
    const unsubscribe = subscribeToCommunityPosts((remotePosts) => {
      if (remotePosts && remotePosts.length > 0) {
        setPosts(remotePosts);
      }
    });
    return () => unsubscribe();
  }, []);

  // Live Firestore subscription for Live Streams
  useEffect(() => {
    const unsubscribe = subscribeToLiveStreams((remoteStreams) => {
      if (remoteStreams && remoteStreams.length > 0) {
        setLiveStreams(remoteStreams);
      }
    });
    return () => unsubscribe();
  }, []);

  // Sync posts locally and to Firestore
  const savePosts = (newPosts: CommunityPost[]) => {
    setPosts(newPosts);
    localStorage.setItem('cartomante24h_community_posts', JSON.stringify(newPosts));
  };

  // Toggle Favorite Friend or Cartomante
  const handleToggleFavorite = async (targetId: string) => {
    let updated: string[];
    if (favorites.includes(targetId)) {
      updated = favorites.filter((id) => id !== targetId);
    } else {
      updated = [...favorites, targetId];
    }
    setFavorites(updated);
    localStorage.setItem(`cartomante24h_favorites_${currentUser?.id || 'guest'}`, JSON.stringify(updated));

    if (currentUser) {
      const updatedUser = { ...currentUser, favoriteUserIds: updated };
      onUpdateCurrentUser(updatedUser);
      try {
        await saveUserProfile(updatedUser);
      } catch (err) {
        console.error('Failed to sync favorite to DB:', err);
      }
    }
  };

  // Handle Post Creation with Firestore
  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!postContent.trim()) return;

    let tarotAttachment = undefined;
    if (selectedTarotCard) {
      tarotAttachment = {
        name: selectedTarotCard,
        icon: '🔮',
        summary: 'Revelação oracular selecionada pelo autor para esta postagem.'
      };
    }

    let taggedUsersList = undefined;
    if (taggedPersonId) {
      const matched = CARTOMANTES_PROFILES.find((c) => c.id === taggedPersonId);
      if (matched) {
        taggedUsersList = [{ id: matched.id, name: matched.name, role: 'cartomante' as const }];
      }
    }

    const newPost: CommunityPost = {
      id: 'post-' + Date.now(),
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      authorRole: currentUser.role,
      authorTitle: currentUser.role === 'cartomante' ? 'Cartomante Plantonista' : currentUser.role === 'admin' ? 'Administrador' : 'Consulente Astral',
      authorBio: currentUser.bio || myBio,
      content: postContent.trim(),
      imageUrl: postImageUrl.trim() || undefined,
      likes: 1,
      likedBy: [currentUser.id],
      comments: [],
      topic: postTopic,
      tarotCardAttachment: tarotAttachment,
      taggedUsers: taggedUsersList,
      createdAt: 'Agora mesmo'
    };

    const updated = [newPost, ...posts];
    savePosts(updated);

    // Save to Firestore Database
    try {
      await createCommunityPost(newPost);
    } catch (err) {
      console.error('Firestore create post error:', err);
    }

    // Reset Form
    setPostContent('');
    setPostImageUrl('');
    setIsAddingImage(false);
    setSelectedTarotCard('');
    setTaggedPersonId('');
  };

  // Handle Post Like Toggle with Firestore
  const handleToggleLike = async (postId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const targetPost = posts.find((p) => p.id === postId);
    if (!targetPost) return;

    const isLiked = targetPost.likedBy.includes(currentUser.id);
    const updatedLikedBy = isLiked
      ? targetPost.likedBy.filter((id) => id !== currentUser.id)
      : [...targetPost.likedBy, currentUser.id];

    const updated = posts.map((post) => {
      if (post.id === postId) {
        return {
          ...post,
          likes: updatedLikedBy.length,
          likedBy: updatedLikedBy
        };
      }
      return post;
    });

    savePosts(updated);

    try {
      await toggleLikePost(postId, currentUser.id, targetPost.likedBy);
    } catch (err) {
      console.error('Firestore toggle like error:', err);
    }
  };

  // Handle Adding Comment with Firestore
  const handleAddComment = async (postId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    const newComment: PostComment = {
      id: 'c-' + Date.now(),
      postId,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      authorRole: currentUser.role,
      content: text,
      createdAt: 'Agora',
      likes: 0
    };

    const targetPost = posts.find((p) => p.id === postId);
    const updated = posts.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [...p.comments, newComment]
        };
      }
      return p;
    });

    savePosts(updated);
    setCommentInputs({ ...commentInputs, [postId]: '' });

    if (targetPost) {
      try {
        await addCommentToPost(postId, newComment);
      } catch (err) {
        console.error('Firestore add comment error:', err);
      }
    }
  };

  // Handle Start Live Stream (Authorized for Cartomantes and Admin only)
  const handleStartLiveStream = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || (currentUser.role !== 'cartomante' && currentUser.role !== 'admin')) {
      alert('Apenas Cartomantes autorizadas e Administradores podem iniciar transmissões ao vivo.');
      return;
    }
    if (!newLiveTitle.trim()) return;

    const newStream: LiveStreamSession = {
      id: 'live-' + Date.now(),
      cartomanteId: currentUser.id,
      cartomanteName: currentUser.name,
      cartomanteTitle: currentUser.role === 'admin' ? 'Mestre Oracular & Admin' : 'Cartomante de Plantão 24h',
      cartomanteAvatar: currentUser.avatar || catLogo,
      title: newLiveTitle.trim(),
      topic: newLiveTopic,
      whatsappGroupLink: config.groupWhatsAppLink,
      whatsappPhone: config.phoneWhatsApp,
      viewersCount: 1,
      isLive: true,
      startedAt: 'Ao vivo agora',
      featuredCard: newLiveFeaturedCard,
      bannerUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80'
    };

    const updatedStreams = [newStream, ...liveStreams];
    setLiveStreams(updatedStreams);
    localStorage.setItem('cartomante24h_live_streams', JSON.stringify(updatedStreams));

    try {
      await saveLiveStream(newStream);
    } catch (err) {
      console.error('Firestore save live stream error:', err);
    }

    setIsCreateLiveOpen(false);
    setNewLiveTitle('');
    onOpenLiveStream(newStream);
  };

  // Handle Save Profile with Firestore
  const handleSaveMyProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const updated: UserAccount = {
      ...currentUser,
      bio: myBio,
      astrologicalSign: mySign
    };
    onUpdateCurrentUser(updated);
    setIsEditingMyProfile(false);
    try {
      await saveUserProfile(updated);
    } catch (err) {
      console.error('Firestore save profile error:', err);
    }
  };

  // Filter posts
  const filteredPosts = posts.filter((post) => {
    if (selectedTopicFilter === 'todos') return true;
    return post.topic === selectedTopicFilter;
  });

  const isAuthorizedToStream = currentUser?.role === 'cartomante' || currentUser?.role === 'admin';

  return (
    <div className="min-h-screen bg-[#06020e] text-white selection:bg-purple-600 selection:text-white pt-6 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Community Navigation Banner */}
        <div className="mb-8 rounded-3xl bg-gradient-to-r from-purple-950/90 via-[#150a2b] to-purple-950/90 border-2 border-purple-500/40 p-6 shadow-2xl shadow-purple-950/80 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex items-center gap-4 z-10">
            <button
              onClick={onBackToHome}
              className="p-3 rounded-2xl bg-purple-900/60 hover:bg-purple-800 border border-purple-400/40 text-purple-200 hover:text-white transition-all cursor-pointer shadow-lg"
              title="Voltar para a Página Principal"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <img
              src={catLogo}
              alt="Logo Gatinho Místico"
              className="w-14 h-14 rounded-2xl border-2 border-purple-400 object-cover shadow-lg shadow-purple-950 animate-pulse"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-serif font-black text-white tracking-wide">
                  Comunidade & Feed Místico
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-purple-600/50 border border-purple-400/40 text-[11px] font-bold text-purple-200">
                  Cartomante 24h
                </span>
              </div>
              <p className="text-xs sm:text-sm text-purple-300 mt-1">
                Espaço de convivência para consulentes e cartomantes: posts, fotos, amizades, favoritos e lives ao vivo!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 z-10 flex-wrap">
            {isAuthorizedToStream ? (
              <button
                onClick={() => setIsCreateLiveOpen(true)}
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-500 hover:to-fuchsia-500 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-red-950/60 transition-all cursor-pointer hover:scale-105"
              >
                <Radio className="w-4 h-4 animate-pulse" />
                <span>Iniciar Live (Cartomante)</span>
              </button>
            ) : (
              <button
                onClick={() => setActiveTab('lives')}
                className="px-4 py-2.5 rounded-2xl bg-purple-900/60 hover:bg-purple-800 border border-purple-400/40 text-purple-200 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <Radio className="w-4 h-4 text-red-400 animate-pulse" />
                <span>Ver Lives Ao Vivo</span>
              </button>
            )}

            {currentUser ? (
              <button
                onClick={() => setIsEditingMyProfile(true)}
                className="px-4 py-2.5 rounded-2xl bg-purple-800/50 hover:bg-purple-700/60 border border-purple-400/40 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <img
                  src={currentUser.avatar || catLogo}
                  alt={currentUser.name}
                  className="w-5 h-5 rounded-full object-cover border border-purple-300"
                />
                <span>Meu Perfil & Bio</span>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-950"
              >
                <Users className="w-4 h-4" />
                <span>Entrar / Criar Perfil</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation Controls */}
        <div className="flex items-center gap-2 sm:gap-3 border-b border-purple-500/30 pb-4 mb-8 overflow-x-auto">
          <button
            onClick={() => setActiveTab('feed')}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'feed'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-950/80 border border-purple-400'
                : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-500/20'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Feed de Publicações</span>
            <span className="px-1.5 py-0.2 rounded-full bg-purple-950 text-[10px] text-purple-200">
              {posts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('lives')}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'lives'
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/80 border border-red-400'
                : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-500/20'
            }`}
          >
            <Radio className="w-4 h-4 text-white animate-pulse" />
            <span>Lives & Transmissões</span>
            <span className="px-1.5 py-0.2 rounded-full bg-red-950 text-[10px] text-red-200 font-extrabold">
              {liveStreams.length} Ao Vivo
            </span>
          </button>

          <button
            onClick={() => setActiveTab('members')}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'members'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-950/80 border border-purple-400'
                : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-500/20'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-400" />
            <span>Membros & Cartomantes</span>
          </button>

          <button
            onClick={() => setActiveTab('favorites')}
            className={`px-5 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'favorites'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-950/80 border border-purple-400'
                : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-500/20'
            }`}
          >
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <span>Meus Favoritos & Amigos</span>
            <span className="px-1.5 py-0.2 rounded-full bg-purple-950 text-[10px] text-amber-300">
              {favorites.length}
            </span>
          </button>
        </div>

        {/* Tab 1: FEED DE PUBLICAÇÕES */}
        {activeTab === 'feed' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Main Feed Column (8 cols) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* Post Creation Box */}
              <div className="bg-[#0f0720] border-2 border-purple-500/40 rounded-3xl p-5 shadow-2xl shadow-purple-950/60">
                <div className="flex items-center gap-3 mb-4">
                  <img
                    src={currentUser?.avatar || catLogo}
                    alt={currentUser?.name || 'Visitante'}
                    className="w-11 h-11 rounded-2xl object-cover border-2 border-purple-400 shadow-md"
                  />
                  <div>
                    <h3 className="font-bold text-white text-sm">
                      {currentUser ? currentUser.name : 'Compartilhe com a Comunidade'}
                    </h3>
                    <p className="text-xs text-purple-300">
                      {currentUser?.role === 'cartomante'
                        ? '🌟 Cartomante Plantonista Oficial'
                        : currentUser?.role === 'admin'
                        ? '🛡️ Administrador do Portal'
                        : 'Consulente e amigo(a) da espiritualidade'}
                    </p>
                  </div>
                </div>

                <form onSubmit={handleCreatePost}>
                  <textarea
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    placeholder="Conte um relato de consulta, tire uma dúvida sobre cartas, compartilhe uma foto mística ou deixe uma mensagem para amigos e cartomantes..."
                    rows={3}
                    className="w-full p-3.5 bg-black/60 border border-purple-500/30 rounded-2xl text-sm text-white placeholder-purple-400/60 focus:outline-none focus:border-purple-400 transition-all resize-none mb-3"
                  />

                  {/* Image Attachment Input Preview */}
                  {isAddingImage && (
                    <div className="mb-3 p-3 bg-purple-950/50 border border-purple-500/30 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-purple-200 flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-purple-300" />
                          URL da Imagem / Foto Mística:
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setIsAddingImage(false);
                            setPostImageUrl('');
                          }}
                          className="text-purple-400 hover:text-white text-xs"
                        >
                          Cancelar
                        </button>
                      </div>
                      <input
                        type="url"
                        value={postImageUrl}
                        onChange={(e) => setPostImageUrl(e.target.value)}
                        placeholder="https://exemplo.com/sua-foto-tarot.jpg"
                        className="w-full px-3 py-2 bg-black/70 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                      />
                      {postImageUrl && (
                        <img
                          src={postImageUrl}
                          alt="Prévia da foto"
                          className="max-h-48 rounded-xl object-cover border border-purple-400/40 mt-2"
                        />
                      )}
                    </div>
                  )}

                  {/* Extra Options Row: Topic, Card Attachment, Tagging */}
                  <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-purple-500/20">
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Topic Selector */}
                      <select
                        value={postTopic}
                        onChange={(e: any) => setPostTopic(e.target.value)}
                        className="px-3 py-1.5 bg-purple-950/80 border border-purple-500/30 rounded-xl text-xs text-purple-200 focus:outline-none focus:border-purple-400 cursor-pointer"
                      >
                        <option value="geral">💬 Geral</option>
                        <option value="relato">🌟 Relato de Consulta</option>
                        <option value="duvida">❓ Dúvida sobre Cartas</option>
                        <option value="previsao">🔮 Previsão Astral</option>
                        <option value="amor">❤️ Amor & Relacionamentos</option>
                        <option value="prosperidade">💰 Prosperidade & Caminhos</option>
                      </select>

                      {/* Add Image Trigger */}
                      <button
                        type="button"
                        onClick={() => setIsAddingImage(!isAddingImage)}
                        className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                          isAddingImage
                            ? 'bg-purple-800 border-purple-400 text-white'
                            : 'bg-purple-950/60 hover:bg-purple-900 border-purple-500/30 text-purple-300'
                        }`}
                        title="Anexar Imagem"
                      >
                        <ImageIcon className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Foto</span>
                      </button>

                      {/* Tag Cartomante */}
                      <select
                        value={taggedPersonId}
                        onChange={(e) => setTaggedPersonId(e.target.value)}
                        className="px-2.5 py-1.5 bg-purple-950/80 border border-purple-500/30 rounded-xl text-xs text-purple-300 focus:outline-none focus:border-purple-400 cursor-pointer"
                      >
                        <option value="">Marcar Cartomante (@)</option>
                        {CARTOMANTES_PROFILES.map((c) => (
                          <option key={c.id} value={c.id}>
                            @{c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={!postContent.trim()}
                      className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-950/60 transition-all cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Publicar</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Topic Filter Pills */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {[
                  { id: 'todos', label: 'Todos os Posts' },
                  { id: 'previsao', label: '🔮 Previsões' },
                  { id: 'relato', label: '🌟 Relatos' },
                  { id: 'amor', label: '❤️ Amor' },
                  { id: 'prosperidade', label: '💰 Prosperidade' },
                  { id: 'duvida', label: '❓ Dúvidas' }
                ].map((pill) => (
                  <button
                    key={pill.id}
                    onClick={() => setSelectedTopicFilter(pill.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      selectedTopicFilter === pill.id
                        ? 'bg-purple-600 text-white border border-purple-300 shadow-md'
                        : 'bg-[#0f0720] hover:bg-purple-950 text-purple-300 border border-purple-500/20'
                    }`}
                  >
                    {pill.label}
                  </button>
                ))}
              </div>

              {/* Posts Feed Stream */}
              <div className="space-y-6">
                {filteredPosts.map((post) => {
                  const isAuthorFavorited = favorites.includes(post.authorId);
                  const isLikedByMe = currentUser ? post.likedBy.includes(currentUser.id) : false;
                  const isCommentsOpen = expandedComments[post.id] || false;

                  return (
                    <article
                      key={post.id}
                      className="bg-[#0c051a] border-2 border-purple-500/30 hover:border-purple-500/50 rounded-3xl p-5 shadow-xl shadow-purple-950/40 transition-all space-y-4"
                    >
                      {/* Post Author Bar */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={post.authorAvatar}
                            alt={post.authorName}
                            className="w-12 h-12 rounded-2xl object-cover border border-purple-400 shadow-md cursor-pointer hover:scale-105 transition-transform"
                            onClick={() => setViewingProfile(post)}
                          />
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4
                                className="font-bold text-white text-sm hover:text-purple-300 cursor-pointer transition-colors"
                                onClick={() => setViewingProfile(post)}
                              >
                                {post.authorName}
                              </h4>
                              {post.authorRole === 'cartomante' && (
                                <span className="px-2 py-0.5 rounded-full bg-purple-600/60 border border-purple-400/50 text-[10px] font-bold text-amber-300">
                                  Cartomante Oficial
                                </span>
                              )}
                              {post.authorRole === 'admin' && (
                                <span className="px-2 py-0.5 rounded-full bg-red-600/60 border border-red-400/50 text-[10px] font-bold text-white">
                                  Admin
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-purple-300">{post.authorTitle || 'Consulente Astral'}</p>
                            <span className="text-[10px] text-purple-400">{post.createdAt}</span>
                          </div>
                        </div>

                        {/* Favorite Author Button */}
                        <button
                          onClick={() => handleToggleFavorite(post.authorId)}
                          className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                            isAuthorFavorited
                              ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                              : 'bg-purple-950/40 hover:bg-purple-900 border-purple-500/30 text-purple-300'
                          }`}
                          title={isAuthorFavorited ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos / Amigos'}
                        >
                          <Star className={`w-3.5 h-3.5 ${isAuthorFavorited ? 'fill-amber-400 text-amber-400' : ''}`} />
                          <span className="text-[11px] hidden sm:inline">
                            {isAuthorFavorited ? 'Favorito' : 'Favoritar'}
                          </span>
                        </button>
                      </div>

                      {/* Tagged Persons */}
                      {post.taggedUsers && post.taggedUsers.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap text-xs text-purple-300">
                          <span className="text-purple-400">Com:</span>
                          {post.taggedUsers.map((tu) => (
                            <span
                              key={tu.id}
                              className="px-2 py-0.5 rounded-lg bg-purple-900/60 border border-purple-400/30 text-[11px] text-purple-200 font-medium"
                            >
                              @{tu.name}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Post Content Body */}
                      <p className="text-sm text-neutral-200 leading-relaxed whitespace-pre-line">
                        {post.content}
                      </p>

                      {/* Optional Tarot Card Attachment */}
                      {post.tarotCardAttachment && (
                        <div className="bg-gradient-to-r from-purple-950/80 to-[#180d32] border border-purple-400/40 rounded-2xl p-3.5 flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-400/50 flex items-center justify-center text-xl shadow-md">
                            {post.tarotCardAttachment.icon}
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider">
                              Arcano / Carta em Destaque
                            </span>
                            <h5 className="font-bold text-white text-xs">{post.tarotCardAttachment.name}</h5>
                            <p className="text-[11px] text-purple-300">{post.tarotCardAttachment.summary}</p>
                          </div>
                        </div>
                      )}

                      {/* Post Image */}
                      {post.imageUrl && (
                        <div className="rounded-2xl overflow-hidden border border-purple-500/30 max-h-[420px]">
                          <img
                            src={post.imageUrl}
                            alt="Foto da publicação"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      {/* Interaction Bar: Likes & Comments Trigger */}
                      <div className="flex items-center justify-between pt-3 border-t border-purple-500/20 text-xs text-purple-300">
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => handleToggleLike(post.id)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
                              isLikedByMe
                                ? 'bg-red-500/20 border-red-500 text-red-300'
                                : 'bg-purple-950/40 hover:bg-purple-900 border-purple-500/30 text-purple-300'
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${isLikedByMe ? 'fill-red-400 text-red-400' : ''}`} />
                            <span>{post.likes} Apoios</span>
                          </button>

                          <button
                            onClick={() =>
                              setExpandedComments({
                                ...expandedComments,
                                [post.id]: !isCommentsOpen
                              })
                            }
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/40 hover:bg-purple-900 border border-purple-500/30 text-purple-300 transition-all cursor-pointer"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span>{post.comments.length} Comentários</span>
                          </button>
                        </div>

                        {post.authorRole === 'cartomante' && (
                          <button
                            onClick={() => {
                              const text = encodeURIComponent(
                                `Olá ${post.authorName}! Vi sua publicação na Comunidade Cartomante 24h e gostaria de agendar uma consulta no WhatsApp!`
                              );
                              window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-400/40 text-emerald-200 font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Chamar Cartomante</span>
                          </button>
                        )}
                      </div>

                      {/* Comments Thread */}
                      {isCommentsOpen && (
                        <div className="pt-3 border-t border-purple-500/20 space-y-3">
                          {/* Comments List */}
                          {post.comments.map((comment) => (
                            <div
                              key={comment.id}
                              className="flex items-start gap-2.5 p-3 rounded-2xl bg-black/40 border border-purple-500/20 text-xs"
                            >
                              <img
                                src={comment.authorAvatar}
                                alt={comment.authorName}
                                className="w-8 h-8 rounded-xl object-cover border border-purple-400/30 shrink-0 mt-0.5"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-white text-xs">
                                    {comment.authorName}
                                  </span>
                                  {comment.authorRole === 'cartomante' && (
                                    <span className="px-1.5 py-0.2 rounded bg-purple-600/60 text-[9px] text-amber-300 font-bold">
                                      Cartomante
                                    </span>
                                  )}
                                  <span className="text-[10px] text-purple-400 ml-auto">
                                    {comment.createdAt}
                                  </span>
                                </div>
                                <p className="text-neutral-200 mt-1 leading-relaxed">
                                  {comment.content}
                                </p>
                              </div>
                            </div>
                          ))}

                          {/* Add Comment Input */}
                          <div className="flex items-center gap-2 pt-2">
                            <input
                              type="text"
                              value={commentInputs[post.id] || ''}
                              onChange={(e) =>
                                setCommentInputs({
                                  ...commentInputs,
                                  [post.id]: e.target.value
                                })
                              }
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddComment(post.id);
                                }
                              }}
                              placeholder="Escreva um comentário carinhoso..."
                              className="flex-1 px-3.5 py-2 bg-black/60 border border-purple-500/30 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                            />
                            <button
                              onClick={() => handleAddComment(post.id)}
                              className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-all cursor-pointer"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            </div>

            {/* Sidebar Column (4 cols) */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* Active Live Streams Widget */}
              <div className="bg-[#0e071e] border-2 border-red-500/40 rounded-3xl p-5 shadow-2xl shadow-red-950/30 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-purple-500/20">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                    <h3 className="font-bold text-white text-sm uppercase tracking-wide">
                      Live Transmitindo Agora
                    </h3>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-red-950 border border-red-500/50 text-[10px] font-black text-red-200 uppercase">
                    Ao Vivo
                  </span>
                </div>

                {liveStreams.length > 0 ? (
                  <div className="space-y-3">
                    {liveStreams.map((stream) => (
                      <div
                        key={stream.id}
                        className="bg-purple-950/50 border border-purple-400/30 rounded-2xl p-3.5 space-y-3 hover:border-purple-400/60 transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={stream.cartomanteAvatar}
                            alt={stream.cartomanteName}
                            className="w-11 h-11 rounded-2xl object-cover border-2 border-red-500 shadow-md"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-white text-xs leading-tight line-clamp-1">
                              {stream.title}
                            </h4>
                            <p className="text-[11px] text-purple-300">{stream.cartomanteName}</p>
                            <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
                              <Eye className="w-3 h-3" />
                              {stream.viewersCount} assistindo
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => onOpenLiveStream(stream)}
                          className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-500 hover:to-fuchsia-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-red-950/60 transition-all cursor-pointer"
                        >
                          <Radio className="w-3.5 h-3.5" />
                          <span>Assistir Live da Cartomante</span>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-purple-300 text-center py-4">
                    Nenhuma live ativa no momento. Nossas cartomantes iniciam transmissões diariamente!
                  </p>
                )}
              </div>

              {/* Quick WhatsApp Group Banner */}
              <div className="bg-gradient-to-br from-emerald-950/80 via-[#0f0720] to-purple-950/80 border-2 border-emerald-500/40 rounded-3xl p-5 shadow-2xl shadow-emerald-950/40 space-y-3 text-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-600/30 border border-emerald-400 flex items-center justify-center text-emerald-300 mx-auto shadow-md">
                  <Users className="w-6 h-6 animate-pulse" />
                </div>
                <h4 className="font-serif font-black text-white text-base">
                  Grupo VIP de WhatsApp 24h
                </h4>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  Entre no nosso grupo oficial para receber cartas diárias e tirar 1 pergunta por R$ 20 ou 3 perguntas por R$ 50!
                </p>
                <button
                  onClick={() => {
                    if (config.groupWhatsAppLink) window.open(config.groupWhatsAppLink, '_blank');
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Entrar no Grupo de WhatsApp</span>
                </button>
              </div>

              {/* Cartomantes on Plantão Quick List */}
              <div className="bg-[#0e071e] border-2 border-purple-500/30 rounded-3xl p-5 shadow-xl shadow-purple-950/40 space-y-3">
                <h4 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Cartomantes no Plantão
                </h4>
                <div className="space-y-2.5">
                  {CARTOMANTES_PROFILES.slice(0, 3).map((cartomante) => (
                    <div
                      key={cartomante.id}
                      className="flex items-center justify-between gap-2 p-2 rounded-xl bg-black/40 border border-purple-500/20"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={cartomante.avatar}
                          alt={cartomante.name}
                          className="w-9 h-9 rounded-xl object-cover border border-purple-400/50"
                        />
                        <div>
                          <p className="font-bold text-white text-xs">{cartomante.name}</p>
                          <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            {cartomante.statusText}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleToggleFavorite(cartomante.id)}
                        className={`p-1.5 rounded-lg border text-xs cursor-pointer ${
                          favorites.includes(cartomante.id)
                            ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                            : 'bg-purple-950/60 border-purple-500/30 text-purple-300'
                        }`}
                        title="Favoritar Cartomante"
                      >
                        <Star className={`w-3.5 h-3.5 ${favorites.includes(cartomante.id) ? 'fill-amber-400' : ''}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: LIVES & TRANSMISSÕES */}
        {activeTab === 'lives' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between flex-wrap gap-4 bg-gradient-to-r from-red-950/80 via-[#150a2b] to-purple-950/80 border-2 border-red-500/40 rounded-3xl p-6 shadow-2xl">
              <div>
                <h2 className="text-xl sm:text-2xl font-serif font-black text-white flex items-center gap-2">
                  <Radio className="w-6 h-6 text-red-400 animate-pulse" />
                  Transmissões de Tarot Ao Vivo
                </h2>
                <p className="text-xs sm:text-sm text-purple-300 mt-1">
                  Assista a tiragens coletivas ao vivo feitas por cartomantes oficiais autorizadas e participe via WhatsApp!
                </p>
              </div>

              {isAuthorizedToStream && (
                <button
                  onClick={() => setIsCreateLiveOpen(true)}
                  className="px-5 py-3 rounded-2xl bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-500 hover:to-fuchsia-500 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-red-950 transition-all cursor-pointer hover:scale-105"
                >
                  <Radio className="w-4 h-4" />
                  <span>Abrir Transmissão Ao Vivo (Cartomante)</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {liveStreams.map((stream) => (
                <div
                  key={stream.id}
                  className="bg-[#0f0720] border-2 border-purple-500/40 hover:border-purple-400 rounded-3xl overflow-hidden shadow-2xl shadow-purple-950/60 transition-all group flex flex-col justify-between"
                >
                  <div className="relative h-48 overflow-hidden bg-black/60">
                    <img
                      src={stream.bannerUrl || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80'}
                      alt={stream.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0f0720] via-transparent to-black/50" />

                    <div className="absolute top-3 left-3 flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-red-600 text-white font-black text-[10px] rounded-full uppercase flex items-center gap-1 shadow-lg animate-pulse">
                        <Radio className="w-3 h-3" />
                        Ao Vivo
                      </span>
                      <span className="px-2.5 py-1 bg-black/70 border border-purple-400/40 text-purple-200 font-semibold text-[10px] rounded-full flex items-center gap-1 backdrop-blur-sm">
                        <Eye className="w-3 h-3 text-emerald-400" />
                        {stream.viewersCount}
                      </span>
                    </div>

                    <div className="absolute bottom-3 left-3 flex items-center gap-2.5">
                      <img
                        src={stream.cartomanteAvatar}
                        alt={stream.cartomanteName}
                        className="w-12 h-12 rounded-2xl object-cover border-2 border-purple-400 shadow-md"
                      />
                      <div>
                        <h4 className="font-bold text-white text-xs">{stream.cartomanteName}</h4>
                        <p className="text-[10px] text-purple-300">{stream.cartomanteTitle}</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-white text-sm leading-snug">{stream.title}</h3>
                      <p className="text-xs text-purple-300 mt-1">{stream.topic}</p>
                      {stream.featuredCard && (
                        <div className="mt-2.5 p-2 rounded-xl bg-purple-950/60 border border-purple-500/30 text-[11px] text-amber-300 font-medium">
                          ✨ Revelação: {stream.featuredCard}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2 pt-2 border-t border-purple-500/20">
                      <button
                        onClick={() => onOpenLiveStream(stream)}
                        className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-500 hover:to-fuchsia-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950 transition-all cursor-pointer"
                      >
                        <Radio className="w-4 h-4" />
                        <span>Entrar na Sala da Live</span>
                      </button>

                      <button
                        onClick={() => {
                          const link = stream.whatsappGroupLink || config.groupWhatsAppLink;
                          if (link) window.open(link, '_blank');
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Entrar no Grupo de WhatsApp Dela</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: MEMBROS & CARTOMANTES */}
        {activeTab === 'members' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between flex-wrap gap-4 pb-4 border-b border-purple-500/20">
              <div>
                <h2 className="text-xl sm:text-2xl font-serif font-black text-white">
                  Membros, Cartomantes & Amigos
                </h2>
                <p className="text-xs sm:text-sm text-purple-300">
                  Conecte-se com pessoas que compartilham da mesma fé oracular e adicione aos favoritos!
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Cartomantes Section */}
              {CARTOMANTES_PROFILES.map((cartomante) => {
                const isFav = favorites.includes(cartomante.id);
                return (
                  <div
                    key={cartomante.id}
                    className="bg-[#0e071e] border-2 border-purple-500/40 rounded-3xl p-5 shadow-xl shadow-purple-950/40 flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <img
                          src={cartomante.avatar}
                          alt={cartomante.name}
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-purple-400 shadow-md"
                        />
                        <button
                          onClick={() => handleToggleFavorite(cartomante.id)}
                          className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                            isFav
                              ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                              : 'bg-purple-950/60 hover:bg-purple-900 border-purple-500/30 text-purple-300'
                          }`}
                        >
                          <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-400' : ''}`} />
                          <span>{isFav ? 'Favorito' : 'Favoritar'}</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-bold text-white text-base">{cartomante.name}</h4>
                        <span className="px-2 py-0.5 rounded bg-purple-600/60 text-[10px] text-amber-300 font-bold">
                          Cartomante
                        </span>
                      </div>
                      <p className="text-xs text-purple-300 mt-0.5">{cartomante.title}</p>
                      <p className="text-xs text-neutral-300 mt-2 line-clamp-3 leading-relaxed">
                        {cartomante.bio}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-purple-500/20 flex gap-2">
                      <button
                        onClick={() => {
                          const text = encodeURIComponent(
                            `Olá ${cartomante.name}! Encontrei seu perfil na Comunidade e gostaria de uma consulta no WhatsApp!`
                          );
                          window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
                        }}
                        className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Chamar WhatsApp</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 4: MEUS FAVORITOS & AMIGOS */}
        {activeTab === 'favorites' && (
          <div className="space-y-6">
            <div className="pb-4 border-b border-purple-500/20">
              <h2 className="text-xl sm:text-2xl font-serif font-black text-white flex items-center gap-2">
                <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
                Meus Favoritos & Amigos Salvos
              </h2>
              <p className="text-xs sm:text-sm text-purple-300 mt-1">
                Acesse com facilidade seus amigos, cartomantes favoritas e publicações salvas.
              </p>
            </div>

            {favorites.length === 0 ? (
              <div className="text-center py-16 bg-[#0f0720] border border-purple-500/30 rounded-3xl p-8">
                <Star className="w-12 h-12 text-purple-400 mx-auto mb-3 opacity-40" />
                <h3 className="font-bold text-white text-base">Você ainda não favoritou ninguém</h3>
                <p className="text-xs text-purple-300 max-w-md mx-auto mt-1">
                  Navegue pelo Feed e pela lista de Membros e clique na estrelinha ⭐ para salvar suas cartomantes e amigos favoritos aqui!
                </p>
                <button
                  onClick={() => setActiveTab('feed')}
                  className="mt-4 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs cursor-pointer shadow-lg"
                >
                  Explorar Feed da Comunidade
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {CARTOMANTES_PROFILES.filter((c) => favorites.includes(c.id)).map((favCartomante) => (
                  <div
                    key={favCartomante.id}
                    className="bg-[#0e071e] border-2 border-amber-400/40 rounded-3xl p-5 shadow-xl shadow-amber-950/30 flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <img
                          src={favCartomante.avatar}
                          alt={favCartomante.name}
                          className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400"
                        />
                        <button
                          onClick={() => handleToggleFavorite(favCartomante.id)}
                          className="p-2 rounded-xl bg-amber-400/20 border border-amber-400 text-amber-300 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Star className="w-4 h-4 fill-amber-400" />
                          <span>Favoritado</span>
                        </button>
                      </div>

                      <h4 className="font-bold text-white text-base">{favCartomante.name}</h4>
                      <p className="text-xs text-amber-300 font-semibold">{favCartomante.title}</p>
                      <p className="text-xs text-neutral-300 mt-2 line-clamp-3">
                        {favCartomante.bio}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        const text = encodeURIComponent(
                          `Olá ${favCartomante.name}! Sou seu consulente favorito e gostaria de tirar uma dúvida no WhatsApp!`
                        );
                        window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Chamar no WhatsApp Direto</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Modal: Edit My Profile & Bio */}
      {isEditingMyProfile && currentUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="bg-[#0e071c] border-2 border-purple-500/50 rounded-3xl w-full max-w-lg p-6 shadow-2xl shadow-purple-950 overflow-hidden space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-purple-500/30">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-purple-300" />
                <h3 className="font-serif font-black text-white text-lg">
                  Editar Meu Perfil na Comunidade
                </h3>
              </div>
              <button
                onClick={() => setIsEditingMyProfile(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMyProfile} className="space-y-4">
              {/* Photo Picker */}
              <div className="flex flex-col items-center gap-2 pb-2">
                <AvatarPicker
                  currentAvatar={currentUser.avatar}
                  onAvatarChange={(newUrl) => {
                    const updated = { ...currentUser, avatar: newUrl };
                    onUpdateCurrentUser(updated);
                  }}
                  userName={currentUser.name}
                  label="Trocar Minha Foto de Perfil"
                  size="lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Nome Exibido:
                </label>
                <input
                  type="text"
                  value={currentUser.name}
                  disabled
                  className="w-full px-3 py-2 bg-black/50 border border-purple-500/30 rounded-xl text-xs text-neutral-300"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Minha Bio Mística & Intenção:
                </label>
                <textarea
                  value={myBio}
                  onChange={(e) => setMyBio(e.target.value)}
                  rows={3}
                  placeholder="Escreva sobre você, seus interesses oraculares, signos favoritos..."
                  className="w-full p-3 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Signo Astrológico:
                </label>
                <select
                  value={mySign}
                  onChange={(e) => setMySign(e.target.value)}
                  className="w-full px-3 py-2 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white focus:outline-none focus:border-purple-400"
                >
                  <option value="Áries ♈">Áries ♈</option>
                  <option value="Touro ♉">Touro ♉</option>
                  <option value="Gêmeos ♊">Gêmeos ♊</option>
                  <option value="Câncer ♋">Câncer ♋</option>
                  <option value="Leão ♌">Leão ♌</option>
                  <option value="Virgem ♍">Virgem ♍</option>
                  <option value="Libra ♎">Libra ♎</option>
                  <option value="Escorpião ♏">Escorpião ♏</option>
                  <option value="Sagitário ♐">Sagitário ♐</option>
                  <option value="Capricórnio ♑">Capricórnio ♑</option>
                  <option value="Aquário ♒">Aquário ♒</option>
                  <option value="Peixes ♓">Peixes ♓</option>
                </select>
              </div>

              <div className="pt-3 border-t border-purple-500/30 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditingMyProfile(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-300 text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg"
                >
                  Salvar Perfil
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Start Live Stream for Cartomante/Admin */}
      {isCreateLiveOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="bg-[#0e071c] border-2 border-red-500/50 rounded-3xl w-full max-w-lg p-6 shadow-2xl shadow-red-950 overflow-hidden space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-purple-500/30">
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-red-400 animate-pulse" />
                <h3 className="font-serif font-black text-white text-lg">
                  Iniciar Transmissão de Tarot Ao Vivo
                </h3>
              </div>
              <button
                onClick={() => setIsCreateLiveOpen(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStartLiveStream} className="space-y-4">
              <div className="p-3 rounded-2xl bg-purple-950/60 border border-purple-500/30 text-xs text-purple-200">
                ✨ <strong>Aviso Importante:</strong> Durante a transmissão, os consulentes verão o botão direto para entrar no seu Grupo de WhatsApp ou chamá-la no privado. (Sem presentes ou moedas virtuais).
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Título da Live:
                </label>
                <input
                  type="text"
                  value={newLiveTitle}
                  onChange={(e) => setNewLiveTitle(e.target.value)}
                  placeholder="Ex: 🔴 Tiragem Coletiva: O que ele(a) sente por mim agora?"
                  required
                  className="w-full px-3.5 py-2.5 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Tema da Leitura:
                </label>
                <input
                  type="text"
                  value={newLiveTopic}
                  onChange={(e) => setNewLiveTopic(e.target.value)}
                  placeholder="Ex: Reconciliação amorosa e abertura de caminhos financeiros"
                  className="w-full px-3.5 py-2.5 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-purple-200 mb-1">
                  Arcano / Carta em Destaque na Mesa:
                </label>
                <input
                  type="text"
                  value={newLiveFeaturedCard}
                  onChange={(e) => setNewLiveFeaturedCard(e.target.value)}
                  placeholder="Ex: A Estrela + A Aliança Cigana"
                  className="w-full px-3.5 py-2.5 bg-black/60 border border-purple-500/40 rounded-xl text-xs text-white placeholder-purple-400/50 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div className="pt-3 border-t border-purple-500/30 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateLiveOpen(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-300 text-xs font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-500 hover:to-fuchsia-500 text-white text-xs font-black shadow-lg shadow-red-950 flex items-center gap-1.5 cursor-pointer"
                >
                  <Radio className="w-4 h-4" />
                  <span>Transmitir Agora</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Member/Cartomante Profile Quick View */}
      {viewingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="bg-[#0e071c] border-2 border-purple-500/50 rounded-3xl w-full max-w-md p-6 shadow-2xl shadow-purple-950 overflow-hidden space-y-4 text-center">
            <div className="flex justify-end">
              <button
                onClick={() => setViewingProfile(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <img
              src={viewingProfile.authorAvatar || viewingProfile.avatar}
              alt={viewingProfile.authorName || viewingProfile.name}
              className="w-24 h-24 rounded-full object-cover border-4 border-purple-400 mx-auto shadow-xl shadow-purple-950"
            />

            <div>
              <h3 className="text-xl font-serif font-bold text-white">
                {viewingProfile.authorName || viewingProfile.name}
              </h3>
              <p className="text-xs text-purple-300 mt-0.5">
                {viewingProfile.authorTitle || viewingProfile.title || 'Membro da Comunidade'}
              </p>
            </div>

            {viewingProfile.authorBio && (
              <p className="text-xs text-neutral-200 leading-relaxed bg-purple-950/40 p-3 rounded-2xl border border-purple-500/30">
                "{viewingProfile.authorBio}"
              </p>
            )}

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  handleToggleFavorite(viewingProfile.authorId || viewingProfile.id);
                  setViewingProfile(null);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-400/40 text-purple-200 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Star className="w-4 h-4 text-amber-400" />
                <span>
                  {favorites.includes(viewingProfile.authorId || viewingProfile.id)
                    ? 'Remover Favorito'
                    : 'Adicionar aos Favoritos'}
                </span>
              </button>

              <button
                onClick={() => {
                  const name = viewingProfile.authorName || viewingProfile.name;
                  const text = encodeURIComponent(`Olá ${name}! Vi seu perfil na Comunidade Cartomante 24h!`);
                  window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
                }}
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
