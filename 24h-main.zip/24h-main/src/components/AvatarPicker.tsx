import { useState, useRef, type ChangeEvent, type DragEvent } from 'react';
import { Camera, Upload, Sparkles, Image, Check, Trash2, RefreshCw } from 'lucide-react';
import catLogo from '../assets/images/mystical_cat_logo_1787014257234.jpg';

export const PRESET_AVATARS = [
  {
    id: 'mystic-cat',
    name: 'Gatinho Místico (Mascote)',
    url: catLogo
  },
  {
    id: 'mystic-1',
    name: 'Cigana de Luz',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-2',
    name: 'Sacerdotisa da Noite',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-3',
    name: 'Mestra do Baralho',
    url: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-4',
    name: 'Guardiã Espiritual',
    url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-5',
    name: 'Mentor de Sabedoria',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-6',
    name: 'Lótus Dourada',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-7',
    name: 'Guardião dos Caminhos',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80'
  },
  {
    id: 'mystic-8',
    name: 'Consulente Astral',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80'
  }
];

interface AvatarPickerProps {
  currentAvatar?: string;
  onAvatarChange: (newAvatarUrl: string) => void;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  userName?: string;
}

export function AvatarPicker({
  currentAvatar,
  onAvatarChange,
  label = 'Foto de Perfil',
  size = 'md',
  userName = 'Perfil'
}: AvatarPickerProps) {
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Resize and compress uploaded image to a clean 300x300 Base64 WebP/JPEG for fast storage
  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione um arquivo de imagem válido (PNG, JPG, WEBP).');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 360;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.85);
          onAvatarChange(compressedBase64);
          setIsUploading(false);
          setIsPickerOpen(false);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleApplyUrl = () => {
    if (customUrl.trim()) {
      onAvatarChange(customUrl.trim());
      setCustomUrl('');
      setIsPickerOpen(false);
    }
  };

  const dimensionClasses = {
    sm: 'w-12 h-12 text-lg',
    md: 'w-20 h-20 text-2xl',
    lg: 'w-28 h-28 text-4xl'
  }[size];

  return (
    <div className="flex flex-col items-center">
      {/* Avatar Display & Trigger */}
      <div className="relative group">
        <div
          className={`${dimensionClasses} rounded-full bg-neutral-900 border-2 border-amber-400/80 overflow-hidden flex items-center justify-center text-amber-300 font-bold shadow-lg shadow-amber-500/10 cursor-pointer transition-all duration-300 group-hover:border-amber-300 group-hover:scale-105`}
          onClick={() => setIsPickerOpen(!isPickerOpen)}
          title="Clique para alterar a foto"
        >
          {currentAvatar ? (
            <img
              src={currentAvatar}
              alt={userName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <span>{userName.charAt(0).toUpperCase()}</span>
          )}
        </div>

        {/* Floating Camera / Edit Icon badge */}
        <button
          type="button"
          onClick={() => setIsPickerOpen(!isPickerOpen)}
          className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-md border-2 border-neutral-950 transition-transform group-hover:scale-110 cursor-pointer"
          title="Mudar foto"
        >
          <Camera className="w-3.5 h-3.5" />
        </button>
      </div>

      <button
        type="button"
        onClick={() => setIsPickerOpen(!isPickerOpen)}
        className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 hover:underline mt-2 cursor-pointer flex items-center gap-1"
      >
        <span>{label}</span>
      </button>

      {/* Popover / Modal with Multiple Photo Sources */}
      {isPickerOpen && (
        <div className="mt-3 w-full max-w-md p-4 bg-neutral-950 border border-amber-500/40 rounded-2xl shadow-2xl text-left space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <span className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-amber-400" />
              Escolha sua Foto de Perfil
            </span>
            <button
              type="button"
              onClick={() => setIsPickerOpen(false)}
              className="text-[10px] text-neutral-400 hover:text-white px-2 py-0.5 rounded bg-neutral-900"
            >
              Fechar
            </button>
          </div>

          {/* 1. Upload from Computer or Phone */}
          <div>
            <span className="text-[11px] font-semibold text-neutral-300 block mb-1.5">
              1. Enviar do seu Computador ou Celular:
            </span>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-4 rounded-xl border-2 border-dashed text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1.5 ${
                isDragging
                  ? 'border-amber-400 bg-amber-950/20'
                  : 'border-neutral-700 hover:border-amber-400/60 bg-neutral-900/60'
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
              <Upload className="w-5 h-5 text-amber-400" />
              <p className="text-xs font-bold text-neutral-200">
                {isUploading ? 'Carregando foto...' : 'Clique ou arraste uma foto aqui'}
              </p>
              <span className="text-[10px] text-neutral-400">JPG, PNG, GIF ou WEBP</span>
            </div>
          </div>

          {/* 2. Choose from Spiritual / Mystical Avatar Gallery */}
          <div>
            <span className="text-[11px] font-semibold text-neutral-300 block mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              2. Ou selecione um Avatar Místico da Galeria:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {PRESET_AVATARS.map((preset) => {
                const isSelected = currentAvatar === preset.url;
                return (
                  <button
                    type="button"
                    key={preset.id}
                    onClick={() => {
                      onAvatarChange(preset.url);
                      setIsPickerOpen(false);
                    }}
                    className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all group ${
                      isSelected
                        ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105'
                        : 'border-neutral-800 hover:border-amber-500/50'
                    }`}
                    title={preset.name}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    {isSelected && (
                      <div className="absolute inset-0 bg-amber-500/30 flex items-center justify-center">
                        <Check className="w-4 h-4 text-amber-200" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Custom Image URL */}
          <div>
            <span className="text-[11px] font-semibold text-neutral-300 block mb-1">
              3. Ou cole o link direto de uma imagem na web:
            </span>
            <div className="flex gap-2">
              <input
                type="url"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://exemplo.com/minha-foto.jpg"
                className="flex-1 px-3 py-1.5 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                onClick={handleApplyUrl}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg transition-all cursor-pointer"
              >
                Aplicar
              </button>
            </div>
          </div>

          {/* Remove / Reset Option */}
          {currentAvatar && (
            <div className="pt-2 border-t border-neutral-800 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  onAvatarChange('');
                  setIsPickerOpen(false);
                }}
                className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>Remover foto atual</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
