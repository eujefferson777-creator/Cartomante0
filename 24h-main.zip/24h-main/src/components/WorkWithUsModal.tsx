import { useState, type FormEvent } from 'react';
import { Sparkles, Users, Send, CheckCircle2, AlertCircle, X, Shield, Phone, Mail, Link as LinkIcon, Heart, BookOpen, Camera } from 'lucide-react';
import { CartomanteCandidate } from '../types';
import { AvatarPicker } from './AvatarPicker';

interface WorkWithUsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCandidateSubmitted?: (candidate: CartomanteCandidate) => void;
}

export function WorkWithUsModal({ isOpen, onClose, onCandidateSubmitted }: WorkWithUsModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [avatar, setAvatar] = useState('https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80');
  const [experienceYears, setExperienceYears] = useState(5);
  const [groupLink, setGroupLink] = useState('');
  const [bio, setBio] = useState('');
  const [socialMedia, setSocialMedia] = useState('');
  const [selectedDecks, setSelectedDecks] = useState<string[]>(['Baralho Cigano (Lenormand)']);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>(['Amor e Reconciliação', 'Caminhos Financeiros']);

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const deckOptions = [
    'Baralho Cigano (Lenormand)',
    'Tarot de Marselha',
    'Tarot dos Orixás',
    'Tarot de Rider Waite',
    'Oráculo das Deusas',
    'Mesa Real 36 Cartas'
  ];

  const specialtyOptions = [
    'Amor e Reconciliação',
    'Caminhos Financeiros e Trabalho',
    'Limpeza Espiritual e Energética',
    'Harmonia Familiar e Casamento',
    'Perguntas Rápidas (1 Pergunta R$ 20 / 3 Perguntas R$ 50)',
    'Afastamento de Energias Negativas'
  ];

  const toggleDeck = (deck: string) => {
    if (selectedDecks.includes(deck)) {
      setSelectedDecks(selectedDecks.filter((d) => d !== deck));
    } else {
      setSelectedDecks([...selectedDecks, deck]);
    }
  };

  const toggleSpecialty = (spec: string) => {
    if (selectedSpecialties.includes(spec)) {
      setSelectedSpecialties(selectedSpecialties.filter((s) => s !== spec));
    } else {
      setSelectedSpecialties([...selectedSpecialties, spec]);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name || !email || !phone || !groupLink) {
      setErrorMsg('Por favor, preencha todos os campos obrigatórios, incluindo o Link do seu Grupo de WhatsApp.');
      return;
    }

    if (!groupLink.includes('whatsapp.com') && !groupLink.includes('wa.me')) {
      setErrorMsg('O link do grupo deve ser um link válido do WhatsApp (ex: https://chat.whatsapp.com/...)');
      return;
    }

    const newCandidate: CartomanteCandidate = {
      id: 'cand-' + Date.now(),
      name,
      email,
      phone,
      avatar: avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
      experienceYears: Number(experienceYears),
      specialties: selectedSpecialties,
      deckTypes: selectedDecks,
      bio: bio || 'Cartomante dedicada a acolher almas com a sabedoria das cartas.',
      groupLink: groupLink.trim(),
      instagramOrFacebook: socialMedia,
      status: 'pendente',
      appliedAt: new Date().toLocaleDateString('pt-BR'),
      pricePer1Question: 20.0,
      pricePer3Questions: 50.0
    };

    // Save to local storage for Admin to review and approve
    const existingCandidates: CartomanteCandidate[] = JSON.parse(
      localStorage.getItem('cartomante24h_candidates') || '[]'
    );
    existingCandidates.unshift(newCandidate);
    localStorage.setItem('cartomante24h_candidates', JSON.stringify(existingCandidates));

    if (onCandidateSubmitted) {
      onCandidateSubmitted(newCandidate);
    }

    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-neutral-900 border border-amber-500/40 rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl relative">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-950/90 via-neutral-900 to-amber-950/90 p-6 border-b border-neutral-800 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-neutral-100">
                Trabalhe Conosco • Inscrição de Cartomante
              </h3>
              <p className="text-xs text-neutral-400">
                Cadastre-se na equipe 24h. O Administrador avaliará e aprovará seu perfil.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {isSubmitted ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 text-emerald-300 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-serif font-bold text-neutral-100">
                Inscrição Enviada com Sucesso!
              </h4>
              <p className="text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                Obrigado, <strong className="text-amber-300">{name}</strong>! Seus dados, sua foto de perfil e o{' '}
                <strong className="text-emerald-400">link do seu grupo de WhatsApp</strong> foram enviados para a análise do
                Administrador Master.
              </p>
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 text-xs text-neutral-400 max-w-md mx-auto text-left space-y-1.5">
                <p>• <strong>Regra de Atendimento:</strong> 1 Pergunta (R$ 20,00) | 3 Perguntas (R$ 50,00)</p>
                <p>• <strong>Status Atual:</strong> <span className="text-amber-400 font-bold">Pendente de Aprovação pelo Admin</span></p>
                <p>• Assim que aprovado pelo admin, seu perfil e foto ficarão ativos para os clientes jogarem diretamente com você.</p>
              </div>
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-neutral-950 font-bold text-xs rounded-xl transition-all cursor-pointer mt-4"
              >
                Fechar e Aguardar Aprovação
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {errorMsg && (
                <div className="p-3 bg-rose-950/70 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Notice about requirement */}
              <div className="p-3.5 bg-amber-950/40 border border-amber-500/30 rounded-2xl text-xs text-amber-200 leading-relaxed">
                ✨ <strong>Requisito Importante:</strong> Para trabalhar conosco, você deve enviar sua foto profissional, definir seus oráculos e criar um Grupo de WhatsApp próprio. Quando o cliente clicar em jogar com você (1 pergunta R$ 20 / 3 perguntas R$ 50), o botão abrirá direto seu grupo!
              </div>

              {/* Profile Photo Picker */}
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 flex flex-col items-center justify-center">
                <AvatarPicker
                  currentAvatar={avatar}
                  onAvatarChange={(newAv) => setAvatar(newAv)}
                  userName={name || 'Cartomante'}
                  size="md"
                  label="Escolha ou Envie sua Foto de Cartomante"
                />
              </div>

              {/* Personal Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    Nome Profissional / Espiritual *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Mãe Valéria de Ogum"
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">E-mail para Contato *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="cartomante@exemplo.com"
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">WhatsApp Pessoal *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">Anos de Experiência</label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={experienceYears}
                    onChange={(e) => setExperienceYears(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Critical Group Link requirement */}
              <div>
                <label className="block text-xs font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" />
                  Link do seu Grupo do WhatsApp (Obrigatório) *
                </label>
                <input
                  type="url"
                  required
                  value={groupLink}
                  onChange={(e) => setGroupLink(e.target.value)}
                  placeholder="https://chat.whatsapp.com/invite-seu-grupo-aqui"
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-emerald-500/50 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-emerald-400"
                />
                <span className="text-[11px] text-neutral-400 mt-1 block">
                  Este é o link que os clientes clicarão quando escolherem jogar com você no site após aprovação.
                </span>
              </div>

              {/* Decks selection */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-2 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                  Oráculos e Decks que Você Domina
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {deckOptions.map((deck) => {
                    const isSelected = selectedDecks.includes(deck);
                    return (
                      <button
                        type="button"
                        key={deck}
                        onClick={() => toggleDeck(deck)}
                        className={`p-2.5 rounded-xl text-xs font-medium border text-left transition-all ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                        }`}
                      >
                        {deck}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Specialties */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-2 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  Especialidades de Atendimento
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {specialtyOptions.map((spec) => {
                    const isSelected = selectedSpecialties.includes(spec);
                    return (
                      <button
                        type="button"
                        key={spec}
                        onClick={() => toggleSpecialty(spec)}
                        className={`p-2.5 rounded-xl text-xs font-medium border text-left transition-all ${
                          isSelected
                            ? 'bg-purple-500/20 border-purple-400 text-purple-300'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                        }`}
                      >
                        {spec}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bio & Description */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  Apresentação Espiritual & Mensagem para os Clientes
                </label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Conte um pouco sobre sua trajetória espiritual, seus mentores e como você orienta seus consulentes..."
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Social Media link */}
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  Instagram, Facebook ou Canal do YouTube (Opcional)
                </label>
                <input
                  type="text"
                  value={socialMedia}
                  onChange={(e) => setSocialMedia(e.target.value)}
                  placeholder="@seuperfil ou link da sua página"
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Submit button */}
              <button
                type="submit"
                id="submit-candidate-form"
                className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 hover:from-amber-300 text-neutral-950 font-bold text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Send className="w-4 h-4" />
                <span>Enviar Inscrição para Aprovação do Admin</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
