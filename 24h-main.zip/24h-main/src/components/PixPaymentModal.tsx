import { useState } from 'react';
import { QrCode, Copy, Check, X, ShieldCheck, Clock, MessageCircle, ExternalLink } from 'lucide-react';
import { SiteConfig, PricingPlan } from '../types';

interface PixPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PricingPlan | null;
  customPrice?: number;
  customTitle?: string;
  config: SiteConfig;
  onPaymentConfirmed?: () => void;
}

export function PixPaymentModal({
  isOpen,
  onClose,
  plan,
  customPrice,
  customTitle,
  config,
  onPaymentConfirmed
}: PixPaymentModalProps) {
  const [copied, setCopied] = useState(false);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');

  if (!isOpen) return null;

  const finalAmount = customPrice ?? (plan?.price ?? 39.90);
  const finalTitle = customTitle ?? (plan?.title ?? 'Consulta de Cartomancia Online 24h');

  // Simulated EMV PIX string
  const pixCode = `00020126580014br.gov.bcb.pix0136${config.pixKey}520400005303986540${finalAmount.toFixed(2)}5802BR5925${config.pixReceiverName.slice(0, 25)}6009SAO PAULO62070503***6304E8A2`;

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleOpenWhatsAppConfirmation = () => {
    const text = encodeURIComponent(
      `Olá Cartomante 24h! Acabei de gerar o PIX para a *${finalTitle}* (R$ ${finalAmount.toFixed(2)}).\n\n` +
      `👤 *Nome:* ${clientName || 'Consulente'}\n` +
      `📱 *Telefone/WhatsApp:* ${clientPhone || 'Não informado'}\n\n` +
      `Estou pronto(a) para iniciar minha consulta por chamada de vídeo/áudio com a Cartomante de plantão!`
    );
    window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
    if (onPaymentConfirmed) onPaymentConfirmed();
    onClose();
  };

  return (
    <div id="pix-payment-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div id="pix-payment-modal-card" className="w-full max-w-md bg-neutral-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl text-neutral-100 relative">
        <button
          id="close-pix-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center pb-3">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-emerald-500/20 border border-amber-400/40 text-amber-300 mb-2">
            <QrCode className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-serif font-bold text-amber-200">{finalTitle}</h3>
          <p className="text-xs text-neutral-400 mt-0.5">Pagamento Instantâneo via PIX com Liberação Imediata</p>
          <div className="mt-3 text-3xl font-extrabold text-emerald-400 tracking-tight">
            R$ {finalAmount.toFixed(2).replace('.', ',')}
          </div>
        </div>

        {/* QR Code Display */}
        <div className="my-4 p-4 bg-white rounded-2xl flex flex-col items-center justify-center shadow-inner mx-auto max-w-[220px]">
          <svg viewBox="0 0 100 100" className="w-36 h-36">
            <rect width="100" height="100" fill="white" />
            {/* Minimal SVG representation of stylized QR Code */}
            <rect x="10" y="10" width="25" height="25" fill="#0f172a" />
            <rect x="15" y="15" width="15" height="15" fill="white" />
            <rect x="18" y="18" width="9" height="9" fill="#0f172a" />

            <rect x="65" y="10" width="25" height="25" fill="#0f172a" />
            <rect x="70" y="15" width="15" height="15" fill="white" />
            <rect x="73" y="18" width="9" height="9" fill="#0f172a" />

            <rect x="10" y="65" width="25" height="25" fill="#0f172a" />
            <rect x="15" y="70" width="15" height="15" fill="white" />
            <rect x="18" y="73" width="9" height="9" fill="#0f172a" />

            {/* Matrix dots */}
            <rect x="42" y="15" width="6" height="6" fill="#0f172a" />
            <rect x="52" y="18" width="6" height="6" fill="#0f172a" />
            <rect x="42" y="32" width="6" height="6" fill="#0f172a" />
            <rect x="52" y="42" width="6" height="6" fill="#0f172a" />
            <rect x="65" y="45" width="6" height="6" fill="#0f172a" />
            <rect x="75" y="55" width="6" height="6" fill="#0f172a" />
            <rect x="40" y="65" width="6" height="6" fill="#0f172a" />
            <rect x="52" y="75" width="6" height="6" fill="#0f172a" />
            <rect x="65" y="70" width="6" height="6" fill="#0f172a" />
            <rect x="78" y="80" width="6" height="6" fill="#0f172a" />
            <rect x="45" y="85" width="8" height="8" fill="#0f172a" />
          </svg>
          <span className="text-[10px] font-bold text-neutral-800 tracking-wider mt-1 uppercase">PIX Banco Central</span>
        </div>

        {/* PIX Key / Copy Paste */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Chave PIX:</span>
            <span className="text-amber-300 font-mono font-medium">{config.pixKey}</span>
          </div>

          <button
            id="copy-pix-key-btn"
            onClick={handleCopyPix}
            className="w-full py-2.5 px-3 bg-neutral-950 hover:bg-neutral-800 border border-neutral-700 hover:border-amber-400 rounded-xl text-xs font-semibold text-neutral-200 flex items-center justify-center gap-2 transition-all"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">Código PIX Copiado com Sucesso!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-amber-400" />
                <span>Copiar Código PIX Copia e Cola</span>
              </>
            )}
          </button>
        </div>

        {/* Client Fast Info */}
        <div className="mt-4 pt-4 border-t border-neutral-800 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Seu Nome (Opcional):</label>
              <input
                type="text"
                id="input-pix-client-name"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Ex: Maria Santos"
                className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">WhatsApp (com DDD):</label>
              <input
                type="tel"
                id="input-pix-client-phone"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                placeholder="Ex: (11) 99999-8888"
                className="w-full px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-lg text-xs text-neutral-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <button
            id="confirm-pix-whatsapp-btn"
            onClick={handleOpenWhatsAppConfirmation}
            className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Já paguei / Iniciar Atendimento no WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </button>
        </div>

        <div className="mt-3 flex items-center justify-center gap-3 text-[11px] text-neutral-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Sigilo Absoluto
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" /> Atendimento 24h Imediato
          </span>
        </div>
      </div>
    </div>
  );
}
