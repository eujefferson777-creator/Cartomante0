import { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Users, 
  Sparkles, 
  Check, 
  X, 
  ArrowRight, 
  Copy, 
  CheckCircle2, 
  ShieldCheck, 
  Star, 
  Zap,
  HelpCircle,
  Clock
} from 'lucide-react';
import { SiteConfig, CartomanteProfile } from '../types';
import catLogo from '../assets/images/black_cat_logo_1787015840608.jpg';

interface SelectCartomanteGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SiteConfig;
  cartomantes: CartomanteProfile[];
  initialCartomante?: CartomanteProfile | null;
  initialQuestionsCount?: 1 | 3;
}

export function SelectCartomanteGroupModal({
  isOpen,
  onClose,
  config,
  cartomantes,
  initialCartomante,
  initialQuestionsCount = 1
}: SelectCartomanteGroupModalProps) {
  const [selectedCartomante, setSelectedCartomante] = useState<CartomanteProfile>(
    initialCartomante || cartomantes[0] || null
  );
  const [questionsCount, setQuestionsCount] = useState<1 | 3 | 5>(
    initialQuestionsCount === 3 ? 3 : 1
  );
  const [copiedMessage, setCopiedMessage] = useState(false);
  const [redirecting, setRedirecting] = useState(false);

  useEffect(() => {
    if (initialCartomante) {
      setSelectedCartomante(initialCartomante);
    } else if (cartomantes.length > 0 && !selectedCartomante) {
      setSelectedCartomante(cartomantes[0]);
    }
  }, [initialCartomante, cartomantes]);

  if (!isOpen) return null;

  const getPrice = () => {
    if (questionsCount === 1) return config.price1Question || 20.0;
    if (questionsCount === 3) return config.price3Questions || 50.0;
    return 90.0; // Mesa Completa
  };

  const getPlanTitle = () => {
    if (questionsCount === 1) return '1 Pergunta Direta no Grupo';
    if (questionsCount === 3) return '3 Perguntas Aprofundadas no Grupo';
    return 'Mesa Real / Tiragem Completa no Grupo';
  };

  const currentPrice = getPrice();
  const currentPlanTitle = getPlanTitle();
  const cartomanteName = selectedCartomante ? selectedCartomante.name : 'Cartomante de Plantão';

  // Customized message to be sent inside the WhatsApp group
  const messageForGroup = `🔮 *CONSULTA NO GRUPO VIP - CARTOMANTE 24H*\n\nOlá a todos do Grupo Oficial! Entrei aqui e escolhi a cartomante *${cartomanteName}* para jogar comigo dentro do grupo!\n\n📋 *Opção de Jogo:* ${currentPlanTitle}\n💰 *Valor:* R$ ${currentPrice.toFixed(2).replace('.', ',')}\n\nPor favor, *${cartomanteName}* ou administradores, me enviem a chave PIX para eu confirmar o pagamento e enviar minha pergunta para a mesa agora! Gratidão e muito axé! ✨`;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(messageForGroup);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 3000);
  };

  const handleJoinGroupToPlay = () => {
    // Copy the message to clipboard automatically
    try {
      navigator.clipboard.writeText(messageForGroup);
      setCopiedMessage(true);
    } catch (e) {
      console.warn('Clipboard write failed:', e);
    }

    setRedirecting(true);

    setTimeout(() => {
      setRedirecting(false);
      const groupLink = config.groupWhatsAppLink || 'https://chat.whatsapp.com/';
      window.open(groupLink, '_blank');
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-neutral-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0b0416] border border-purple-500/40 rounded-3xl w-full max-w-3xl max-h-[92vh] overflow-y-auto shadow-2xl relative flex flex-col text-white">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-purple-950 via-[#18072c] to-[#0d041c] border-b border-purple-500/30 sticky top-0 z-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shrink-0 shadow-lg shadow-emerald-950/50">
              <MessageCircle className="w-5 h-5 fill-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-black uppercase tracking-wider">
                  ATENDIMENTO OFICIAL NO WHATSAPP
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-purple-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  Plantão 24 Horas
                </span>
              </div>
              <h3 className="font-serif font-black text-lg sm:text-xl text-white mt-0.5">
                Escolha a Cartomante para Jogar no Grupo
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-purple-900/30 hover:bg-purple-800/60 border border-purple-500/30 text-purple-300 hover:text-white transition-all cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 space-y-6 flex-1">
          {/* Informational banner */}
          <div className="p-4 rounded-2xl bg-[#140827] border border-purple-500/30 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-900/60 flex items-center justify-center text-amber-300 shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-xs space-y-1 text-purple-200/90">
              <p className="font-bold text-white">
                Como funciona o jogo dentro do Grupo VIP?
              </p>
              <p>
                O nosso atendimento é realizado exclusivamente pelo Grupo Oficial de WhatsApp. Você escolhe a sua cartomante preferida abaixo, entra no grupo e ela abre a mesa sagrada para responder suas perguntas com sigilo e rapidez!
              </p>
            </div>
          </div>

          {/* STEP 1: SELECT CARTOMANTE */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs flex items-center justify-center font-black">
                  1
                </span>
                <span>Escolha com qual Cartomante você quer jogar:</span>
              </h4>
              <span className="text-[11px] text-emerald-400 font-semibold">
                ✓ Todas online no grupo
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              {cartomantes.map((c) => {
                const isSelected = selectedCartomante?.id === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setSelectedCartomante(c)}
                    className={`p-3.5 rounded-2xl text-left transition-all cursor-pointer relative flex flex-col justify-between border ${
                      isSelected
                        ? 'bg-gradient-to-b from-purple-900/60 via-[#210c3b] to-[#120623] border-amber-400 shadow-xl shadow-purple-950/60 ring-2 ring-amber-400/40'
                        : 'bg-[#120621] hover:bg-[#1c0a33] border-purple-500/20 hover:border-purple-500/40'
                    }`}
                  >
                    {isSelected && (
                      <div className="absolute -top-2 -right-2 bg-gradient-to-r from-amber-400 to-amber-500 text-neutral-950 p-1 rounded-full shadow-lg">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}

                    <div className="flex items-center gap-3">
                      <div className="relative shrink-0">
                        <img
                          src={c.avatar}
                          alt={c.name}
                          className="w-12 h-12 rounded-xl object-cover border-2 border-purple-400/40"
                          referrerPolicy="no-referrer"
                        />
                        <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#120621]"></span>
                      </div>
                      <div className="min-w-0">
                        <h5 className="font-bold text-sm text-white truncate">{c.name}</h5>
                        <p className="text-[11px] text-amber-300 font-medium truncate">{c.title}</p>
                        <div className="flex items-center gap-1 text-[10px] text-purple-300/80 mt-0.5">
                          <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                          <span>{c.rating.toFixed(2)}</span>
                          <span>•</span>
                          <span>{c.experienceYears} anos exp.</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-purple-500/20 flex items-center justify-between text-[11px]">
                      <span className="text-purple-300/80 truncate">
                        {c.deckTypes[0] || 'Baralho Cigano'}
                      </span>
                      <span className={`font-bold text-[10px] px-2 py-0.5 rounded-full ${
                        isSelected 
                          ? 'bg-amber-400 text-neutral-950' 
                          : 'bg-purple-900/60 text-purple-200'
                      }`}>
                        {isSelected ? 'Selecionada' : 'Escolher'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* STEP 2: SELECT GAME OPTION / QUESTIONS */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-purple-600 text-white text-xs flex items-center justify-center font-black">
                2
              </span>
              <span>Escolha o formato do seu jogo no Grupo:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Option 1: 1 Question */}
              <button
                type="button"
                onClick={() => setQuestionsCount(1)}
                className={`p-4 rounded-2xl text-left transition-all cursor-pointer border ${
                  questionsCount === 1
                    ? 'bg-gradient-to-b from-purple-900/60 via-[#1f0b38] to-[#120622] border-emerald-400 ring-2 ring-emerald-400/40 shadow-lg'
                    : 'bg-[#110620] hover:bg-[#1a0930] border-purple-500/20 hover:border-purple-500/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-emerald-300">Consulta Direta</span>
                  <span className="font-black text-base text-white">
                    R$ {(config.price1Question || 20.0).toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <h5 className="font-bold text-sm text-white">1 Pergunta Objetiva</h5>
                <p className="text-[11px] text-purple-200/70 mt-1">
                  Resposta rápida e certeira na mesa sobre amor, trabalho ou decisão.
                </p>
              </button>

              {/* Option 2: 3 Questions (Popular) */}
              <button
                type="button"
                onClick={() => setQuestionsCount(3)}
                className={`p-4 rounded-2xl text-left transition-all cursor-pointer border relative ${
                  questionsCount === 3
                    ? 'bg-gradient-to-b from-purple-900/60 via-[#260e44] to-[#150727] border-amber-400 ring-2 ring-amber-400/40 shadow-xl'
                    : 'bg-[#110620] hover:bg-[#1a0930] border-purple-500/20 hover:border-purple-500/40'
                }`}
              >
                <div className="absolute -top-2.5 right-3 bg-gradient-to-r from-amber-400 to-amber-500 text-neutral-950 font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider shadow">
                  ⭐ MAIS ESCOLHIDA
                </div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-amber-300">Consulta Completa</span>
                  <span className="font-black text-base text-amber-300">
                    R$ {(config.price3Questions || 50.0).toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <h5 className="font-bold text-sm text-white">3 Perguntas Aprofundadas</h5>
                <p className="text-[11px] text-purple-200/70 mt-1">
                  Análise dos 3 pontos chaves da sua vida com conselho espiritual das cartas.
                </p>
              </button>

              {/* Option 3: Full Table */}
              <button
                type="button"
                onClick={() => setQuestionsCount(5)}
                className={`p-4 rounded-2xl text-left transition-all cursor-pointer border ${
                  questionsCount === 5
                    ? 'bg-gradient-to-b from-purple-900/60 via-[#1f0b38] to-[#120622] border-purple-400 ring-2 ring-purple-400/40 shadow-lg'
                    : 'bg-[#110620] hover:bg-[#1a0930] border-purple-500/20 hover:border-purple-500/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-purple-300">Mesa Cigana</span>
                  <span className="font-black text-base text-white">R$ 90,00</span>
                </div>
                <h5 className="font-bold text-sm text-white">Mesa Real Completa</h5>
                <p className="text-[11px] text-purple-200/70 mt-1">
                  Leitura completa de passado, presente e caminhos abertos para o futuro.
                </p>
              </button>
            </div>
          </div>

          {/* STEP 3: PREVIEW MESSAGE */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Mensagem que será enviada no Grupo do WhatsApp:</span>
              </label>

              <button
                type="button"
                onClick={handleCopyMessage}
                className="text-[11px] text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 cursor-pointer transition-colors"
              >
                {copiedMessage ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copiada!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Mensagem</span>
                  </>
                )}
              </button>
            </div>

            {/* WhatsApp Styled Bubble */}
            <div className="p-3.5 rounded-2xl bg-[#0d1b18] border border-emerald-500/30 text-xs font-sans text-emerald-100/90 whitespace-pre-line shadow-inner">
              {messageForGroup}
            </div>
          </div>
        </div>

        {/* Modal Footer / Action CTA */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#120524] via-[#17082e] to-[#0d041c] border-t border-purple-500/30 sticky bottom-0 z-20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <div className="text-xs text-purple-300">
              Jogando com: <strong className="text-white font-bold">{cartomanteName}</strong>
            </div>
            <div className="text-lg font-black text-emerald-400">
              {currentPlanTitle} • R$ {currentPrice.toFixed(2).replace('.', ',')}
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 sm:w-auto px-4 py-3 rounded-2xl bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-purple-200 text-xs font-bold transition-all cursor-pointer"
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handleJoinGroupToPlay}
              disabled={redirecting}
              className="flex-1 sm:w-auto px-7 py-3.5 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm rounded-2xl flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/70 hover:scale-[1.02] transition-all cursor-pointer disabled:opacity-50"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>
                {redirecting
                  ? 'Entrando no Grupo...'
                  : `Entrar no Grupo e Jogar com ${cartomanteName.split(' ')[0]}`}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
