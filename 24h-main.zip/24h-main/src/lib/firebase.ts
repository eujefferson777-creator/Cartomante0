import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocFromServer,
  serverTimestamp
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { UserAccount, CommunityPost, PostComment, LiveStreamSession, LiveChatMessage, LiveQuestion, SiteConfig, CartomanteCandidate, WebChatMessage, WebChatSession } from '../types';

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// CRITICAL: Initialize Firestore with custom database ID from config
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return new Error(JSON.stringify(errInfo));
}

// Test Connection on Boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'site_config', 'connection_test'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or initializing.');
    }
    return false;
  }
}
testConnection();

export const ADMIN_EMAIL = 'eujefferson777@gmail.com';

// -------------------------------------------------------------
// Authentication Helpers (Email + Password, Google Sign-in, etc.)
// -------------------------------------------------------------

export async function registerWithEmailAndPassword(
  name: string,
  email: string,
  pass: string,
  role: 'client' | 'cartomante' = 'client',
  additionalData?: { 
    astrologicalSign?: string; 
    bio?: string; 
    phone?: string; 
    phoneVerified?: boolean;
    cpf?: string;
    birthDate?: string;
    city?: string;
    state?: string;
    avatar?: string;
  }
): Promise<UserAccount> {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
  const fbUser = cred.user;

  // Set display name in Auth
  await updateProfile(fbUser, { displayName: name });

  // Auto assign admin role if email matches the user admin email
  const finalRole: 'client' | 'cartomante' | 'admin' =
    email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : role;

  // Cartomantes need admin approval by default unless it's the admin
  const isApproved = finalRole === 'admin' ? true : finalRole === 'client' ? true : false;

  // Monthly fee default: 30 days from now
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

  const newUser: UserAccount = {
    id: fbUser.uid,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    role: finalRole,
    phone: additionalData?.phone || '',
    phoneVerified: additionalData?.phoneVerified ?? true,
    cpf: additionalData?.cpf || '',
    birthDate: additionalData?.birthDate || '',
    city: additionalData?.city || '',
    state: additionalData?.state || '',
    avatar: additionalData?.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name)}`,
    bio: additionalData?.bio || (finalRole === 'cartomante' ? 'Cartomante consagrada no Cartomante 24h.' : 'Consulente em busca de clareza e caminhos.'),
    astrologicalSign: additionalData?.astrologicalSign || 'Áries',
    isApprovedByAdmin: isApproved,
    monthlyFeeStatus: 'pago',
    monthlyFeeDueDate: thirtyDaysFromNow.toISOString(),
    favoriteUserIds: [],
    createdAt: new Date().toISOString()
  };

  // Save to Firestore users collection
  try {
    await setDoc(doc(db, 'users', fbUser.uid), newUser);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
  }

  return newUser;
}

export async function loginWithEmailAndPass(email: string, pass: string): Promise<UserAccount> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
  const fbUser = cred.user;
  return await fetchOrCreateUserProfile(fbUser);
}

export async function loginWithGoogle(): Promise<UserAccount> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  const cred = await signInWithPopup(auth, provider);
  return await fetchOrCreateUserProfile(cred.user);
}

export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

export function subscribeToAuthChanges(callback: (user: UserAccount | null) => void) {
  return onAuthStateChanged(auth, async (fbUser) => {
    if (fbUser) {
      try {
        const user = await fetchOrCreateUserProfile(fbUser);
        callback(user);
      } catch (err) {
        console.error('Error fetching user profile:', err);
        callback(null);
      }
    } else {
      callback(null);
    }
  });
}

export async function fetchOrCreateUserProfile(fbUser: FirebaseUser): Promise<UserAccount> {
  const userDocRef = doc(db, 'users', fbUser.uid);
  try {
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      const data = snap.data() as UserAccount;
      // If email is the admin email, ensure role is admin
      if (fbUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() && data.role !== 'admin') {
        data.role = 'admin';
        data.isApprovedByAdmin = true;
        await updateDoc(userDocRef, { role: 'admin', isApprovedByAdmin: true });
      }
      return data;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `users/${fbUser.uid}`);
  }

  // Create new profile if not exists
  const isAdmin = fbUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
  const thirtyDays = new Date();
  thirtyDays.setDate(thirtyDays.getDate() + 30);

  const newUser: UserAccount = {
    id: fbUser.uid,
    name: fbUser.displayName || (isAdmin ? 'Admin Jefferson' : 'Consulente'),
    email: fbUser.email?.toLowerCase() || '',
    role: isAdmin ? 'admin' : 'client',
    phone: '',
    phoneVerified: true,
    avatar: fbUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(fbUser.displayName || 'Consulente')}`,
    bio: isAdmin ? 'Administrador Geral do Portal Cartomante 24h.' : 'Consulente conectado às energias.',
    astrologicalSign: 'Leão',
    isApprovedByAdmin: true,
    monthlyFeeStatus: 'pago',
    monthlyFeeDueDate: thirtyDays.toISOString(),
    favoriteUserIds: [],
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(userDocRef, newUser);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `users/${fbUser.uid}`);
  }

  return newUser;
}

export async function saveUserProfile(user: UserAccount): Promise<void> {
  try {
    await setDoc(doc(db, 'users', user.id), user, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${user.id}`);
  }
}

// -------------------------------------------------------------
// Admin Helpers for Users & Cartomantes Management
// -------------------------------------------------------------

export function subscribeToAllUsers(callback: (users: UserAccount[]) => void) {
  const usersRef = collection(db, 'users');
  return onSnapshot(usersRef, (snapshot) => {
    const list: UserAccount[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as UserAccount);
    });
    // Sort by createdAt desc
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    callback(list);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, 'users');
  });
}

export async function updateUserApprovalStatus(userId: string, isApproved: boolean): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', userId), {
      isApprovedByAdmin: isApproved
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}

export async function updateUserMonthlyFeeStatus(
  userId: string, 
  status: 'pago' | 'pendente' | 'vencido', 
  dueDate?: string
): Promise<void> {
  try {
    const payload: Partial<UserAccount> = {
      monthlyFeeStatus: status
    };
    if (dueDate) {
      payload.monthlyFeeDueDate = dueDate;
    }
    await updateDoc(doc(db, 'users', userId), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}

export async function updateUserRole(userId: string, newRole: 'client' | 'cartomante' | 'admin'): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', userId), {
      role: newRole,
      isApprovedByAdmin: newRole === 'cartomante' ? false : true
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}

// -------------------------------------------------------------
// Community Posts & Comments in Firestore
// -------------------------------------------------------------

export function subscribeToCommunityPosts(callback: (posts: CommunityPost[]) => void) {
  const postsCollection = collection(db, 'community_posts');
  return onSnapshot(postsCollection, (snapshot) => {
    const posts: CommunityPost[] = [];
    snapshot.forEach((docSnap) => {
      posts.push({ id: docSnap.id, ...docSnap.data() } as CommunityPost);
    });
    // Sort by createdAt desc
    posts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    callback(posts);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, 'community_posts');
  });
}

export async function createCommunityPost(post: Omit<CommunityPost, 'id'>): Promise<string> {
  const postRef = collection(db, 'community_posts');
  try {
    const docRef = await addDoc(postRef, {
      ...post,
      createdAt: new Date().toISOString()
    });
    return docRef.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, 'community_posts');
    throw err;
  }
}

export async function toggleLikePost(postId: string, userId: string, currentLikedBy: string[]): Promise<void> {
  const isLiked = currentLikedBy.includes(userId);
  const newLikedBy = isLiked
    ? currentLikedBy.filter((id) => id !== userId)
    : [...currentLikedBy, userId];

  try {
    await updateDoc(doc(db, 'community_posts', postId), {
      likedBy: newLikedBy,
      likes: newLikedBy.length
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `community_posts/${postId}`);
  }
}

export async function addCommentToPost(postId: string, comment: Omit<PostComment, 'id'>): Promise<void> {
  try {
    const commentsRef = collection(db, 'community_posts', postId, 'comments');
    await addDoc(commentsRef, {
      ...comment,
      createdAt: new Date().toISOString()
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `community_posts/${postId}/comments`);
  }
}

// -------------------------------------------------------------
// Live Streams in Firestore
// -------------------------------------------------------------

export function subscribeToLiveStreams(callback: (streams: LiveStreamSession[]) => void) {
  const streamsRef = collection(db, 'live_streams');
  return onSnapshot(streamsRef, (snapshot) => {
    const streams: LiveStreamSession[] = [];
    snapshot.forEach((docSnap) => {
      streams.push({ id: docSnap.id, ...docSnap.data() } as LiveStreamSession);
    });
    callback(streams);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, 'live_streams');
  });
}

export async function saveLiveStream(stream: LiveStreamSession): Promise<void> {
  try {
    await setDoc(doc(db, 'live_streams', stream.id), stream, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `live_streams/${stream.id}`);
  }
}

export async function endLiveStream(streamId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'live_streams', streamId), { isLive: false, endedAt: new Date().toISOString() });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `live_streams/${streamId}`);
  }
}

export interface LiveViewerPresence {
  userId: string;
  userName: string;
  userAvatar: string;
  userRole: string;
  joinedAt: string;
  lastSeen: string;
}

export async function joinLivePresence(streamId: string, user: UserAccount): Promise<void> {
  try {
    const presenceRef = doc(db, 'live_streams', streamId, 'viewers', user.id);
    const viewerData: LiveViewerPresence = {
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar || '',
      userRole: user.role,
      joinedAt: new Date().toISOString(),
      lastSeen: new Date().toISOString()
    };
    await setDoc(presenceRef, viewerData, { merge: true });
  } catch (err) {
    console.error('Error joining live presence:', err);
  }
}

export async function leaveLivePresence(streamId: string, userId: string): Promise<void> {
  try {
    const presenceRef = doc(db, 'live_streams', streamId, 'viewers', userId);
    await deleteDoc(presenceRef);
  } catch (err) {
    console.error('Error leaving live presence:', err);
  }
}

export function subscribeToLivePresence(streamId: string, callback: (viewers: LiveViewerPresence[]) => void) {
  const viewersRef = collection(db, 'live_streams', streamId, 'viewers');
  return onSnapshot(viewersRef, (snapshot) => {
    const list: LiveViewerPresence[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as LiveViewerPresence);
    });
    callback(list);
  }, (error) => {
    console.warn('Presence snapshot warning:', error);
  });
}

export function subscribeToLiveMessages(streamId: string, callback: (messages: LiveChatMessage[]) => void) {
  const messagesRef = collection(db, 'live_streams', streamId, 'chat_messages');
  return onSnapshot(messagesRef, (snapshot) => {
    const msgs: LiveChatMessage[] = [];
    snapshot.forEach((docSnap) => {
      msgs.push({ id: docSnap.id, ...docSnap.data() } as LiveChatMessage);
    });
    msgs.sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
    callback(msgs);
  }, (error) => {
    console.warn('Live chat snapshot warning:', error);
  });
}

export async function sendLiveMessage(streamId: string, message: Omit<LiveChatMessage, 'id'>): Promise<void> {
  try {
    const messagesRef = collection(db, 'live_streams', streamId, 'chat_messages');
    await addDoc(messagesRef, {
      ...message,
      createdAt: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error sending live message:', err);
  }
}

export function subscribeToLiveQuestions(streamId: string, callback: (questions: LiveQuestion[]) => void) {
  const questionsRef = collection(db, 'live_streams', streamId, 'live_questions');
  return onSnapshot(questionsRef, (snapshot) => {
    const list: LiveQuestion[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as LiveQuestion);
    });
    // Sort: 'respondendo' first, then 'aguardando', then 'respondida'
    list.sort((a, b) => {
      const order = { respondendo: 0, aguardando: 1, respondida: 2 };
      const orderDiff = (order[a.status] ?? 1) - (order[b.status] ?? 1);
      if (orderDiff !== 0) return orderDiff;
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
    callback(list);
  }, (error) => {
    console.warn('Live questions snapshot warning:', error);
  });
}

export async function sendLiveQuestion(streamId: string, question: Omit<LiveQuestion, 'id'>): Promise<string | undefined> {
  try {
    const questionsRef = collection(db, 'live_streams', streamId, 'live_questions');
    const docRef = await addDoc(questionsRef, {
      ...question,
      createdAt: new Date().toISOString()
    });
    return docRef.id;
  } catch (err) {
    console.error('Error submitting live question:', err);
    return undefined;
  }
}

export async function updateLiveQuestion(
  streamId: string, 
  questionId: string, 
  updates: Partial<LiveQuestion>
): Promise<void> {
  try {
    const qRef = doc(db, 'live_streams', streamId, 'live_questions', questionId);
    await updateDoc(qRef, updates);
  } catch (err) {
    console.error('Error updating live question:', err);
  }
}

export async function upvoteLiveQuestion(
  streamId: string,
  questionId: string,
  currentUpvotes: number = 0
): Promise<void> {
  try {
    const qRef = doc(db, 'live_streams', streamId, 'live_questions', questionId);
    await updateDoc(qRef, {
      upvotes: currentUpvotes + 1
    });
  } catch (err) {
    console.error('Error upvoting live question:', err);
  }
}

// -------------------------------------------------------------
// Site Configuration & Link Management in Firestore
// -------------------------------------------------------------

export function subscribeToSiteConfig(callback: (config: SiteConfig | null) => void) {
  const configDocRef = doc(db, 'site_config', 'main');
  return onSnapshot(configDocRef, (snap) => {
    if (snap.exists()) {
      callback(snap.data() as SiteConfig);
    } else {
      callback(null);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, 'site_config/main');
  });
}

export async function saveSiteConfigToDb(config: SiteConfig): Promise<void> {
  try {
    await setDoc(doc(db, 'site_config', 'main'), {
      ...config,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'site_config/main');
  }
}

// -------------------------------------------------------------
// Cartomante Candidates in Firestore (Trabalhe Conosco)
// -------------------------------------------------------------

export function subscribeToCartomanteCandidates(callback: (candidates: CartomanteCandidate[]) => void) {
  const candidatesRef = collection(db, 'cartomante_candidates');
  return onSnapshot(candidatesRef, (snapshot) => {
    const list: CartomanteCandidate[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as CartomanteCandidate);
    });
    callback(list);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, 'cartomante_candidates');
  });
}

export async function submitCartomanteCandidate(candidate: CartomanteCandidate): Promise<void> {
  try {
    await setDoc(doc(db, 'cartomante_candidates', candidate.id), candidate);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `cartomante_candidates/${candidate.id}`);
  }
}

export async function updateCandidateStatus(candidateId: string, status: 'aprovado' | 'rejeitado'): Promise<void> {
  try {
    await updateDoc(doc(db, 'cartomante_candidates', candidateId), {
      status,
      approvedAt: status === 'aprovado' ? new Date().toISOString() : null
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `cartomante_candidates/${candidateId}`);
  }
}

// -------------------------------------------------------------
// Direct Web Chat with Cartomantes (Chat Web no Site)
// -------------------------------------------------------------

export function subscribeToDirectChatMessages(
  chatId: string,
  callback: (messages: WebChatMessage[]) => void
) {
  const messagesRef = collection(db, 'direct_chats', chatId, 'messages');
  const q = query(messagesRef, orderBy('timestamp', 'asc'));

  return onSnapshot(q, (snapshot) => {
    const list: WebChatMessage[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as WebChatMessage);
    });
    callback(list);
  }, (error) => {
    // If permission or index error occurs, log and try client-side sorting
    console.warn('Direct chat snapshot warning:', error);
  });
}

export async function sendDirectChatMessage(
  chatId: string,
  message: WebChatMessage,
  sessionInfo?: Partial<WebChatSession>
): Promise<void> {
  try {
    // 1. Ensure chat session document exists/is updated
    const chatDocRef = doc(db, 'direct_chats', chatId);
    await setDoc(chatDocRef, {
      id: chatId,
      lastMessage: message.text,
      lastMessageAt: message.timestamp,
      ...(sessionInfo || {})
    }, { merge: true });

    // 2. Add message to subcollection
    const messageDocRef = doc(db, 'direct_chats', chatId, 'messages', message.id);
    await setDoc(messageDocRef, message);
  } catch (err) {
    console.warn('Error saving direct chat message to Firebase (using local state fallback):', err);
  }
}

export function subscribeToDirectChatSessions(
  callback: (sessions: WebChatSession[]) => void
) {
  const chatsRef = collection(db, 'direct_chats');
  return onSnapshot(chatsRef, (snapshot) => {
    const list: WebChatSession[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as WebChatSession);
    });
    // Sort descending by last message
    list.sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());
    callback(list);
  }, (error) => {
    console.warn('Direct chat sessions warning:', error);
  });
}

