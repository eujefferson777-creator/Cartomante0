// Web Audio API Spiritual Synthesizer & Radio Audio Engine
// Generates realistic atabaque drums, curimba beats, mystical flutes, bells, and 432Hz/528Hz healing frequencies

class SpiritualAudioEngine {
  private audioCtx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private volumeNode: GainNode | null = null;
  private masterVolume: number = 0.65;
  private currentRhythmStyle: string = 'barravento';
  private timerId: number | null = null;
  private step: number = 0;
  private droneOscillators: OscillatorNode[] = [];
  private droneGains: GainNode[] = [];
  private analyserNode: AnalyserNode | null = null;

  public getAudioContext(): AudioContext | null {
    return this.audioCtx;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
      this.volumeNode = this.audioCtx.createGain();
      this.volumeNode.gain.setValueAtTime(this.masterVolume, this.audioCtx.currentTime);

      this.analyserNode = this.audioCtx.createAnalyser();
      this.analyserNode.fftSize = 64;

      this.volumeNode.connect(this.analyserNode);
      this.analyserNode.connect(this.audioCtx.destination);
    }

    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setVolume(vol: number) {
    this.masterVolume = Math.max(0, Math.min(1, vol));
    if (this.volumeNode && this.audioCtx) {
      this.volumeNode.gain.setValueAtTime(this.masterVolume, this.audioCtx.currentTime);
    }
  }

  public startStation(rhythmStyle: string) {
    this.initContext();
    this.currentRhythmStyle = rhythmStyle;

    if (this.isPlaying) {
      this.stopDrones();
    } else {
      this.isPlaying = true;
    }

    this.startDrones(rhythmStyle);
    this.startSequencer();
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId !== null) {
      window.clearInterval(this.timerId);
      this.timerId = null;
    }
    this.stopDrones();
  }

  private stopDrones() {
    this.droneOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // ignore
      }
    });
    this.droneOscillators = [];
    this.droneGains = [];
  }

  private startDrones(style: string) {
    if (!this.audioCtx || !this.volumeNode) return;
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Harmonic chords based on tradition
    let freqs: number[] = [108, 216, 324]; // Default warm fifths

    if (style === 'mantra_432hz') {
      freqs = [108, 216, 432, 528]; // Sacred 432Hz & 528Hz Solfeggio
    } else if (style === 'barravento' || style === 'ijexa') {
      freqs = [110, 164.81, 220, 329.63]; // Root A minor / Dórico Afro-brasileiro
    } else if (style === 'cigano_flamenco') {
      freqs = [146.83, 220, 293.66, 370]; // Refrão Cigano D Phrygian / Menor Harmônico
    } else if (style === 'xamanico_tambor') {
      freqs = [73.42, 146.83, 220]; // D profundo da Terra
    }

    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = idx === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, now);

      // Low soothing drone volume
      const droneVol = idx === 0 ? 0.08 : 0.04 / (idx + 1);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(droneVol, now + 1.5);

      osc.connect(gain);
      gain.connect(this.volumeNode!);
      osc.start(now);

      this.droneOscillators.push(osc);
      this.droneGains.push(gain);
    });
  }

  // Rhythmic atabaque percussion generator
  private triggerDrum(type: 'rum' | 'rumpi' | 'le' | 'shaker' | 'flute' | 'bell', velocity: number = 0.8) {
    if (!this.audioCtx || !this.volumeNode) return;
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    if (type === 'rum') {
      // Deep bass atabaque (O Rum sagrado dos terreiros)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(95, now);
      osc.frequency.exponentialRampToValueAtTime(38, now + 0.28);

      gain.gain.setValueAtTime(0.7 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.volumeNode);
      osc.start(now);
      osc.stop(now + 0.36);
    } else if (type === 'rumpi') {
      // Mid resonant slap
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(90, now + 0.15);

      gain.gain.setValueAtTime(0.5 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc.connect(gain);
      gain.connect(this.volumeNode);
      osc.start(now);
      osc.stop(now + 0.19);
    } else if (type === 'le') {
      // Sharp high rim slap
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.08);

      gain.gain.setValueAtTime(0.3 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(this.volumeNode);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'shaker') {
      // Xequerê / Agogô / Maracá noise burst
      const bufferSize = ctx.sampleRate * 0.05;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.3;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(3500, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.2 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.volumeNode);
      whiteNoise.start(now);
      whiteNoise.stop(now + 0.06);
    } else if (type === 'bell') {
      // Sineta / Taça Tibetana / Campainha Cigana
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(528, now); // 528Hz healing tone

      gain.gain.setValueAtTime(0.25 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

      osc.connect(gain);
      gain.connect(this.volumeNode);
      osc.start(now);
      osc.stop(now + 1.9);
    } else if (type === 'flute') {
      // Melodic spiritual note
      const notes = [440, 523.25, 587.33, 659.25, 783.99]; // Pentatonic
      const note = notes[Math.floor(Math.random() * notes.length)];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(note, now);

      gain.gain.setValueAtTime(0.12 * velocity, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

      osc.connect(gain);
      gain.connect(this.volumeNode);
      osc.start(now);
      osc.stop(now + 0.85);
    }
  }

  private startSequencer() {
    if (this.timerId !== null) {
      window.clearInterval(this.timerId);
    }

    // Tempo based on rhythm
    let tempoMs = 180;
    if (this.currentRhythmStyle === 'barravento') tempoMs = 150;
    if (this.currentRhythmStyle === 'ijexa') tempoMs = 210;
    if (this.currentRhythmStyle === 'xamanico_tambor') tempoMs = 380;
    if (this.currentRhythmStyle === 'mantra_432hz') tempoMs = 750;
    if (this.currentRhythmStyle === 'cigano_flamenco') tempoMs = 175;

    this.step = 0;

    this.timerId = window.setInterval(() => {
      if (!this.isPlaying) return;
      const s = this.step % 16;

      if (this.currentRhythmStyle === 'barravento') {
        // Energetic Macumba/Umbanda beat
        if (s === 0 || s === 6 || s === 10) this.triggerDrum('rum', 0.9);
        if (s === 3 || s === 8 || s === 12) this.triggerDrum('rumpi', 0.7);
        if (s % 2 === 1) this.triggerDrum('shaker', 0.35);
        if (s === 2 || s === 14) this.triggerDrum('le', 0.5);
        if (s === 0 && Math.random() > 0.6) this.triggerDrum('bell', 0.6);
      } else if (this.currentRhythmStyle === 'ijexa') {
        // Swing suave dos Orixás d'água (Oxum, Iemanjá, Logun Edé)
        if (s === 0 || s === 4 || s === 10) this.triggerDrum('rum', 0.8);
        if (s === 2 || s === 8 || s === 14) this.triggerDrum('rumpi', 0.6);
        if (s % 2 === 0) this.triggerDrum('shaker', 0.4);
        if (s === 0) this.triggerDrum('bell', 0.4);
        if (s === 8 && Math.random() > 0.5) this.triggerDrum('flute', 0.5);
      } else if (this.currentRhythmStyle === 'cigano_flamenco') {
        // Pandeiro cigano, palmas e violinos
        if (s === 0 || s === 6 || s === 12) this.triggerDrum('rum', 0.7);
        if (s === 3 || s === 9 || s === 15) this.triggerDrum('rumpi', 0.65);
        if (s % 2 === 0) this.triggerDrum('shaker', 0.4);
        if (s === 4 || s === 10) this.triggerDrum('bell', 0.5);
        if (s === 0 && Math.random() > 0.4) this.triggerDrum('flute', 0.6);
      } else if (this.currentRhythmStyle === 'xamanico_tambor') {
        // Pulsação profunda do coração (Tum... tum...)
        if (s % 4 === 0) this.triggerDrum('rum', 1.0);
        if (s % 4 === 1) this.triggerDrum('rum', 0.5);
        if (s % 2 === 0) this.triggerDrum('shaker', 0.25);
        if (s === 0 && Math.random() > 0.5) this.triggerDrum('flute', 0.5);
      } else if (this.currentRhythmStyle === 'mantra_432hz') {
        // Flautas cósmicas e taças tibetanas
        if (s % 4 === 0) this.triggerDrum('bell', 0.8);
        if (s % 2 === 0 && Math.random() > 0.4) this.triggerDrum('flute', 0.6);
      }

      this.step++;
    }, tempoMs);
  }
}

export const spiritualAudioEngine = new SpiritualAudioEngine();
