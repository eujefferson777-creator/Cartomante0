import { RadioStation } from '../types';

export const RADIO_STATIONS: RadioStation[] = [
  {
    id: 'macumba-umbanda',
    name: 'Rádio Umbanda GV & Pontos de Axé',
    tagline: 'Toques de Atabaque, Curimba & Pontos Cantados 24h Ao Vivo',
    category: 'umbanda',
    badgeColor: 'from-amber-600 to-red-600',
    coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80',
    description: 'Transmissão ao vivo de Umbanda e Axé com pontos cantados, chamadas de falanges de Ogum, Oxóssi, Iemanjá, Pretos Velhos e Guardiões.',
    frequency: '108.0 FM • Axé do Terreiro',
    streamUrl: 'https://stream.zeno.fm/3aqrsixqaksvv',
    backupStreamUrl: 'https://servidor27-2.brlogic.com:8016/live',
    rhythmStyle: 'barravento',
    tracks: [
      {
        id: 'ponto-ogum',
        title: 'Ponto de Ogum Beira-Mar (Cavaleiro da Força)',
        artistOrEntity: 'Curimba Templo Estrela D’Alva',
        duration: 'Ao Vivo',
        category: 'umbanda',
        pontoLyrics: 'Ogum olha sua bandeira, é branca, verde e encarnada! Ogum nos campos de batalha, ele venceu a guerra e não perdeu soldado!'
      },
      {
        id: 'ponto-oxum',
        title: 'Canto das Águas Doces da Mamãe Oxum',
        artistOrEntity: 'Vozes da Cachoeira Dourada',
        duration: 'Ao Vivo',
        category: 'umbanda',
        pontoLyrics: 'Eu vi a mamãe Oxum na cachoeira, sentada na beira do rio... Colhendo lírio, lírio ê, colhendo lírio, lírio ah!'
      },
      {
        id: 'ponto-padilha',
        title: 'Ponto de Maria Padilha das Sete Encruzilhadas',
        artistOrEntity: 'Guardiões da Madrugada',
        duration: 'Ao Vivo',
        category: 'umbanda',
        pontoLyrics: 'Deu meia-noite, a lua se escondeu! Lá na encruzilhada, bela gargalhada Padilha deu! É Pomba Gira, rainha da noite!'
      },
      {
        id: 'ponto-preto-velho',
        title: 'Cachimbo de Pai Joaquim & Mironga de Vovó Maria',
        artistOrEntity: 'Terreiro Luz e Caridade',
        duration: 'Ao Vivo',
        category: 'umbanda',
        pontoLyrics: 'Preto Velho senta no toco, faz o sinal da cruz, pede a proteção pra Jesus... É Pai Joaquim de Angola que chegou no gongá!'
      },
      {
        id: 'ponto-caboclo',
        title: 'Oxóssi na Mata Virgem & Caboclo Sete Flechas',
        artistOrEntity: 'Aldeia dos Ventos',
        duration: 'Ao Vivo',
        category: 'umbanda',
        pontoLyrics: 'Okê Arô Oxóssi! No tronco do juremá, ecoa o tambor que chama a falange sagrada do caçador!'
      }
    ]
  },
  {
    id: 'boa-nova-espiritual',
    name: 'Rede Boa Nova de Rádio',
    tagline: 'Espiritualidade, Mensagens de Luz, Preces & Paz 24h',
    category: 'mantras',
    badgeColor: 'from-blue-600 to-cyan-800',
    coverImage: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&auto=format&fit=crop&q=80',
    description: 'A maior rede de rádio espiritualista do Brasil no ar 24 horas. Preces, mensagens de esperança, vibrações de paz, harmonização e consolo.',
    frequency: '1450 AM • Luz Cósmica',
    streamUrl: 'https://servidor27-2.brlogic.com:8016/live',
    backupStreamUrl: 'https://paineldj5.com.br:2100/stream?type=.mp3',
    rhythmStyle: 'mantra_432hz',
    tracks: [
      {
        id: 'prece-luz',
        title: 'Prece de Cáritas & Vibrações de Paz Mundial',
        artistOrEntity: 'Mensageiros da Luz',
        duration: 'Ao Vivo',
        category: 'mantras',
        pontoLyrics: 'Deus, nosso Pai, que sois todo poder e bondade, dai força àquele que passa pela provação, dai luz àquele que procura a verdade!'
      },
      {
        id: 'mensagens-esperanca',
        title: 'Consolação e Cura para a Alma',
        artistOrEntity: 'Rede Boa Nova Oficial',
        duration: 'Ao Vivo',
        category: 'mantras',
        pontoLyrics: 'Respire fundo, sinta a presença de seus anjos da guarda e mentores de luz. Nada acontece por acaso, a vitória da fé é certa.'
      }
    ]
  },
  {
    id: 'candomble-zambi',
    name: 'Rádio Luz de Zambi & Orixás',
    tagline: 'Toques de Ijexá, Ketu, Angola e Cânticos Ancestrais',
    category: 'candomble',
    badgeColor: 'from-blue-700 to-indigo-950',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'Ancestralidade de África e força viva dos Orixás. Toques cerimoniais de Rum, Rumpi e Lé com o pulsar sagrado do Ijexá.',
    frequency: '104.3 FM • Raiz Sagrada',
    streamUrl: 'https://stream.zeno.fm/z6w4zbvs4a0uv',
    backupStreamUrl: 'https://stream.zeno.fm/3aqrsixqaksvv',
    rhythmStyle: 'ijexa',
    tracks: [
      {
        id: 'canto-iemanja',
        title: 'Odoyá Iemanjá - Serenata das Ondas do Mar',
        artistOrEntity: 'Iyalorixá Yá Nitinha & Ogãs',
        duration: 'Ao Vivo',
        category: 'candomble',
        pontoLyrics: 'Iemanjá, Rainha do Mar, tuas águas lavam a tristeza e perfumam a terra com alfazema e conchas sagradas.'
      },
      {
        id: 'canto-xango',
        title: 'Alujá de Xangô & Justiça do Trovão',
        artistOrEntity: 'Ilê Axé Opô Afonjá',
        duration: 'Ao Vivo',
        category: 'candomble',
        pontoLyrics: 'Kaô Kabecilê! A pedra rolou na pedreira, o machado brilhou no trovão! Quem deve paga, quem merece ganha a coroa de ouro!'
      },
      {
        id: 'canto-iansa',
        title: 'Eparrey Iansã - Vento da Transformação',
        artistOrEntity: 'Tambores do Ilê',
        duration: 'Ao Vivo',
        category: 'candomble',
        pontoLyrics: 'Olha o raio de Iansã clareando a escuridão! A guerreira de Oyá sopra os ventos que levam embora toda maldade!'
      }
    ]
  },
  {
    id: 'sons-de-cura-natureza',
    name: 'Rádio Sons de Cura & Natureza 432Hz',
    tagline: 'Frequências Solfeggio 528Hz, Sons das Matas & Águas',
    category: 'mantras',
    badgeColor: 'from-emerald-700 to-teal-900',
    coverImage: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=600&auto=format&fit=crop&q=80',
    description: 'Sons sagrados da natureza, cachoeiras cristalinas, pássaros da floresta e instrumentos de frequência 432Hz e 528Hz para conexão cósmica.',
    frequency: '432 Hz • Som do Universo',
    streamUrl: 'https://stream.zeno.fm/3ac97ysh6f0uv.aac',
    backupStreamUrl: 'https://stream.zeno.fm/689zc32y4x8uv',
    rhythmStyle: 'mantra_432hz',
    tracks: [
      {
        id: 'flauta-floresta',
        title: 'Canto das Águas Sagradas & Pássaros da Manhã',
        artistOrEntity: 'Frequência de Amor 528Hz',
        duration: 'Ao Vivo',
        category: 'mantras',
        pontoLyrics: 'Feche os olhos e sinta a energia do elemento água purificando pensamentos e abrindo os canais intuitivos do seu coração.'
      },
      {
        id: 'mantra-protecao',
        title: 'Tigelas Tibetanas & Harmonização dos Chakras',
        artistOrEntity: 'Som Sagrado dos Templos',
        duration: 'Ao Vivo',
        category: 'mantras',
        pontoLyrics: 'Om... Paz no corpo físico, paz na mente, paz no espírito. A luz divina dissipa todas as sombras.'
      }
    ]
  },
  {
    id: 'chuva-purificacao',
    name: 'Rádio Chuva Sagrada & Descarrego Mental',
    tagline: 'Som Relaxante de Chuva, Trovões Suaves & Noite Mística',
    category: 'xamanismo',
    badgeColor: 'from-purple-800 to-slate-900',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
    description: 'Gotas de chuva purificadoras para descarregar o cansaço do dia, acalmar a ansiedade antes da consulta de Tarot e induzir clareza mental.',
    frequency: '92.5 FM • Serenidade',
    streamUrl: 'https://stream.zeno.fm/689zc32y4x8uv',
    backupStreamUrl: 'https://stream.zeno.fm/3ac97ysh6f0uv.aac',
    rhythmStyle: 'xamanico_tambor',
    tracks: [
      {
        id: 'chuva-noite',
        title: 'Chuva Suave na Cabana Mística',
        artistOrEntity: 'Sons da Terra Sagrada',
        duration: 'Ao Vivo',
        category: 'xamanismo',
        pontoLyrics: 'A chuva lava o passado, limpa o ar e prepara o terreno para as sementes do novo destino florescerem.'
      }
    ]
  },
  {
    id: 'web-fraternidade',
    name: 'Web Rádio Fraternidade',
    tagline: 'Luz, Conforto Espiritual & Mensagens Consoladoras 24h',
    category: 'mantras',
    badgeColor: 'from-indigo-700 to-purple-900',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'Emissora de rádio online com programas de consolo, orações diárias, mensagens de luz e temas de espiritualidade maior.',
    frequency: '96.3 FM • Fraternidade',
    streamUrl: 'https://paineldj5.com.br:2100/stream?type=.mp3',
    backupStreamUrl: 'https://servidor27-2.brlogic.com:8016/live',
    rhythmStyle: 'mantra_432hz',
    tracks: [
      {
        id: 'mensagem-consolo',
        title: 'Palavras de Amor e Esperança',
        artistOrEntity: 'Web Rádio Fraternidade Oficial',
        duration: 'Ao Vivo',
        category: 'mantras',
        pontoLyrics: 'Onde houver desespero, que eu leve a esperança. Onde houver trevas, que eu leve a luz.'
      }
    ]
  }
];
