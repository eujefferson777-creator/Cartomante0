import { Testimonial } from '../types';

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    clientName: 'Fernanda M. Silveira',
    city: 'São Paulo - SP',
    stars: 5,
    date: 'Ontem às 23:45',
    comment: 'Fiz a chamada de vídeo de madrugada com a Mãe Yara porque estava desesperada com meu noivado. Ela abriu o baralho e falou coisas que só eu sabia! No outro dia tudo que ela disse se confirmou. Me trouxe muita paz!',
    serviceUsed: 'Consulta Express de Vídeo (15 min)',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    whatsappScreenshotText: 'Mãe Yara, passando para agradecer de coração! A conversa com ele aconteceu exatamente como você previu no vídeo de ontem. Muito obrigada pelo carinho!'
  },
  {
    id: '2',
    clientName: 'Rodrigo B. Santos',
    city: 'Curitiba - PR',
    stars: 5,
    date: 'Há 2 dias',
    comment: 'Entrei no grupo de WhatsApp deles por curiosidade e acabei marcando a Mesa Real por vídeo. O atendimento é 100% sigiloso e profissional. O valor cobrado é muito justo pela precisão das respostas.',
    serviceUsed: 'Mesa Real 360° em Vídeo',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    whatsappScreenshotText: 'Bom dia! O processo que estava travado há 2 anos no tribunal finalmente teve despacho favorável hoje, como você cravou na tiragem das cartas!'
  },
  {
    id: '3',
    clientName: 'Camila Alencar',
    city: 'Belo Horizonte - MG',
    stars: 5,
    date: 'Há 3 dias',
    comment: 'Adoro o grupo do WhatsApp onde elas mandam a carta do dia todo dia de manhã! E quando precisei de uma consulta de emergência no plantão da 1h da manhã fui atendida na hora por chamada de vídeo. Nota 1000!',
    serviceUsed: 'Plantão 24h da Madrugada',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    whatsappScreenshotText: 'Dona Clara, que Deus e Iemanjá abençoem suas mãos. Seu banho de ervas e a leitura me tiraram daquela angústia profunda.'
  }
];
