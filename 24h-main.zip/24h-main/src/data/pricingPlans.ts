import { PricingPlan } from '../types';

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'pergunta-unica',
    title: '1 Pergunta Direta',
    badge: 'Mais Rápida',
    durationMinutes: 0,
    price: 20.00,
    originalPrice: 35.00,
    directQuestions: 1,
    description: 'Resposta rápida, objetiva e clara para aquela dúvida pontual que não sai da sua cabeça.',
    features: [
      '1 Pergunta direta com revelação imediata das cartas',
      'Tiragem focada exatamente na sua dúvida',
      'Áudio explicativo ou chamada em vídeo no WhatsApp',
      'Resposta sem corte de tempo • Foco total em você',
      'Atendimento 24 horas por dia'
    ],
    isPopular: false,
    format: 'audio_whatsapp',
    ctaText: 'Jogar 1 Pergunta (R$ 20,00)'
  },
  {
    id: 'tres-perguntas',
    title: '3 Perguntas Completas',
    badge: 'Mais Escolhida',
    durationMinutes: 0,
    price: 50.00,
    originalPrice: 80.00,
    directQuestions: 3,
    description: 'Três perguntas profundas para analisar amor, finanças ou decisões com conselho dos guardiões e mestres.',
    features: [
      '3 Perguntas profundas à sua escolha livre',
      'Tiragem com Baralho Cigano ou Tarot de Marselha',
      'Conselho e direcionamento espiritual dos mentores de luz',
      'Chamada de vídeo sem corte de tempo ou no WhatsApp',
      'Entrada direta no grupo privativo da Cartomante'
    ],
    isPopular: true,
    format: 'video',
    ctaText: 'Jogar 3 Perguntas (R$ 50,00)'
  }
];

export const WHATSAPP_GROUP_BENEFITS = [
  {
    title: 'Tiragem da Carta do Dia Gratuita',
    description: 'Todas as manhãs, a Cartomante envia a energia astral e o conselho das cartas direto no grupo.'
  },
  {
    title: 'Sorteios Semanais de Consultas em Vídeo',
    description: 'Membros do grupo concorrem a consultas completas gratuitas toda semana.'
  },
  {
    title: 'Rituais Lunares e Banhos de Ervas',
    description: 'Receba receitas sagradas de prosperidade, atração amorosa e limpeza espiritual conforme a fase da lua.'
  },
  {
    title: 'Fila Preferencial de Atendimento 24h',
    description: 'Quem faz parte do grupo tem atendimento prioritário direto com as mestres de plantão.'
  }
];
