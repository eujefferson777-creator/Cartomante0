import { CartomanteProfile } from '../types';

export const CARTOMANTES_PROFILES: CartomanteProfile[] = [
  {
    id: 'mestra-yara',
    name: 'Mãe Yara do Oriente',
    title: 'Mestra em Baralho Cigano & União de Almas',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    rating: 4.98,
    consultationsCount: 4120,
    experienceYears: 27,
    isOnline: true,
    statusText: 'Disponível Agora para Chamada de Vídeo',
    specialties: ['Amor e Reconciliação', 'Baralho Cigano Tradicional', 'Afastamento de Rivais', 'Destrancamento de Caminhos'],
    deckTypes: ['Baralho Cigano (Lenormand)', 'Tarot das Bruxas'],
    bio: 'Descendente de linhagem cigana calom, utilizo a força das 36 cartas sagradas e a clarividência herdada dos meus ancestrais para trazer verdades claras e curar feridas do coração.',
    voiceGreetingText: 'Salve Santa Sara Kali! Seja muito bem-vindo(a). Se o seu coração está angustiado, as cartas ciganas vão te mostrar a luz agora mesmo.',
    whatsappMessage: 'Olá Mãe Yara! Gostaria de agendar uma consulta rápida por chamada de vídeo com você agora.'
  },
  {
    id: 'dona-clara',
    name: 'Dona Clara de Iemanjá',
    title: 'Sacerdotisa de Tarot dos Orixás & Prosperidade',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    rating: 4.95,
    consultationsCount: 3250,
    experienceYears: 21,
    isOnline: true,
    statusText: 'Online no Plantão 24h',
    specialties: ['Finanças e Emprego', 'Tarot dos Orixás', 'Limpeza Energética', 'Harmonia Familiar'],
    deckTypes: ['Tarot dos Orixás', 'Tarot de Marselha'],
    bio: 'Canalizo a sabedoria das águas sagradas e a firmeza dos Orixás para abrir portas profissionais, quebrar demandas espirituais e restabelecer a paz no seu lar.',
    voiceGreetingText: 'Odoyá! Meu filho(a), não se desespere. O mar limpa tudo e traz a fartura que você merece. Venha ouvir os conselhos das cartas.',
    whatsappMessage: 'Olá Dona Clara! Quero uma consulta sobre finanças e caminhos abertos no atendimento 24h.'
  },
  {
    id: 'mestra-serena',
    name: 'Mestra Serena d’Arc',
    title: 'Taróloga Intuitiva & Terapeuta Holística',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
    rating: 4.96,
    consultationsCount: 2890,
    experienceYears: 16,
    isOnline: true,
    statusText: 'Pronta para Consulta Express de Vídeo',
    specialties: ['Perguntas Rápidas Sim/Não', 'Tarot de Marselha', 'Autoconhecimento', 'Tomada de Decisões'],
    deckTypes: ['Tarot de Marselha', 'Tarot Cósmico', 'Oráculo dos Anjos'],
    bio: 'Abordagem direta, acolhedora e precisa. Ideal para consultas rápidas em vídeo quando você precisa saber exatamente o que fazer diante de uma encruzilhada.',
    voiceGreetingText: 'Paz e Luz! Estou aqui ao vivo para tirar suas dúvidas sem rodeios, com todo carinho e verdade.',
    whatsappMessage: 'Olá Mestra Serena! Gostaria de fazer a consulta Express de 15 minutos em chamada de vídeo.'
  }
];
