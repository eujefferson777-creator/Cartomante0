import { CommunityPost, LiveStreamSession } from '../types';

export const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: 'post-1',
    authorId: 'cartomante-1',
    authorName: 'Mãe Yara do Oriente',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    authorRole: 'cartomante',
    authorTitle: 'Cigana & Mestra do Baralho Lenormand',
    authorBio: '24 anos guiando corações aflitos com a energia do Povo Cigano e banhos de atração.',
    content: '🌙 ✨ Mensagem do Dia para os Filhos de Fé:\nHoje a carta do Sol e as Alianças se uniram em nossa mesa! A energia astral indica reconciliações profundas e destravamento de causas amorosas que pareciam perdidas.\n\nQuem sentir o coração pesado, deixe seu nome nos comentários para eu firmar uma vela branca no altar cigano hoje à noite! Axé e muito amor a todos!',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80',
    likes: 42,
    likedBy: ['admin-master', 'client-1', 'client-2'],
    topic: 'previsao',
    tarotCardAttachment: {
      name: 'O Sol - Carta 31',
      icon: '☀️',
      summary: 'Clareza, vitória, cura e iluminação nos relacionamentos e planos futuros.'
    },
    taggedUsers: [
      { id: 'cartomante-2', name: 'Mestra Serena d’Arc', role: 'cartomante' },
      { id: 'client-1', name: 'Beatriz Vasconcelos', role: 'client' }
    ],
    createdAt: 'Há 25 minutos',
    comments: [
      {
        id: 'c-1',
        postId: 'post-1',
        authorId: 'client-1',
        authorName: 'Beatriz Vasconcelos',
        authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
        authorRole: 'client',
        content: 'Mãe Yara querida! Por favor firme meu nome (Beatriz) e do Carlos. Sua última tiragem de 3 perguntas bateu certinho no dia seguinte! Gratidão eterna 🙏✨',
        createdAt: 'Há 18 minutos',
        likes: 7
      },
      {
        id: 'c-2',
        postId: 'post-1',
        authorId: 'cartomante-2',
        authorName: 'Mestra Serena d’Arc',
        authorAvatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&auto=format&fit=crop&q=80',
        authorRole: 'cartomante',
        content: 'Lindo aviso, irmã de fé! A egrégora do amor está fortíssima no nosso grupo hoje.',
        createdAt: 'Há 10 minutos',
        likes: 5
      }
    ]
  },
  {
    id: 'post-2',
    authorId: 'client-2',
    authorName: 'Carlos Eduardo Silva',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    authorRole: 'client',
    authorBio: 'Consulente assíduo. Apaixonado por autoconhecimento e espiritualidade.',
    content: 'Passando aqui na comunidade para dar meu depoimento sincero! Estava com a empresa quase fechando no mês passado e fiz a consulta de 15 minutos em vídeo com a Cigana Samara. O conselho das cartas e o direcionamento que ela me deu foram cirúrgicos. Consegui assinar o contrato na mesma semana! Recomendo a todos entrarem no grupo VIP! 🚀💰',
    likes: 29,
    likedBy: ['cartomante-3', 'client-3'],
    topic: 'relato',
    taggedUsers: [
      { id: 'cartomante-3', name: 'Cigana Samara da Mata', role: 'cartomante' }
    ],
    createdAt: 'Há 2 horas',
    comments: [
      {
        id: 'c-3',
        postId: 'post-2',
        authorId: 'cartomante-3',
        authorName: 'Cigana Samara da Mata',
        authorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
        authorRole: 'cartomante',
        content: 'Que alegria imensa ler suas palavras, Carlos! Quando a fé se alinha com a ação, os caminhos se abrem sem demora. Parabéns pelo sucesso! 🌹✨',
        createdAt: 'Há 1 hora',
        likes: 9
      },
      {
        id: 'c-4',
        postId: 'post-2',
        authorId: 'client-4',
        authorName: 'Juliana Mendes',
        authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
        authorRole: 'client',
        content: 'Que lindo relato! Também vou agendar uma pergunta com a Samara hoje.',
        createdAt: 'Há 45 minutos',
        likes: 3
      }
    ]
  },
  {
    id: 'post-3',
    authorId: 'cartomante-2',
    authorName: 'Mestra Serena d’Arc',
    authorAvatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=400&auto=format&fit=crop&q=80',
    authorRole: 'cartomante',
    authorTitle: 'Taróloga Clássica & Linha dos Arcanos',
    authorBio: 'Especialista em tiragens complexas de amor, triângulos amorosos e libertação espiritual.',
    content: '🌿 Banho de Ervas para Afastar Inveja e Abrir Caminhos Amorosos:\n\n1. 7 folhas de louro (atração e vitória)\n2. 1 punhado de alecrim (alegria e magnetismo)\n3. 3 paus de canela (paixão e prosperidade)\n4. Pétalas de 1 rosa vermelha ou branca\n\nFerva a água, adicione as ervas, abafe por 15 minutos e jogue do pescoço para baixo após o banho higiênico, mentalizando o seu maior desejo. Quem fizer me conta aqui nos comentários! 🌹',
    imageUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&auto=format&fit=crop&q=80',
    likes: 67,
    likedBy: ['admin-master', 'client-1', 'client-2', 'client-3', 'client-4'],
    topic: 'amor',
    createdAt: 'Há 5 horas',
    comments: [
      {
        id: 'c-5',
        postId: 'post-3',
        authorId: 'client-3',
        authorName: 'Fernanda Rocha',
        authorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
        authorRole: 'client',
        content: 'Fiz na lua cheia passada e a energia em casa mudou completamente! Serena é maravilhosa ❤️',
        createdAt: 'Há 3 horas',
        likes: 11
      }
    ]
  }
];

export const INITIAL_LIVE_STREAMS: LiveStreamSession[] = [
  {
    id: 'live-stream-1',
    cartomanteId: 'cartomante-1',
    cartomanteName: 'Mãe Yara do Oriente',
    cartomanteTitle: 'Cigana & Mestra do Baralho Lenormand',
    cartomanteAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    title: '🔴 AO VIVO: Tiragem Aberta de Amor & Destravamento de Relacionamentos 24h',
    topic: 'Tiragem de Cartas Coletivas & Abertura no WhatsApp',
    isLive: true,
    viewersCount: 48,
    whatsappGroupLink: 'https://chat.whatsapp.com/invite-cartomante24h',
    whatsappPhone: '5511999998888',
    startedAt: 'Ao vivo há 12 min',
    featuredCard: 'Os Enamorados + A Aliança Cigana',
    bannerUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80'
  }
];
