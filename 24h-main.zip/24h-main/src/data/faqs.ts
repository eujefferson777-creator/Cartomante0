import { FAQItem } from '../types';

export const FAQS_DATA: FAQItem[] = [
  {
    id: '1',
    question: 'Como funciona a consulta rápida por chamada de vídeo?',
    answer: 'Você escolhe o plano ou a Cartomante de plantão, clica em "Iniciar Vídeo" ou chama no WhatsApp. A chamada acontece em uma sala de vídeo privativa e segura (ou diretamente pelo WhatsApp Vídeo se preferir). Durante a chamada de 15, 30 ou 50 minutos, a cartomante embaralha e mostra as cartas na câmera ao vivo, tirando todas as suas dúvidas.',
    category: 'video'
  },
  {
    id: '2',
    question: 'Como funciona o Grupo de WhatsApp do Cartomante 24h?',
    answer: 'Nosso grupo de WhatsApp é uma comunidade acolhedora onde postamos diariamente as previsões da Carta do Dia, horóscopo das cartas ciganas, orações, receitas de banhos energéticos e sorteios semanais de consultas gratuitas. Além disso, membros do grupo têm prioridade e desconto exclusivo para atendimento no privado.',
    category: 'whatsapp'
  },
  {
    id: '3',
    question: 'Quais são os valores cobrados pelas consultas?',
    answer: 'Nossos valores são totalmente transparentes e acessíveis: Consulta Express de 15 minutos em vídeo (até 3 perguntas) por apenas R$ 39,90; Consulta Completa Amor & Destino de 30 minutos por R$ 79,90; e a profunda Mesa Real Cigana de 50 minutos por R$ 139,90. Temos também plantão 24h da madrugada por R$ 59,90.',
    category: 'valores'
  },
  {
    id: '4',
    question: 'Como é feito o pagamento e a confirmação?',
    answer: 'O pagamento é feito via PIX com aprovação instantânea (QR Code e chave Copia e Cola gerados na hora), ou cartão de crédito em até 12x. Assim que gerado o PIX ou enviado o comprovante no WhatsApp, a sua consulta é iniciada imediatamente.',
    category: 'valores'
  },
  {
    id: '5',
    question: 'O atendimento é 100% sigiloso e confidencial?',
    answer: 'Sim, absoluto sigilo ético e espiritual. Nenhuma informação pessoal, imagem ou assunto tratado durante a consulta por chamada de vídeo ou conversa de WhatsApp é gravada ou compartilhada com terceiros. Seu sigilo é inviolável.',
    category: 'sigilo'
  },
  {
    id: '6',
    question: 'O atendimento é realmente 24 horas todos os dias?',
    answer: 'Sim! Temos uma equipe em escala contínua com cartomantes e tarólogas experientes de plantão durante o dia, a noite e especialmente na madrugada e finais de semana.',
    category: 'atendimento'
  }
];
