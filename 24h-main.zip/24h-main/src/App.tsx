import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { PricingCalculatorSection } from './components/PricingCalculatorSection';
import { WhatsAppGroupSection } from './components/WhatsAppGroupSection';
import { CartomantesOnDuty } from './components/CartomantesOnDuty';
import { RadioMacumbaSection } from './components/RadioMacumbaSection';
import { RadioMacumbaPlayer } from './components/RadioMacumbaPlayer';
import { MysticalGamesSection } from './components/MysticalGamesSection';
import { FreeTarotDraw } from './components/FreeTarotDraw';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { PixPaymentModal } from './components/PixPaymentModal';
import { AdminConfigModal } from './components/AdminConfigModal';
import { AdminLinkManagerModal } from './components/AdminLinkManagerModal';
import { AdminPage } from './components/AdminPage';
import { AuthModal } from './components/AuthModal';
import { ClientProfileModal } from './components/ClientProfileModal';
import { WorkWithUsModal } from './components/WorkWithUsModal';
import { FloatingWhatsAppButton } from './components/FloatingWhatsAppButton';
import { CommunityPage } from './components/CommunityPage';
import { LiveStreamModal } from './components/LiveStreamModal';
import { SelectCartomanteGroupModal } from './components/SelectCartomanteGroupModal';
import { SiteConfig, PricingPlan, CartomanteProfile, UserAccount, CartomanteCandidate, LiveStreamSession } from './types';
import { CARTOMANTES_PROFILES } from './data/cartomantes';
import { PRICING_PLANS } from './data/pricingPlans';
import { INITIAL_LIVE_STREAMS } from './data/communityData';
import cuteMysticBg from './assets/images/mystic_cute_bg_1787015849730.jpg';
import catLogo from './assets/images/black_cat_logo_1787015840608.jpg';
import { 
  subscribeToAuthChanges, 
  logoutUser, 
  subscribeToSiteConfig, 
  saveSiteConfigToDb 
} from './lib/firebase';

const DEFAULT_CONFIG: SiteConfig = {
  siteName: 'Cartomante 24h',
  phoneWhatsApp: '5511999998888',
  groupWhatsAppLink: 'https://chat.whatsapp.com/invite-cartomante24h',
  pixKey: 'contato@cartomante24h.com.br',
  pixReceiverName: 'Cartomante 24h Atendimentos Espirituais',
  pixCity: 'São Paulo - SP',
  emergencyNightShiftActive: true,
  onlineNotice: '🟢 3 Cartomantes de Plantão Online Agora',
  facebookLink: 'https://facebook.com/cartomante24h.oficial',
  facebookPageName: 'Cartomante 24h Oficial',
  price1Question: 20.0,
  price3Questions: 50.0,
  developerWhatsApp: '5511999998888',
  monthlyFeeAmount: 50.0,
  monthlyFeePixKey: 'financeiro.provedor@cartomante24h.com'
};

export default function App() {
  // Current view: 'home' | 'community' | 'admin'
  const [currentView, setCurrentView] = useState<'home' | 'community' | 'admin'>('home');

  // Load config from database with localStorage fallback
  const [config, setConfig] = useState<SiteConfig>(() => {
    try {
      const saved = localStorage.getItem('cartomante24h_config');
      return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });

  // Current logged in user (Client or Admin or Cartomante)
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = localStorage.getItem('cartomante24h_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Real-time Auth sync with Firebase
  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges((user) => {
      if (user) {
        setCurrentUser(user);
        localStorage.setItem('cartomante24h_current_user', JSON.stringify(user));
      }
    });
    return () => unsubscribe();
  }, []);

  // Real-time Site Config sync with Firebase
  useEffect(() => {
    const unsubscribe = subscribeToSiteConfig((dbConfig) => {
      if (dbConfig) {
        setConfig((prev) => ({ ...prev, ...dbConfig }));
        localStorage.setItem('cartomante24h_config', JSON.stringify({ ...DEFAULT_CONFIG, ...dbConfig }));
      }
    });
    return () => unsubscribe();
  }, []);

  // Modals state
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isLinkManagerOpen, setIsLinkManagerOpen] = useState(false);
  const [targetLinkId, setTargetLinkId] = useState<string | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isWorkWithUsOpen, setIsWorkWithUsOpen] = useState(false);
  const [isRadioOpen, setIsRadioOpen] = useState(false);
  const [isPixModalOpen, setIsPixModalOpen] = useState(false);
  const [activeLiveStream, setActiveLiveStream] = useState<LiveStreamSession | null>(null);
  const [isSelectGroupModalOpen, setIsSelectGroupModalOpen] = useState(false);
  const [selectedCartomanteForGroup, setSelectedCartomanteForGroup] = useState<CartomanteProfile | null>(null);
  const [selectedQuestionsCountForGroup, setSelectedQuestionsCountForGroup] = useState<1 | 3>(1);

  // Selected item for payment / live
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(PRICING_PLANS[0]);
  const [selectedCartomante, setSelectedCartomante] = useState<CartomanteProfile>(CARTOMANTES_PROFILES[0]);
  const [customOrderTitle, setCustomOrderTitle] = useState<string>('1 Pergunta Direta');
  const [customOrderPrice, setCustomOrderPrice] = useState<number>(20.00);

  const handleSaveConfig = async (newConfig: SiteConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem('cartomante24h_config', JSON.stringify(newConfig));
      await saveSiteConfigToDb(newConfig);
    } catch (e) {
      console.error('Config save error:', e);
    }
  };

  const handleOpenLinkManager = (linkId?: string) => {
    setTargetLinkId(linkId || null);
    setIsLinkManagerOpen(true);
  };

  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentView('admin');
    } else {
      setIsProfileOpen(true);
    }
  };

  const handleUpdateCurrentUser = (updatedUser: UserAccount) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('cartomante24h_current_user', JSON.stringify(updatedUser));
  };

  const handleLogout = async () => {
    localStorage.removeItem('cartomante24h_current_user');
    setCurrentUser(null);
    setCurrentView('home');
    try {
      await logoutUser();
    } catch (e) {
      console.error(e);
    }
  };

  const handleOpenWhatsAppGroup = (cartomante?: CartomanteProfile | null, questionsCount?: 1 | 3) => {
    if (cartomante) {
      setSelectedCartomanteForGroup(cartomante);
    }
    if (questionsCount) {
      setSelectedQuestionsCountForGroup(questionsCount);
    }
    setIsSelectGroupModalOpen(true);
  };

  const handleOpenWhatsAppDirect = (topicOrTitle: string, price?: number) => {
    const priceText = price ? ` (Valor: R$ ${price.toFixed(2).replace('.', ',')})` : '';
    const text = encodeURIComponent(
      `Olá Cartomante 24h! Gostaria de agendar uma consulta sobre: *${topicOrTitle}*${priceText}. Como posso iniciar?`
    );
    window.open(`https://wa.me/${config.phoneWhatsApp}?text=${text}`, '_blank');
  };

  const handleSelectPlan = (plan: PricingPlan) => {
    setSelectedPlan(plan);
    setCustomOrderTitle(plan.title);
    setCustomOrderPrice(plan.price);
    setIsPixModalOpen(true);
  };

  const handleSelectCartomanteLive = (cartomante: CartomanteProfile) => {
    setSelectedCartomante(cartomante);
    const matchedStream = INITIAL_LIVE_STREAMS.find(
      (s) => s.cartomanteId === cartomante.id || s.cartomanteName.toLowerCase().includes(cartomante.name.toLowerCase().split(' ')[0])
    );
    if (matchedStream) {
      setActiveLiveStream(matchedStream);
    } else {
      setActiveLiveStream({
        id: `live-${cartomante.id}`,
        cartomanteId: cartomante.id,
        cartomanteName: cartomante.name,
        cartomanteAvatar: cartomante.avatar,
        title: `🔴 Live Sagrada com ${cartomante.name} • Baralho Cigano & Respostas`,
        startedAt: 'Ao vivo agora',
        viewerCount: 42,
        isLive: true,
        category: 'baralho-cigano',
        description: `Mesa aberta ao vivo com ${cartomante.name}. Envie perguntas e receba a revelação das cartas na live!`
      });
    }
  };

  const handleSelectCartomanteWhatsApp = (cartomante: CartomanteProfile) => {
    setSelectedCartomanteForGroup(cartomante);
    setSelectedQuestionsCountForGroup(1);
    setIsSelectGroupModalOpen(true);
  };

  const handleSelectPlayWithCartomante = (cartomante: CartomanteProfile, questionsCount: 1 | 3) => {
    setSelectedCartomanteForGroup(cartomante);
    setSelectedQuestionsCountForGroup(questionsCount);
    setIsSelectGroupModalOpen(true);
  };

  const handleOpenLiveWithQuestion = (question?: string) => {
    if (INITIAL_LIVE_STREAMS.length > 0) {
      setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
    } else {
      setCurrentView('community');
    }
  };

  const scrollToPricing = () => {
    setCurrentView('home');
    setTimeout(() => {
      document.getElementById('valores')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const scrollToFreeDraw = () => {
    setCurrentView('home');
    setTimeout(() => {
      document.getElementById('oraculo-gratis')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="min-h-screen bg-[#06020e] text-white font-sans antialiased selection:bg-purple-600 selection:text-white flex flex-col relative overflow-x-hidden">
      {/* Cute Mystical Stars & Nebulae Background Artwork */}
      <div 
        className="fixed inset-0 pointer-events-none -z-20 bg-cover bg-center bg-no-repeat opacity-25 filter saturate-150"
        style={{ backgroundImage: `url(${cuteMysticBg})` }}
      />
      <div className="fixed inset-0 pointer-events-none -z-10 bg-gradient-to-b from-[#06020e]/80 via-[#06020e]/60 to-[#06020e]/95" />

      {/* If on dedicated Admin Page */}
      {currentView === 'admin' ? (
        <AdminPage
          config={config}
          currentUser={currentUser}
          onSaveConfig={handleSaveConfig}
          onBackToHome={() => setCurrentView('home')}
          onOpenCommunity={() => setCurrentView('community')}
        />
      ) : (
        <>
          {/* Header Navigation */}
          <Header
            config={config}
            currentUser={currentUser}
            onOpenAdmin={() => {
              if (currentUser?.role === 'admin') {
                setCurrentView('admin');
              } else {
                setIsAuthOpen(true);
              }
            }}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenWorkWithUs={() => setIsWorkWithUsOpen(true)}
            onOpenWhatsAppGroup={handleOpenWhatsAppGroup}
            onOpenLinkManager={handleOpenLinkManager}
            onOpenCommunity={() => setCurrentView('community')}
            onOpenLives={() => {
              if (INITIAL_LIVE_STREAMS.length > 0) {
                setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
              } else {
                setCurrentView('community');
              }
            }}
            onOpenRadio={() => setIsRadioOpen(true)}
          />

          <main className="flex-1">
            {currentView === 'community' ? (
              /* Dedicated Community, Feed, Friends/Favorites & Lives Page */
              <CommunityPage
                config={config}
                currentUser={currentUser}
                onOpenAuth={() => setIsAuthOpen(true)}
                onOpenLiveStream={(stream) => setActiveLiveStream(stream)}
                onBackToHome={() => setCurrentView('home')}
                onUpdateCurrentUser={handleUpdateCurrentUser}
              />
            ) : (
              /* Main Landing Page */
              <>
                {/* Hero Section */}
                <HeroSection
                  config={config}
                  currentUser={currentUser}
                  onOpenWhatsAppGroup={handleOpenWhatsAppGroup}
                  onOpenLives={() => {
                    if (INITIAL_LIVE_STREAMS.length > 0) {
                      setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
                    } else {
                      setCurrentView('community');
                    }
                  }}
                  onOpenRadio={() => setIsRadioOpen(true)}
                  onScrollToPricing={scrollToPricing}
                  onScrollToFreeDraw={scrollToFreeDraw}
                  onOpenLinkManager={handleOpenLinkManager}
                />

                {/* Pricing Table ("Valores: 1 Pergunta R$ 20 / 3 Perguntas R$ 50") */}
                <PricingCalculatorSection
                  config={config}
                  currentUser={currentUser}
                  onSelectPlan={handleSelectPlan}
                  onOpenWhatsAppDirect={handleOpenWhatsAppDirect}
                  onOpenLinkManager={handleOpenLinkManager}
                />

                {/* WhatsApp Group Dedicated Section */}
                <WhatsAppGroupSection
                  config={config}
                  currentUser={currentUser}
                  onJoinGroup={handleOpenWhatsAppGroup}
                  onTalkPrivate={() => handleOpenWhatsAppDirect('Atendimento Privado 24h')}
                  onOpenLinkManager={handleOpenLinkManager}
                  cartomantes={config.customCartomantes && config.customCartomantes.length > 0 ? config.customCartomantes : CARTOMANTES_PROFILES}
                  onSelectCartomanteToPlay={(cartomante) => {
                    setSelectedCartomanteForGroup(cartomante);
                    setIsSelectGroupModalOpen(true);
                  }}
                />

                {/* Cartomantes on Duty Section (With 1 Question R$20 & 3 Questions R$50 triggers & Live streaming) */}
                <CartomantesOnDuty
                  config={config}
                  currentUser={currentUser}
                  onSelectCartomanteLive={handleSelectCartomanteLive}
                  onSelectCartomanteWhatsApp={handleSelectCartomanteWhatsApp}
                  onSelectPlayWithCartomante={handleSelectPlayWithCartomante}
                  onOpenWorkWithUs={() => setIsWorkWithUsOpen(true)}
                  onOpenAdminEdit={() => setCurrentView('admin')}
                />

                {/* Rádio Macumba & Espiritualidades Section */}
                <RadioMacumbaSection onOpenRadioPlayer={() => setIsRadioOpen(true)} />

                {/* Salão de Jogos Místicos & Distrações (Roleta, Memória, Raspadinha, Búzios, Quiz) */}
                <MysticalGamesSection
                  config={config}
                  onSelectCartomanteToPlay={(cartomante) => {
                    if (cartomante) {
                      setSelectedCartomanteForGroup(cartomante);
                    }
                    setIsSelectGroupModalOpen(true);
                  }}
                  onJoinGroup={handleOpenWhatsAppGroup}
                />

                {/* Free Instant Tarot Oracle Draw (Gemini AI + Baralho Cigano) */}
                <FreeTarotDraw
                  config={config}
                  onOpenLiveWithQuestion={handleOpenLiveWithQuestion}
                  onOpenWhatsAppDirect={handleOpenWhatsAppDirect}
                />

                {/* Social Proof & Verified Testimonials */}
                <TestimonialsSection config={config} />

                {/* FAQs */}
                <FaqSection config={config} />
              </>
            )}
          </main>

          {/* Footer */}
          <Footer
            config={config}
            onOpenWhatsAppGroup={handleOpenWhatsAppGroup}
            onOpenLives={() => {
              if (INITIAL_LIVE_STREAMS.length > 0) {
                setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
              } else {
                setCurrentView('community');
              }
            }}
            onOpenAdmin={() => {
              if (currentUser?.role === 'admin') {
                setCurrentView('admin');
              } else {
                setIsAuthOpen(true);
              }
            }}
          />

          {/* Floating WhatsApp Quick Action Button */}
          <FloatingWhatsAppButton
            config={config}
            isAdmin={currentUser?.role === 'admin'}
            onOpenWhatsAppGroup={handleOpenWhatsAppGroup}
            onOpenLives={() => {
              if (INITIAL_LIVE_STREAMS.length > 0) {
                setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
              } else {
                setCurrentView('community');
              }
            }}
            onOpenLinkManager={handleOpenLinkManager}
          />
        </>
      )}

      {/* Live Stream Full Broadcast & Chat Room Modal */}
      <LiveStreamModal
        isOpen={activeLiveStream !== null}
        onClose={() => setActiveLiveStream(null)}
        stream={activeLiveStream}
        currentUser={currentUser}
        config={config}
        onEndStream={(streamId) => {
          setActiveLiveStream(null);
        }}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Rádio Macumba Persistent/Floating Audio Player */}
      <RadioMacumbaPlayer
        isOpen={isRadioOpen}
        onClose={() => setIsRadioOpen(false)}
      />

      {/* PIX Instant Payment Modal with Cartomante Group redirection */}
      <PixPaymentModal
        isOpen={isPixModalOpen}
        onClose={() => setIsPixModalOpen(false)}
        plan={selectedPlan}
        customTitle={customOrderTitle}
        customPrice={customOrderPrice}
        config={config}
        onPaymentConfirmed={() => {
          handleOpenWhatsAppGroup();
        }}
      />

      {/* Mandatory Cartomante Selection & WhatsApp Group Entry Modal */}
      <SelectCartomanteGroupModal
        isOpen={isSelectGroupModalOpen}
        onClose={() => setIsSelectGroupModalOpen(false)}
        config={config}
        cartomantes={config.customCartomantes && config.customCartomantes.length > 0 ? config.customCartomantes : CARTOMANTES_PROFILES}
        initialCartomante={selectedCartomanteForGroup}
        initialQuestionsCount={selectedQuestionsCountForGroup}
      />

      {/* Admin Link Manager Modal (Dedicated click link update hub) */}
      <AdminLinkManagerModal
        isOpen={isLinkManagerOpen}
        onClose={() => setIsLinkManagerOpen(false)}
        config={config}
        onSaveConfig={handleSaveConfig}
        targetLinkId={targetLinkId}
      />

      {/* Login & Registration Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Client Profile and History Modal */}
      <ClientProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={currentUser}
        config={config}
        onLogout={handleLogout}
        onOpenLives={() => {
          setIsProfileOpen(false);
          if (INITIAL_LIVE_STREAMS.length > 0) {
            setActiveLiveStream(INITIAL_LIVE_STREAMS[0]);
          } else {
            setCurrentView('community');
          }
        }}
        onOpenWhatsAppDirect={handleOpenWhatsAppDirect}
        onUpdateUser={(updatedUser) => setCurrentUser(updatedUser)}
      />

      {/* Work With Us (Cartomante Application) Modal */}
      <WorkWithUsModal
        isOpen={isWorkWithUsOpen}
        onClose={() => setIsWorkWithUsOpen(false)}
        onCandidateSubmitted={(newCandidate) => {
          console.log('Nova inscrição enviada:', newCandidate);
        }}
      />
    </div>
  );
}
