export type DeckType = 'cigano' | 'marselha' | 'orixas' | 'anjos';

export interface TarotCard {
  id: number;
  name: string;
  deck: DeckType;
  imageIcon: string;
  summary: string;
  loveMeaning: string;
  careerMeaning: string;
  advice: string;
  keywords: string[];
  element: 'Fogo' | 'Água' | 'Terra' | 'Ar' | 'Espírito';
  number: number;
}

export interface CartomanteProfile {
  id: string;
  name: string;
  title: string;
  avatar: string;
  rating: number;
  consultationsCount: number;
  experienceYears: number;
  isOnline: boolean;
  statusText: string;
  specialties: string[];
  deckTypes: string[];
  bio: string;
  voiceNoteUrl?: string;
  voiceGreetingText: string;
  whatsappMessage: string;
  phone?: string;
  monthlyFeeStatus?: 'pago' | 'pendente' | 'vencido';
  monthlyFeeDueDate?: string;
}

export interface PricingPlan {
  id: string;
  title: string;
  badge?: string;
  durationMinutes: number;
  price: number;
  originalPrice?: number;
  directQuestions: number;
  description: string;
  features: string[];
  isPopular?: boolean;
  format: 'video' | 'audio_whatsapp' | 'mesa_real';
  ctaText: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  city: string;
  stars: number;
  date: string;
  comment: string;
  serviceUsed: string;
  avatar: string;
  whatsappScreenshotText?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'atendimento' | 'video' | 'valores' | 'whatsapp' | 'sigilo';
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: 'client' | 'admin' | 'cartomante';
  phone?: string;
  phoneVerified?: boolean;
  cpf?: string;
  birthDate?: string;
  city?: string;
  state?: string;
  avatar?: string;
  bio?: string;
  astrologicalSign?: string;
  favoriteUserIds?: string[];
  isApprovedByAdmin?: boolean; // For cartomantes to work on the site
  monthlyFeeStatus?: 'pago' | 'pendente' | 'vencido';
  monthlyFeeDueDate?: string;
  monthlyFeeApprovedUntil?: string;
  createdAt: string;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: 'client' | 'cartomante' | 'admin';
  content: string;
  createdAt: string;
  likes: number;
  likedByMe?: boolean;
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorRole: 'client' | 'cartomante' | 'admin';
  authorTitle?: string;
  authorBio?: string;
  content: string;
  imageUrl?: string;
  likes: number;
  likedBy: string[];
  comments: PostComment[];
  topic: 'relato' | 'duvida' | 'previsao' | 'amor' | 'prosperidade' | 'oraculo' | 'geral';
  tarotCardAttachment?: {
    name: string;
    icon: string;
    summary: string;
  };
  taggedUsers?: {
    id: string;
    name: string;
    role: 'client' | 'cartomante' | 'admin';
  }[];
  createdAt: string;
}

export interface LiveStreamSession {
  id: string;
  cartomanteId: string;
  cartomanteName: string;
  cartomanteTitle: string;
  cartomanteAvatar: string;
  title: string;
  topic: string;
  isLive: boolean;
  viewersCount: number;
  whatsappGroupLink: string;
  whatsappPhone: string;
  startedAt: string;
  featuredCard?: string;
  bannerUrl?: string;
  activeQuestion?: string;
  currentLiveDeck?: string;
}

export interface LiveChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: 'client' | 'cartomante' | 'admin';
  message: string;
  timestamp: string;
  isHighlight?: boolean;
}

export interface LiveQuestion {
  id: string;
  streamId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorRole: 'client' | 'cartomante' | 'admin';
  question: string;
  category?: 'amor' | 'financeiro' | 'espiritual' | 'saude' | 'geral';
  type: '1_pergunta' | '3_perguntas' | 'geral';
  price?: number;
  status: 'aguardando' | 'respondendo' | 'respondida';
  revealedCards?: string[];
  cartomanteAnswer?: string;
  upvotes?: number;
  createdAt: string;
  answeredAt?: string;
}

export interface RadioTrack {
  id: string;
  title: string;
  artistOrEntity: string;
  duration: string;
  pontoLyrics?: string;
  category: 'umbanda' | 'candomble' | 'cigano' | 'xamanismo' | 'mantras' | 'curimba';
}

export interface RadioStation {
  id: string;
  name: string;
  tagline: string;
  category: 'umbanda' | 'candomble' | 'cigano' | 'xamanismo' | 'mantras' | 'curimba';
  badgeColor: string;
  coverImage: string;
  description: string;
  frequency: string;
  streamUrl: string;
  backupStreamUrl?: string;
  tracks: RadioTrack[];
  rhythmStyle: 'ijexa' | 'barravento' | 'congo' | 'cigano_flamenco' | 'xamanico_tambor' | 'mantra_432hz';
}

export interface ClientProfileData {
  userId: string;
  name: string;
  email: string;
  phone: string;
  birthDate: string;
  astrologicalSign: string;
  preferredDeck: DeckType;
  notes: string;
  avatar?: string;
  consultationsHistory: {
    id: string;
    date: string;
    type: string;
    questionsCount: number;
    price: number;
    cartomanteName: string;
    status: 'concluida' | 'agendada' | 'em_andamento';
  }[];
}

export interface CartomanteCandidate {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  experienceYears: number;
  specialties: string[];
  deckTypes: string[];
  bio: string;
  groupLink: string; // The whatsapp group link created by the candidate
  instagramOrFacebook?: string;
  status: 'pendente' | 'aprovado' | 'rejeitado';
  appliedAt: string;
  approvedAt?: string;
  pricePer1Question?: number; // R$ 20,00
  pricePer3Questions?: number; // R$ 50,00
}

export interface SiteConfig {
  siteName: string;
  siteSlogan?: string;
  phoneWhatsApp: string;
  groupWhatsAppLink: string;
  developerWhatsApp?: string; // WhatsApp do Provedor / Desenvolvedor para pagamento e manutenção mensal
  monthlyFeeAmount?: number; // Valor mensal de manutenção (ex: 50.00)
  monthlyFeePixKey?: string; // Chave PIX do desenvolvedor/provedor
  cartomanteMonthlyFeeAmount?: number; // Valor da mensalidade cobrada das cartomantes pelo Jefferson (ex: 50.00)
  cartomanteMonthlyFeePixKey?: string; // Chave PIX do Jefferson/Admin para receber a mensalidade das cartomantes
  cartomanteMonthlyFeeReceiverName?: string; // Nome do titular da chave PIX do Jefferson
  cartomanteMonthlyFeeCustomMessage?: string; // Mensagem personalizada de cobrança enviada no WhatsApp das cartomantes
  videoConsultLink?: string;
  facebookLink?: string; // Link da Página ou Grupo do Facebook
  facebookPageName?: string; // Nome da Página do Facebook
  facebookPixelId?: string; // ID do Pixel do Facebook (Meta Ads)
  cloneDomainUrl?: string; // Domínio ou URL do site clonado
  instagramLink?: string;
  telegramLink?: string;
  youtubeLink?: string;
  pixKey: string;
  pixReceiverName: string;
  pixCity: string;
  emergencyNightShiftActive: boolean;
  onlineNotice: string;
  adminEmail?: string;
  price1Question?: number; // R$ 20.00
  price3Questions?: number; // R$ 50.00
  heroTitle?: string;
  heroSubtitle?: string;
  heroBadge?: string;
  footerAbout?: string;
  whatsappMessageTemplate?: string;
  customCartomantes?: CartomanteProfile[];
  customFaqs?: FAQItem[];
  customTestimonials?: Testimonial[];
  customLinks?: Record<string, string>; // Maps button/click IDs to custom updated URLs or actions
  floatingBalloonAction?: 'menu' | 'direct_whatsapp' | 'direct_group' | 'custom_url'; // Ação do balão flutuante
  floatingBalloonCustomUrl?: string; // Link personalizado do balão flutuante
  floatingBalloonDirectMessage?: string; // Mensagem automática enviada no WhatsApp pelo balão
  floatingBalloonNotice?: string; // Texto de aviso no balão (ex: Plantão 24h Ativo)
  enableLiveSoundAlerts?: boolean; // Tocar som de sino ao iniciar live
}

export interface WebChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  senderRole: 'client' | 'cartomante' | 'admin';
  text: string;
  tarotCard?: {
    name: string;
    image?: string;
    suit?: string;
    meaning: string;
    advice: string;
  };
  timestamp: string;
  isSpiritualAdvice?: boolean;
}

export interface WebChatSession {
  id: string;
  cartomanteId: string;
  cartomanteName: string;
  cartomanteAvatar: string;
  cartomanteTitle: string;
  clientId: string;
  clientName: string;
  clientAvatar?: string;
  lastMessage: string;
  lastMessageAt: string;
  unreadCount?: number;
}

